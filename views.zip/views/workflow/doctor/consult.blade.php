@php
    $title = __('Consultation - :name', ['name' => $visit->patient->full_name]);

    $medicineOptions = $medicines->map(function ($m) {
        return [
            'id' => $m->id,
            'name' => $m->name,
            'category_id' => $m->category_id,
            'batches' => $m->batches->map(function ($b) {
                return [
                    'id' => $b->id,
                    'sale_price' => $b->sale_price,
                    'stock' => $b->remaining_quantity,
                ];
            })->values()->toArray(),
        ];
    })->values()->toArray();

    $categoryOptions = $categories->map(function ($c) {
        return ['id' => $c->id, 'name' => $c->name];
    })->values()->toArray();

    $labTestOptions = $labTests->map(function ($t) {
        return [
            'id' => $t->id,
            'name' => $t->name,
            'price' => $t->price,
            'category_id' => $t->category?->id,
        ];
    })->values()->toArray();

    $labTestCategoryOptions = $labTestCategories->map(function ($c) {
        return ['id' => $c->id, 'name' => $c->name];
    })->values()->toArray();

    $latestVital = $visit->vitals->sortByDesc('created_at')->first();
@endphp

@extends('layouts.admin')

@section('content')
<style>
    .consultation-summary .description-block { margin: 0; }
    .consultation-summary .description-header { font-size: 1rem; margin-bottom: .15rem; }
    .clinical-card .card-header { border-bottom: 1px solid rgba(0, 0, 0, .08); }
    .clinical-card .card-title { font-size: 1rem; font-weight: 600; }
    .clinical-subtitle {
        color: #6c757d;
        font-size: .8rem;
        font-weight: 600;
        letter-spacing: 0;
        margin-bottom: .5rem;
        text-transform: uppercase;
    }
    .clinical-table th,
    .clinical-table td { vertical-align: middle; white-space: nowrap; }
    .clinical-table td:first-child,
    .clinical-table th:first-child { white-space: normal; }
    .clinical-actions {
        background: #fff;
        border-top: 1px solid #dee2e6;
        bottom: 0;
        margin: 0 -7.5px;
        padding: .75rem 7.5px;
        position: sticky;
        z-index: 5;
    }
    .new-entry-table {
        border-collapse: collapse;
        width: 100%;
    }
    .new-entry-table th,
    .new-entry-table td {
        border-top: 1px solid #dee2e6;
        padding: .3rem;
        vertical-align: middle;
    }
    .new-entry-table thead th {
        border-bottom: 2px solid #dee2e6;
        font-size: .875rem;
        font-weight: 600;
    }
</style>

<div class="card consultation-summary">
    <div class="card-body py-3">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-6 mb-3 mb-lg-0">
                <div class="d-flex align-items-center">
                    <div class="mr-3">
                        <span class="fa-stack fa-lg text-primary">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fas fa-user-injured fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div>
                        <div class="text-muted small">{{ __('Patient') }}</div>
                        <h4 class="mb-0">{{ $visit->patient->full_name }}</h4>
                        <div class="text-muted small">{{ $visit->patient->mrn }} | {{ $visit->visit_code }}</div>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 col-md-6 mb-3 mb-lg-0">
                <div class="row">
                    <div class="col-4">
                        <div class="description-block border-right">
                            <span class="description-text">{{ __('Gender') }}</span>
                            <h5 class="description-header">{{ __(ucfirst($visit->patient->gender)) }}</h5>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="description-block border-right">
                            <span class="description-text">{{ __('Age') }}</span>
                            <h5 class="description-header">{{ $visit->patient->date_of_birth?->age ?? __('N/A') }}</h5>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="description-block">
                            <span class="description-text">{{ __('Phone') }}</span>
                            <h5 class="description-header">{{ $visit->patient->phone ?: '-' }}</h5>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                @if($latestVital)
                    <div class="d-flex flex-wrap justify-content-lg-end">
                        <span class="badge badge-light border mr-2 mb-2">{{ __('BP') }}: {{ $latestVital->blood_pressure ?: '-' }}</span>
                        <span class="badge badge-light border mr-2 mb-2">{{ __('Temp') }}: {{ $latestVital->temperature_celsius ?: '-' }} C</span>
                        <span class="badge badge-light border mr-2 mb-2">{{ __('Pulse') }}: {{ $latestVital->pulse_rate ?: '-' }}</span>
                        <span class="badge badge-light border mb-2">{{ __('O2 Sat') }}: {{ $latestVital->oxygen_saturation ?: '-' }}%</span>
                    </div>
                @else
                    <div class="text-lg-right text-muted">{{ __('No vitals recorded') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>

<form id="consultation-form">
    @csrf

    <div class="row">
        <div class="col-12">
            <div class="card card-primary clinical-card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-notes-medical mr-1"></i> {{ __('Clinical Note') }}</h3>
                </div>

                <div class="card-body">
                    <div class="form-group">
                        <label>{{ __('Chief Complaint') }} <span class="text-danger">*</span></label>
                        <textarea name="chief_complaint" class="form-control" rows="2" required>{{ $visit->consultation?->chief_complaint }}</textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>{{ __('History') }}</label>
                                <textarea name="history" class="form-control" rows="3">{{ $visit->consultation?->history }}</textarea>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label>{{ __('Examination') }}</label>
                                <textarea name="examination" class="form-control" rows="3">{{ $visit->consultation?->examination }}</textarea>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-0">
                        <label>{{ __('Treatment Plan') }}</label>
                        <textarea name="treatment_plan" class="form-control" rows="2">{{ $visit->consultation?->treatment_plan }}</textarea>
                    </div>
                </div>
            </div>

            <div class="card card-info clinical-card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-diagnoses mr-1"></i> {{ __('Diagnoses') }}
                    </h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool text-white" id="add-diagnosis" title="{{ __('Add Diagnosis') }}">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="new-entry-table" id="diagnosis-table">
                            <thead>
                                <tr>
                                    <th>{{ __('Diagnosis') }}</th>
                                    <th style="width: 190px">{{ __('Type') }}</th>
                                    <th style="width: 60px">{{ __('Action') }}</th>
                                </tr>
                            </thead>

                            <tbody>
                                @if($visit->consultation)
                                    @foreach($visit->consultation->diagnoses as $d)
                                        <tr>
                                            <td>
                                                <input type="text"
                                                       name="diagnoses[{{ $loop->index }}][name]"
                                                       class="form-control form-control-sm"
                                                       value="{{ $d->diagnosis_name }}">
                                            </td>

                                            <td>
                                                <select name="diagnoses[{{ $loop->index }}][type]" class="form-control form-control-sm">
                                                    <option value="provisional" {{ $d->diagnosis_type === 'provisional' ? 'selected' : '' }}>
                                                        {{ __('Provisional') }}
                                                    </option>

                                                    <option value="final" {{ $d->diagnosis_type === 'final' ? 'selected' : '' }}>
                                                        {{ __('Final') }}
                                                    </option>

                                                    <option value="differential" {{ $d->diagnosis_type === 'differential' ? 'selected' : '' }}>
                                                        {{ __('Differential') }}
                                                    </option>
                                                </select>
                                            </td>

                                            <td>
                                                <button type="button" class="btn btn-sm btn-danger remove-diagnosis" title="{{ __('Remove') }}">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            @if($labResults->count())
                <div class="card card-info clinical-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0"><i class="fas fa-chart-line mr-1"></i> {{ __('Previous Lab Results') }}</h3>
                        <span class="badge badge-info">{{ $labResults->count() }} {{ __('result(s)') }}</span>
                    </div>
                    <div class="card-body p-0">
                        @foreach($labResults as $lr)
                        <div class="border-bottom {{ !$loop->last ? '' : 'border-bottom-0' }}">
                            <div class="bg-light px-3 py-2 d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-calendar-alt text-muted mr-1"></i>
                                    <strong>{{ displayDate($lr->result_date, 'Y-m-d') }}</strong>
                                    <span class="text-muted mx-1">|</span>
                                    <span class="text-muted">{{ $lr->items->count() }} {{ __('test(s)') }}</span>
                                </div>
                                <div>
                                    <a href="{{ route('workflow.lab.result', $lr->id) }}" class="btn btn-sm btn-info mr-1" target="_blank">
                                        <i class="fas fa-external-link-alt mr-1"></i>{{ __('Full Report') }}
                                    </a>
                                    @if($lr->file_path)
                                    <a href="{{ Storage::disk('public')->url($lr->file_path) }}" target="_blank" class="btn btn-sm btn-outline-info" rel="noopener noreferrer">
                                        <i class="fas fa-{{ in_array($lr->file_type, ['jpg','jpeg','png','gif','webp']) ? 'image' : 'paperclip' }} mr-1"></i>
                                        {{ __('File') }}
                                    </a>
                                    @endif
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-hover mb-0">
                                    <thead class="text-muted small">
                                        <tr>
                                            <th width="22%">{{ __('Test') }}</th>
                                            <th width="15%">{{ __('Result') }}</th>
                                            <th width="15%">{{ __('Normal Range') }}</th>
                                            <th width="8%">{{ __('Flag') }}</th>
                                            <th width="40%">{{ __('Remarks') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($lr->items as $item)
                                        @php
                                            $flagClass = $item->flag === 'normal' ? 'success' : ($item->flag === 'critical' ? 'danger' : ($item->flag === 'abnormal' ? 'warning' : 'secondary'));
                                            $isAbnormal = $item->flag && $item->flag !== 'normal';
                                        @endphp
                                        <tr class="{{ $isAbnormal ? 'table-active' : '' }}">
                                            <td>
                                                <strong>{{ $item->test_name }}</strong>
                                                @if($item->labTest?->unit)
                                                <br><small class="text-muted">({{ $item->labTest->unit }})</small>
                                                @endif
                                            </td>
                                            <td>
                                                <span class="font-weight-bold {{ $isAbnormal ? 'text-danger' : 'text-success' }}">
                                                    {{ $item->result_value }}
                                                </span>
                                                @if($item->unit)
                                                <small class="text-muted"> {{ $item->unit }}</small>
                                                @endif
                                            </td>
                                            <td>
                                                <small class="text-muted">
                                                    {{ $item->normal_range ?? ($item->labTest->normal_range ?? '—') }}
                                                </small>
                                            </td>
                                            <td>
                                                @if($item->flag)
                                                <span class="badge badge-{{ $flagClass }} px-2 py-1">
                                                    {{ $item->flag === 'critical' ? '!' : ucfirst($item->flag) }}
                                                </span>
                                                @else
                                                <span class="text-muted">—</span>
                                                @endif
                                            </td>
                                            <td>
                                                <small class="text-muted">{{ $item->remarks ?? '—' }}</small>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @if($lr->file_path && in_array($lr->file_type, ['jpg','jpeg','png','gif','webp']))
                            <div class="text-center py-2">
                                <a href="{{ Storage::disk('public')->url($lr->file_path) }}" target="_blank" rel="noopener noreferrer">
                                    <img src="{{ Storage::disk('public')->url($lr->file_path) }}"
                                         alt="Lab Result"
                                         class="img-fluid rounded"
                                         style="max-height:200px;object-fit:contain;cursor:zoom-in">
                                </a>
                            </div>
                            @endif
                        </div>
                        @endforeach
                    </div>
                </div>
            @endif
        </div>

        <div class="col-12 mt-3">
            <div class="card card-success clinical-card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-prescription mr-1"></i> {{ __('Prescriptions') }}
                    </h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool text-white" id="add-prescription" title="{{ __('Add Medicine') }}">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>

                <div class="card-body">
                    @if($visit->prescriptions->isNotEmpty())
                        <div class="clinical-subtitle">{{ __('Saved Prescriptions') }}</div>
                        <div class="table-responsive mb-3">
                            <table class="table table-sm table-striped clinical-table mb-0">
                                <thead>
                                    <tr>
                                        <th>{{ __('Medicine') }}</th>
                                        <th>{{ __('Dose') }}</th>
                                        <th>{{ __('Freq') }}</th>
                                        <th>{{ __('Duration') }}</th>
                                        <th>{{ __('Qty') }}</th>
                                        <th>{{ __('Status') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($visit->prescriptions->sortByDesc('prescription_date') as $prescription)
                                        @foreach($prescription->items as $item)
                                            <tr>
                                                <td>
                                                    <strong>{{ $item->medicine_name }}</strong>
                                                    <div class="text-muted small">{{ $prescription->prescription_code }} | {{ displayDate($prescription->prescription_date, 'Y-m-d') }}</div>
                                                </td>
                                                <td>{{ $item->dosage }}</td>
                                                <td>{{ $item->frequency }}</td>
                                                <td>{{ $item->duration }}</td>
                                                <td>{{ $item->quantity }}</td>
                                                <td>
                                                    @if($prescription->pharmacySale)
                                                        <span class="badge badge-success">{{ __('Received') }}</span>
                                                    @else
                                                        <span class="badge badge-warning">{{ __('Pending') }}</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif

                    <div class="clinical-subtitle">{{ __('New Medicines') }}</div>
                    <div class="table-responsive">
                        <table class="new-entry-table mb-2" id="prescription-table">
                            <thead>
                                <tr>
                                    <th style="min-width: 130px">{{ __('Category') }}</th>
                                    <th style="min-width: 160px">{{ __('Medicine') }}</th>
                                    <th style="width: 90px">{{ __('Dosage') }}</th>
                                    <th style="width: 80px">{{ __('Freq') }}</th>
                                    <th style="width: 90px">{{ __('Duration') }}</th>
                                    <th style="width: 60px">{{ __('Qty') }}</th>
                                    <th style="width: 50px">{{ __('Action') }}</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>

                    <button type="button" class="btn btn-sm btn-outline-success" id="add-prescription-inline">
                        <i class="fas fa-plus"></i> {{ __('Add Medicine') }}
                    </button>
                </div>
            </div>

            <div class="card card-warning clinical-card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-flask mr-1"></i> {{ __('Lab Tests') }}
                    </h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool text-dark" id="add-lab-test" title="{{ __('Order Lab Test') }}">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>

                <div class="card-body">
                    @if($visit->labRequests->isNotEmpty())
                        <div class="clinical-subtitle">{{ __('Saved Lab Requests') }}</div>
                        <div class="table-responsive mb-3">
                            <table class="table table-sm table-striped clinical-table mb-0">
                                <thead>
                                    <tr>
                                        <th>{{ __('Lab Test') }}</th>
                                        <th>{{ __('Priority') }}</th>
                                        <th>{{ __('Payment') }}</th>
                                        <th>{{ __('Status') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($visit->labRequests->sortByDesc('request_date') as $labRequest)
                                        @foreach($labRequest->items as $item)
                                            <tr>
                                                <td>
                                                    <strong>{{ $item->test_name }}</strong>
                                                    <div class="text-muted small">{{ $labRequest->request_code }} | {{ displayDate($labRequest->request_date, 'Y-m-d') }}</div>
                                                </td>
                                                <td>{{ __(ucfirst($labRequest->priority ?? 'routine')) }}</td>
                                                <td>{{ __(ucwords(str_replace('_', ' ', $labRequest->payment_status ?? ''))) }}</td>
                                                <td>{{ __(ucwords(str_replace('_', ' ', $labRequest->status ?? ''))) }}</td>
                                            </tr>
                                        @endforeach
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @endif

                    <div class="clinical-subtitle">{{ __('New Lab Orders') }}</div>
                    <div class="table-responsive">
                        <table class="new-entry-table mb-2" id="lab-table">
                            <thead>
                                <tr>
                                    <th style="min-width: 130px">{{ __('Category') }}</th>
                                    <th style="min-width: 160px">{{ __('Lab Test') }}</th>
                                    <th style="width: 100px">{{ __('Priority') }}</th>
                                    <th style="width: 50px">{{ __('Action') }}</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>

                    <button type="button" class="btn btn-sm btn-outline-warning" id="add-lab-test-inline">
                        <i class="fas fa-plus"></i> {{ __('Order Lab Test') }}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="clinical-actions">
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> {{ __('Save Consultation') }}
        </button>

        <a href="{{ route('workflow.doctor.pending') }}" class="btn btn-default">
            {{ __('Cancel') }}
        </a>
    </div>
</form>
@endsection

@push('js')
<script>
$(document).ready(function () {
    $('.clinical-card table.table').each(function () {
        if ($.fn.DataTable && $.fn.DataTable.isDataTable(this)) {
            $(this).DataTable().destroy();
        }
    });

    var medIdx = 0;
    var labIdx = 0;
    var diagIdx = {{ $visit->consultation?->diagnoses?->count() ?? 0 }};

    var medicines = @json($medicineOptions);
    var categories = @json($categoryOptions);
    var labTests = @json($labTestOptions);
    var labTestCategories = @json($labTestCategoryOptions);

    function filterLabTests(catId, testSelect) {
        var filtered = catId
            ? labTests.filter(function (t) { return t.category_id == catId; })
            : labTests;
        var opts = filtered.map(function (t) {
            return '<option value="' + t.id + '">' + t.name + ' (' + t.price + ' {{ __("AFN") }})</option>';
        }).join('');
        testSelect.html(opts).trigger('change');
    }

    function filterMedicines(catId, medSelect) {
        var filtered = catId
            ? medicines.filter(function (m) { return m.category_id == catId; })
            : medicines;
        var opts = filtered.map(function (m) {
            return '<option value="' + m.id + '" data-batches=\'' + JSON.stringify(m.batches) + '\'>' + m.name + '</option>';
        }).join('');
        medSelect.html(opts).trigger('change');
    }

    $('#add-prescription, #add-prescription-inline').on('click', function () {
        var catOpts = '<option value="">{{ __("Select category") }}</option>' +
            categories.map(function (c) {
                return '<option value="' + c.id + '">' + c.name + '</option>';
            }).join('');

        var html =
            '<tr>' +
                '<td><select class="form-control form-control-sm category-select" style="width:100%">' + catOpts + '</select></td>' +
                '<td><select class="form-control form-control-sm medicine-select" name="prescriptions[' + medIdx + '][medicine_id]" style="width:100%"></select></td>' +
                '<td><input type="text" name="prescriptions[' + medIdx + '][dosage]" class="form-control form-control-sm" placeholder="{{ __("e.g. 500mg") }}"></td>' +
                '<td><input type="text" name="prescriptions[' + medIdx + '][frequency]" class="form-control form-control-sm" placeholder="{{ __("e.g. TID") }}"></td>' +
                '<td><input type="text" name="prescriptions[' + medIdx + '][duration]" class="form-control form-control-sm" placeholder="{{ __("e.g. 7 days") }}"></td>' +
                '<td><input type="number" name="prescriptions[' + medIdx + '][quantity]" class="form-control form-control-sm" min="1" value="1" style="width:70px"></td>' +
                '<td><button type="button" class="btn btn-sm btn-danger remove-prescription"><i class="fas fa-times"></i></button></td>' +
            '</tr>';

        var $row = $(html);
        $('#prescription-table tbody').append($row);

        var $catSelect = $row.find('.category-select');
        var $medSelect = $row.find('.medicine-select');

        $catSelect.select2({theme: 'bootstrap4', width: '100%'});
        $medSelect.select2({theme: 'bootstrap4', width: '100%'});

        $catSelect.on('change', function () {
            filterMedicines($(this).val(), $medSelect);
        });

        filterMedicines('', $medSelect);
        medIdx++;
    });

    $('#add-lab-test, #add-lab-test-inline').on('click', function () {
        var catOpts = '<option value="">{{ __("Select category") }}</option>' +
            labTestCategories.map(function (c) {
                return '<option value="' + c.id + '">' + c.name + '</option>';
            }).join('');

        var html =
            '<tr>' +
                '<td><select class="form-control form-control-sm lab-category-select" style="width:100%">' + catOpts + '</select></td>' +
                '<td><select class="form-control form-control-sm lab-test-select" name="lab_requests[' + labIdx + '][lab_test_id]" style="width:100%"></select></td>' +
                '<td><select name="lab_requests[' + labIdx + '][priority]" class="form-control form-control-sm">' +
                    '<option value="routine">{{ __("Routine") }}</option>' +
                    '<option value="urgent">{{ __("Urgent") }}</option>' +
                    '<option value="stat">{{ __("STAT") }}</option>' +
                '</select></td>' +
                '<td><button type="button" class="btn btn-sm btn-danger remove-lab-test"><i class="fas fa-times"></i></button></td>' +
            '</tr>';

        var $row = $(html);
        $('#lab-table tbody').append($row);

        var $catSelect = $row.find('.lab-category-select');
        var $testSelect = $row.find('.lab-test-select');

        $catSelect.select2({theme: 'bootstrap4', width: '100%'});
        $testSelect.select2({theme: 'bootstrap4', width: '100%'});

        $catSelect.on('change', function () {
            filterLabTests($(this).val(), $testSelect);
        });

        filterLabTests('', $testSelect);
        labIdx++;
    });

    $('#add-diagnosis').on('click', function () {
        var html =
            '<tr>' +
                '<td><input type="text" name="diagnoses[' + diagIdx + '][name]" class="form-control form-control-sm" placeholder="{{ __("Diagnosis name") }}"></td>' +
                '<td><select name="diagnoses[' + diagIdx + '][type]" class="form-control form-control-sm">' +
                    '<option value="provisional">{{ __("Provisional") }}</option>' +
                    '<option value="final">{{ __("Final") }}</option>' +
                    '<option value="differential">{{ __("Differential") }}</option>' +
                '</select></td>' +
                '<td><button type="button" class="btn btn-sm btn-danger remove-diagnosis"><i class="fas fa-times"></i></button></td>' +
            '</tr>';

        $('#diagnosis-table tbody').append(html);
        diagIdx++;
    });

    $(document).on('click', '.remove-prescription', function () {
        $(this).closest('tr').remove();
    });

    $(document).on('click', '.remove-lab-test', function () {
        $(this).closest('tr').remove();
    });

    $(document).on('click', '.remove-diagnosis', function () {
        $(this).closest('tr').remove();
    });

    $('#consultation-form').on('submit', function (e) {
        e.preventDefault();

        var btn = $(this).find('button[type="submit"]');

        btn.html('<i class="fas fa-spinner fa-spin"></i> {{ __("Saving...") }}').prop('disabled', true);

        $.ajax({
            url: '{{ route("workflow.doctor.save-consultation", $visit->id) }}',
            method: 'POST',
            data: $(this).serialize(),

            success: function (res) {
                if (res.success) {
                    window.location.href = res.redirect;
                }
            },

            error: function (xhr) {
                var errors = xhr.responseJSON ? xhr.responseJSON.errors : null;
                var msg = '<div class="alert alert-danger"><ul>';

                if (errors) {
                    $.each(errors, function (k, v) {
                        msg += '<li>' + v[0] + '</li>';
                    });
                } else {
                    msg += '<li>{{ __("Something went wrong.") }}</li>';
                }

                msg += '</ul></div>';

                $('#consultation-form .alert-danger').remove();
                $('#consultation-form').prepend(msg);

                btn.html('<i class="fas fa-save"></i> {{ __("Save Consultation") }}').prop('disabled', false);
            }
        });
    });
});
</script>
@endpush
