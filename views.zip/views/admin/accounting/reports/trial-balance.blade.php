@extends('layouts.admin', ['title' => __('Trial Balance')])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ __('Trial Balance') }}</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>{{ __('Account Code') }}</th>
                                    <th>{{ __('Account Name') }}</th>
                                    <th>{{ __('Type') }}</th>
                                    <th>{{ __('Debit') }}</th>
                                    <th>{{ __('Credit') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($accounts as $item)
                                    <tr>
                                        <td>{{ $item['account']->code }}</td>
                                        <td>{{ $item['account']->name }}</td>
                                        <td>{{ __($item['account']->type) }}</td>
                                        <td>{{ number_format($item['debit'], 2) }}</td>
                                        <td>{{ number_format($item['credit'], 2) }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">{{ __('No chart of accounts defined.') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3">{{ __('Totals') }}</th>
                                    <th>{{ number_format($totalDebit, 2) }}</th>
                                    <th>{{ number_format($totalCredit, 2) }}</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
