@extends('layouts.admin', ['title' => $resource === 'patients' ? __('Patient Record') : $config['title'], 'resource' => $resource])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ $resource === 'patients' ? __('Patient Record') : __($config['title']).' '.__('Detail') }}</h3>
                    <div class="card-tools">
                        <a class="btn btn-secondary btn-sm" href="{{ route('masters.index', $resource) }}">
                            <i class="fas fa-arrow-left"></i> {{ __('Back') }}
                        </a>
                        @if (! empty($invoice))
                            <a class="btn btn-success btn-sm" href="{{ route('invoices.print', $invoice) }}">
                                <i class="fas fa-print"></i> {{ __('Print Bill') }}
                            </a>
                            <a class="btn btn-info btn-sm" href="{{ route('invoices.download', $invoice) }}">
                                <i class="fas fa-file-pdf"></i> {{ __('Download PDF') }}
                            </a>
                        @elseif (in_array($resource, ['invoices', 'opd-invoices', 'ipd-invoices'], true))
                            <a class="btn btn-success btn-sm" href="{{ route('invoices.print', $record) }}">
                                <i class="fas fa-print"></i> {{ __('Print') }}
                            </a>
                        @endif
                        @if(auth()->user()->hasPermission($resource.'.edit'))
                        <a class="btn btn-warning btn-sm" href="{{ route('masters.edit', [$resource, $record]) }}">
                            <i class="fas fa-edit"></i> {{ __('Edit') }}
                        </a>
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    @if ($resource === 'patients')
                        @include('admin.masters.partials.patient-profile', ['patient' => $record])
                    @else
                    <dl class="row">
                        @foreach ($config['fields'] as $name => $field)
                            @continue(($field['type'] ?? null) === 'password')
                            <dt class="col-sm-3">{{ __((string) $field['label']) }}</dt>
                            <dd class="col-sm-9">
                                @include('admin.masters.partials.display-value', ['record' => $record, 'name' => $name, 'field' => $field])
                            </dd>
                        @endforeach
                    </dl>
                    @endif

                    @if ($resource === 'lab-results')
                        @if($record->file_path)
                        <hr class="my-4">
                        <div class="card card-outline card-info">
                            <div class="card-header">
                                <h4 class="card-title"><i class="fas fa-paperclip mr-2"></i>{{ __('Attached File') }}</h4>
                                <div class="card-tools">
                                    <a href="{{ Storage::disk('public')->url($record->file_path) }}" target="_blank" class="btn btn-sm btn-outline-secondary" rel="noopener noreferrer">
                                        <i class="fas fa-external-link-alt mr-1"></i>{{ __('Open') }}
                                    </a>
                                </div>
                            </div>
                            <div class="card-body text-center p-0">
                                @if(in_array($record->file_type, ['jpg', 'jpeg', 'png', 'gif', 'webp']))
                                <a href="{{ Storage::disk('public')->url($record->file_path) }}" target="_blank" rel="noopener noreferrer">
                                    <img src="{{ Storage::disk('public')->url($record->file_path) }}"
                                         alt="Lab Result File"
                                         class="img-fluid"
                                         style="max-height:500px;object-fit:contain;cursor:zoom-in">
                                </a>
                                @else
                                <div class="py-5">
                                    <i class="fas fa-file-{{ $record->file_type === 'pdf' ? 'pdf' : 'alt' }} text-muted" style="font-size:64px"></i>
                                    <p class="mt-2 mb-0"><strong>{{ basename($record->file_path) }}</strong></p>
                                    <p class="text-muted small">{{ strtoupper($record->file_type) }} {{ __('file') }}</p>
                                    <a href="{{ Storage::disk('public')->url($record->file_path) }}" target="_blank" class="btn btn-info btn-sm" rel="noopener noreferrer">
                                        <i class="fas fa-download mr-1"></i>{{ __('Download') }}
                                    </a>
                                </div>
                                @endif
                            </div>
                        </div>
                        @endif

                        <hr class="my-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="mb-0"><i class="fas fa-flask mr-2"></i>{{ __('Result Items') }}</h4>
                            <span class="badge badge-{{ $record->status === 'completed' ? 'success' : ($record->status === 'pending' ? 'warning' : 'secondary') }} px-3 py-2">
                                {{ __(ucfirst($record->status)) }}
                            </span>
                        </div>
                        @if($record->items->isNotEmpty())
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>{{ __('Test') }}</th>
                                        <th>{{ __('Result Value') }}</th>
                                        <th>{{ __('Normal Range') }}</th>
                                        <th>{{ __('Flag') }}</th>
                                        <th>{{ __('Remarks') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($record->items as $item)
                                    @php
                                        $isAbnormal = $item->flag === 'abnormal' || $item->flag === 'critical';
                                        $flagClass = $item->flag === 'critical' ? 'danger' : ($item->flag === 'abnormal' ? 'warning' : 'success');
                                    @endphp
                                    <tr class="{{ $isAbnormal ? 'table-' . $flagClass : '' }}">
                                        <td><strong>{{ $item->test_name }}</strong></td>
                                        <td><strong>{{ $item->result_value }}</strong></td>
                                        <td><small class="text-muted">{{ $item->normal_range ?? '—' }} {{ $item->unit ?? '' }}</small></td>
                                        <td>
                                            @if($item->flag)
                                            <span class="badge badge-{{ $flagClass }}">{{ __(ucfirst($item->flag)) }}</span>
                                            @else
                                            <span class="text-muted">—</span>
                                            @endif
                                        </td>
                                        <td>{{ $item->remarks ?? '—' }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @else
                        <p class="text-muted text-center py-3">{{ __('No result items recorded.') }}</p>
                        @endif
                    @endif

                    @if ($resource === 'consultations')
                        @php
                            $prescriptionItems = $record->prescriptionItems;
                            if ($prescriptionItems->isEmpty() && $record->prescriptions->isNotEmpty()) {
                                $prescriptionItems = $record->prescriptions->flatMap(fn ($prescription) => $prescription->items);
                            }
                        @endphp

                        @if ($prescriptionItems->isNotEmpty())
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="card-title">{{ __('Prescribed Medicines') }}</h4>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>{{ __('Medicine') }}</th>
                                                <th>{{ __('Dosage') }}</th>
                                                <th>{{ __('Frequency') }}</th>
                                                <th>{{ __('Duration') }}</th>
                                                <th>{{ __('Quantity') }}</th>
                                                <th>{{ __('Instructions') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($prescriptionItems as $item)
                                                <tr>
                                                    <td>{{ $item->medicine_name }}</td>
                                                    <td>{{ $item->dosage }}</td>
                                                    <td>{{ $item->frequency }}</td>
                                                    <td>{{ $item->duration }}</td>
                                                    <td>{{ $item->quantity }}</td>
                                                    <td>{{ $item->instructions }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif

                        @if ($record->labRequestItems->isNotEmpty())
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="card-title">{{ __('Requested Lab Tests') }}</h4>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>{{ __('Lab Test') }}</th>
                                                <th>{{ __('Request Code') }}</th>
                                                <th>{{ __('Priority') }}</th>
                                                <th>{{ __('Status') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($record->labRequestItems as $item)
                                                <tr>
                                                    <td>{{ $item->test_name }}</td>
                                                    <td>{{ $item->labRequest->request_code ?? '-' }}</td>
                                                    <td>{{ __(ucfirst($item->labRequest?->priority ?? 'routine')) }}</td>
                                                    <td>{{ __(ucfirst($item->labRequest?->status ?? 'pending')) }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif
                    @endif

                    @if ($resource === 'patients')
                        @if ($record->consultations->isNotEmpty())
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="card-title">{{ __('Consultation History') }}</h4>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>{{ __('Date') }}</th>
                                                <th>{{ __('Doctor') }}</th>
                                                <th>{{ __('Chief Complaint') }}</th>
                                                <th>{{ __('Diagnosis / Plan') }}</th>
                                                <th>{{ __('Status') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($record->consultations->sortByDesc('consultation_date') as $consultation)
                                                <tr>
                                                    <td>{{ displayDate($consultation->consultation_date, 'Y-m-d') }}</td>
                                                    <td>{{ $consultation->doctor?->display_name ?? '-' }}</td>
                                                    <td>{{ $consultation->chief_complaint ?: '-' }}</td>
                                                    <td>{{ $consultation->treatment_plan ?: ($consultation->examination ?: '-') }}</td>
                                                    <td>{{ __(ucwords(str_replace('_', ' ', $consultation->status ?? ''))) }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif

                        @if ($record->prescriptions->isNotEmpty())
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="card-title">{{ __('Prescribed Medicines') }}</h4>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>{{ __('Date') }}</th>
                                                <th>{{ __('Prescription') }}</th>
                                                <th>{{ __('Medicine') }}</th>
                                                <th>{{ __('Dosage') }}</th>
                                                <th>{{ __('Frequency') }}</th>
                                                <th>{{ __('Duration') }}</th>
                                                <th>{{ __('Quantity') }}</th>
                                                <th>{{ __('Status') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($record->prescriptions->sortByDesc('prescription_date') as $prescription)
                                                @forelse($prescription->items as $item)
                                                    <tr>
                                                        <td>{{ displayDate($prescription->prescription_date, 'Y-m-d') }}</td>
                                                        <td>{{ $prescription->prescription_code }}</td>
                                                        <td>{{ $item->medicine_name }}</td>
                                                        <td>{{ $item->dosage }}</td>
                                                        <td>{{ filled($item->frequency) ? __(ucwords(str_replace('_', ' ', $item->frequency))) : '-' }}</td>
                                                        <td>{{ filled($item->duration) ? __($item->duration) : '-' }}</td>
                                                        <td>{{ $item->quantity }}</td>
                                                        <td>{{ __(ucwords(str_replace('_', ' ', $prescription->status ?? ''))) }}</td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td>{{ displayDate($prescription->prescription_date, 'Y-m-d') }}</td>
                                                        <td>{{ $prescription->prescription_code }}</td>
                                                        <td colspan="5">{{ __('No medicine items') }}</td>
                                                        <td>{{ __(ucwords(str_replace('_', ' ', $prescription->status ?? ''))) }}</td>
                                                    </tr>
                                                @endforelse
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif

                        @if ($record->labRequests->isNotEmpty())
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="card-title">{{ __('Requested Lab Tests') }}</h4>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>{{ __('Date') }}</th>
                                                <th>{{ __('Request Code') }}</th>
                                                <th>{{ __('Lab Test') }}</th>
                                                <th>{{ __('Priority') }}</th>
                                                <th>{{ __('Status') }}</th>
                                                <th>{{ __('Consultation') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($record->labRequests->sortByDesc('request_date') as $labRequest)
                                                @forelse($labRequest->items as $item)
                                                    <tr>
                                                        <td>{{ displayDate($labRequest->request_date, 'Y-m-d') }}</td>
                                                        <td>{{ $labRequest->request_code }}</td>
                                                        <td>{{ $item->test_name }}</td>
                                                        <td>{{ __(ucfirst($labRequest->priority ?? 'routine')) }}</td>
                                                        <td>{{ __(ucwords(str_replace('_', ' ', $labRequest->status ?? ''))) }}</td>
                                                        <td>{{ $labRequest->consultation?->display_name ?? '-' }}</td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td>{{ displayDate($labRequest->request_date, 'Y-m-d') }}</td>
                                                        <td>{{ $labRequest->request_code }}</td>
                                                        <td>{{ __('No lab test items') }}</td>
                                                        <td>{{ __(ucfirst($labRequest->priority ?? 'routine')) }}</td>
                                                        <td>{{ __(ucwords(str_replace('_', ' ', $labRequest->status ?? ''))) }}</td>
                                                        <td>{{ $labRequest->consultation?->display_name ?? '-' }}</td>
                                                    </tr>
                                                @endforelse
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif
                    @endif

                    @if ($resource === 'chart-of-accounts')
                        @php $txns = $record->journalEntryItems->sortBy('created_at'); @endphp
                        @if ($txns->isNotEmpty())
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="card-title">{{ __('Transactions') }}</h4>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>{{ __('Date') }}</th>
                                                <th>{{ __('Entry #') }}</th>
                                                <th>{{ __('Description') }}</th>
                                                <th class="text-right">{{ __('Debit') }}</th>
                                                <th class="text-right">{{ __('Credit') }}</th>
                                                <th class="text-right">{{ __('Balance') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @php $runningBalance = 0; @endphp
                                            @foreach($txns as $item)
                                                @php
                                                    $je = $item->journalEntry;
                                                    $isDebitPositive = in_array($record->type, ['Asset', 'Expense']);
                                                    $runningBalance += $isDebitPositive ? ($item->debit - $item->credit) : ($item->credit - $item->debit);
                                                @endphp
                                                <tr>
                                                    <td>{{ $je?->entry_date }}</td>
                                                    <td>{{ $je?->entry_number }}</td>
                                                    <td>{{ $je?->description }}</td>
                                                    <td class="text-right">{{ $item->debit > 0 ? number_format($item->debit, 2) : '-' }}</td>
                                                    <td class="text-right">{{ $item->credit > 0 ? number_format($item->credit, 2) : '-' }}</td>
                                                    <td class="text-right">{{ number_format($runningBalance, 2) }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
