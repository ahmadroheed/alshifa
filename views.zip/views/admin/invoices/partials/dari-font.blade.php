@if(app()->getLocale() === 'fa')
<style>
    @font-face { font-family: VazirmatnPrint; font-style: normal; font-weight: 400; src: url("{{ public_path('vendor/fonts/vazirmatn/Vazirmatn-Regular.ttf') }}") format('truetype'); }
    @font-face { font-family: VazirmatnPrint; font-style: normal; font-weight: 700; src: url("{{ public_path('vendor/fonts/vazirmatn/Vazirmatn-Bold.ttf') }}") format('truetype'); }
    html[dir=rtl] body { font-family: VazirmatnPrint, 'DejaVu Sans', sans-serif !important; direction: rtl; text-align: right; line-height: 1.9; }
    html[dir=rtl] th { text-align: right; letter-spacing: 0 !important; }
    html[dir=rtl] .invoice-meta { float: left; text-align: left; }
    html[dir=rtl] .totals { margin-right: auto; margin-left: 0; }
    html[dir=rtl] .value { direction: ltr; text-align: left; }
</style>
@endif
