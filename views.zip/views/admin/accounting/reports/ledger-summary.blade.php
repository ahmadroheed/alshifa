@extends('layouts.admin', ['title' => __('Ledger Summary')])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">{{ __('Ledger Summary') }}</h3>
                    <form method="get" action="{{ route('accounting.reports.ledger-summary') }}" class="form-inline">
                        <div class="input-group">
                            <select name="account_id" class="form-control">
                                <option value="">{{ __('Select Account') }}</option>
                                @foreach ($accounts as $account)
                                    <option value="{{ $account->id }}" {{ optional($selectedAccount)->id == $account->id ? 'selected' : '' }}>
                                        {{ $account->code }} - {{ $account->name }} ({{ __($account->type) }})
                                    </option>
                                @endforeach
                            </select>
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">{{ __('Filter') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    @if ($selectedAccount)
                        <div class="mb-3">
                            <strong>{{ __('Account') }}:</strong> {{ $selectedAccount->code }} - {{ $selectedAccount->name }}<br>
                            <strong>{{ __('Type') }}:</strong> {{ __($selectedAccount->type) }}<br>
                            <strong>{{ __('Running Balance') }}:</strong> {{ number_format($runningBalance, 2) }}
                        </div>
                    @endif

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>{{ __('Date') }}</th>
                                    <th>{{ __('Journal Entry') }}</th>
                                    <th>{{ __('Description') }}</th>
                                    <th>{{ __('Debit') }}</th>
                                    <th>{{ __('Credit') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($entries as $entry)
                                    <tr>
                                        <td>{{ displayDate($entry->journalEntry?->entry_date, 'Y-m-d') }}</td>
                                        <td>{{ optional($entry->journalEntry)->entry_number }}</td>
                                        <td>{{ $entry->description }}</td>
                                        <td>{{ number_format($entry->debit, 2) }}</td>
                                        <td>{{ number_format($entry->credit, 2) }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">{{ __('Choose an account to view ledger entries.') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
