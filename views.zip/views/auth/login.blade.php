<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{ app()->getLocale() === 'fa' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ __($system_settings['site_name'] ?? config('app.name', 'Laravel')) }}</title>
    <link rel="stylesheet" href="{{ asset('vendor/fonts/inter.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/fonts/material-icons.css') }}">
    <style>
        @php
            $loginPrimary = $system_settings['primary_color'] ?? '#2e7d32';
            $loginSecondary = $system_settings['secondary_color'] ?? '#1b5e20';
        @endphp
        :root { --primary: {{ $loginPrimary }}; --secondary: {{ $loginSecondary }}; }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            -webkit-font-smoothing: antialiased;
            background: #f5f5f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .m3-card {
            background: #ffffff;
            border-radius: 28px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 6px 24px rgba(0,0,0,0.04);
            width: 100%;
            max-width: 380px;
            padding: 48px 32px 36px;
            transition: box-shadow 0.3s;
        }

        .m3-logo {
            width: 48px;
            height: 48px;
            background: color-mix(in srgb, var(--primary) 15%, white);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }

        .m3-logo .material-icons {
            font-size: 24px;
            color: var(--primary);
        }

        .m3-title {
            text-align: center;
            margin-bottom: 32px;
        }

        .m3-title h1 {
            font-size: 22px;
            font-weight: 600;
            color: #1a1a1a;
            letter-spacing: -0.3px;
        }

        .m3-title p {
            font-size: 14px;
            color: #6b7280;
            margin-top: 4px;
        }

        .m3-field {
            margin-bottom: 20px;
        }

        .m3-field label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: #4b5563;
            margin-bottom: 6px;
            letter-spacing: 0.3px;
            text-transform: uppercase;
        }

        .m3-field .input-wrap {
            position: relative;
        }

        .m3-field .input-wrap .material-icons {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 18px;
            color: #9ca3af;
            pointer-events: none;
        }

        .m3-field input {
            width: 100%;
            height: 48px;
            padding: 0 14px 0 42px;
            font-size: 14px;
            font-family: inherit;
            color: #1a1a1a;
            background: #f3f4f6;
            border: 2px solid transparent;
            border-radius: 12px;
            outline: none;
            transition: all 0.2s;
        }

        .m3-field input::placeholder {
            color: #9ca3af;
        }

        .m3-field input:focus {
            background: #ffffff;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px color-mix(in srgb, var(--primary) 12%, transparent);
        }

        .m3-field .error-text {
            font-size: 12px;
            color: #dc2626;
            margin-top: 4px;
            display: block;
        }

        .m3-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .m3-check {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .m3-check input {
            width: 16px;
            height: 16px;
            border-radius: 4px;
            border: 2px solid #d1d5db;
            accent-color: var(--primary);
            cursor: pointer;
        }

        .m3-check span {
            font-size: 13px;
            color: #6b7280;
        }

        .m3-link {
            font-size: 13px;
            color: var(--primary);
            font-weight: 500;
            text-decoration: none;
        }

        .m3-link:hover {
            text-decoration: underline;
        }

        .m3-btn {
            width: 100%;
            height: 48px;
            border: none;
            border-radius: 100px;
            background: var(--primary);
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
            box-shadow: 0 1px 3px color-mix(in srgb, var(--primary) 15%, transparent);
        }

        .m3-btn:hover {
            background: var(--secondary);
            box-shadow: 0 4px 12px color-mix(in srgb, var(--primary) 25%, transparent);
        }

        .m3-btn:active {
            transform: scale(0.98);
        }

        .m3-btn .material-icons {
            font-size: 18px;
        }

        .m3-alert {
            padding: 12px 16px;
            background: color-mix(in srgb, var(--primary) 15%, white);
            border-radius: 12px;
            font-size: 13px;
            color: var(--primary);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .m3-alert .material-icons {
            font-size: 18px;
        }

        .m3-lang {
            position: fixed;
            top: 16px;
            right: 16px;
            display: flex;
            gap: 2px;
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 100px;
            padding: 3px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        }

        .m3-lang a {
            padding: 5px 14px;
            border-radius: 100px;
            font-size: 12px;
            font-weight: 500;
            color: #9ca3af;
            text-decoration: none;
            transition: all 0.2s;
        }

        .m3-lang a.active {
            background: var(--primary);
            color: #fff;
        }

        .m3-lang a:not(.active):hover {
            color: #4b5563;
        }

        .m3-footer {
            position: fixed;
            bottom: 24px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 11px;
            color: #9ca3af;
        }

        [dir="rtl"] .m3-lang { right: auto; left: 16px; }
        [dir="rtl"] .m3-field .input-wrap .material-icons { left: auto; right: 14px; }
        [dir="rtl"] .m3-field input { padding: 0 42px 0 14px; }
    </style>
    <link rel="stylesheet" href="{{ asset('vendor/fonts/dari.css') }}?v={{ filemtime(public_path('vendor/fonts/dari.css')) }}">
</head>
<body>
    <div class="m3-lang">
        <a href="{{ route('locale.switch', 'en') }}" class="{{ app()->getLocale() === 'en' ? 'active' : '' }}">EN</a>
        <a href="{{ route('locale.switch', 'fa') }}" class="{{ app()->getLocale() === 'fa' ? 'active' : '' }}">دری</a>
    </div>

    <div class="m3-card">
        <div class="m3-logo">
            <span class="material-icons">local_hospital</span>
        </div>

        <div class="m3-title">
            <h1>{{ __('Alshefa HMS') }}</h1>
            <p>{{ __('Sign in to continue') }}</p>
        </div>

        @if (session('status'))
            <div class="m3-alert">
                <span class="material-icons">check_circle</span>
                <span>{{ session('status') }}</span>
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}">
            @csrf

            <div class="m3-field">
                <label for="email">{{ __('Email') }}</label>
                <div class="input-wrap">
                    <span class="material-icons">email</span>
                    <input id="email" name="email" type="email" required autofocus autocomplete="username"
                           value="{{ old('email') }}" placeholder="{{ __('name@hospital.com') }}">
                </div>
                @error('email')
                    <span class="error-text">{{ $message }}</span>
                @enderror
            </div>

            <div class="m3-field">
                <label for="password">{{ __('Password') }}</label>
                <div class="input-wrap">
                    <span class="material-icons">lock</span>
                    <input id="password" name="password" type="password" required autocomplete="current-password"
                           placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;">
                </div>
                @error('password')
                    <span class="error-text">{{ $message }}</span>
                @enderror
            </div>

            <div class="m3-row">
                <label class="m3-check">
                    <input type="checkbox" name="remember">
                    <span>{{ __('Remember me') }}</span>
                </label>
                @if (Route::has('password.request'))
                    <a href="{{ route('password.request') }}" class="m3-link">{{ __('Forgot password?') }}</a>
                @endif
            </div>

            <button type="submit" class="m3-btn">
                <span class="material-icons">login</span>
                {{ __('Sign in') }}
            </button>
        </form>
    </div>

    <div class="m3-footer">
        &copy; {{ displayDate(now(), 'Y') }} {{ __('Alshefa HMS') }}. {{ __('All rights reserved.') }}
    </div>
</body>
</html>
