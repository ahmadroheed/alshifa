@extends('layouts.admin', ['title' => __('Accounting Reports')])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ __('Accounting Reports') }}</h3>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <div class="info-box bg-success">
                                <span class="info-box-icon"><i class="fas fa-hand-holding-usd"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{{ __('Cash Received') }}</span>
                                    <span class="info-box-number">{{ number_format($cashReceived, 2) }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="info-box bg-danger">
                                <span class="info-box-icon"><i class="fas fa-money-bill-wave"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{{ __('Cash Outflows') }}</span>
                                    <span class="info-box-number">{{ number_format($cashOutflows, 2) }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="info-box bg-primary">
                                <span class="info-box-icon"><i class="fas fa-chart-line"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{{ __('Net Cash Flow') }}</span>
                                    <span class="info-box-number">{{ number_format($netCash, 2) }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="info-box bg-warning">
                                <span class="info-box-icon"><i class="fas fa-file-invoice-dollar"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{{ __('Total Receivables') }}</span>
                                    <span class="info-box-number">{{ number_format($totalReceivables, 2) }}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <a href="{{ route('accounting.reports.ledger-summary') }}" class="btn btn-outline-primary btn-block">{{ __('Ledger Summary') }}</a>
                        </div>
                        <div class="col-md-4 mb-3">
                            <a href="{{ route('accounting.reports.trial-balance') }}" class="btn btn-outline-secondary btn-block">{{ __('Trial Balance') }}</a>
                        </div>
                        <div class="col-md-4 mb-3">
                            <a href="{{ route('accounting.reports.cashflow') }}" class="btn btn-outline-success btn-block">{{ __('Cashflow Report') }}</a>
                        </div>
                        <div class="col-md-4 mb-3">
                            <a href="{{ route('accounting.reports.payables') }}" class="btn btn-outline-danger btn-block">{{ __('Payables Report') }}</a>
                        </div>
                        <div class="col-md-4 mb-3">
                            <a href="{{ route('accounting.reports.receivables') }}" class="btn btn-outline-info btn-block">{{ __('Receivables Report') }}</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <h5>{{ __('Top Liability Accounts') }}</h5>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>{{ __('Account') }}</th>
                                            <th>{{ __('Debit') }}</th>
                                            <th>{{ __('Credit') }}</th>
                                            <th>{{ __('Balance') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($payableAccounts as $item)
                                            <tr>
                                                <td>{{ $item['account']->code }} - {{ $item['account']->name }}</td>
                                                <td>{{ number_format($item['debit'], 2) }}</td>
                                                <td>{{ number_format($item['credit'], 2) }}</td>
                                                <td>{{ number_format($item['balance'], 2) }}</td>
                                            </tr>
                                        @empty
                                            <tr><td colspan="4">{{ __('No liability accounts found.') }}</td></tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <h5>{{ __('Top Income / Expense Accounts') }}</h5>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>{{ __('Account') }}</th>
                                            <th>{{ __('Type') }}</th>
                                            <th>{{ __('Debit') }}</th>
                                            <th>{{ __('Credit') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($incomeAccounts->merge($expenseAccounts) as $item)
                                            <tr>
                                                <td>{{ $item['account']->code }} - {{ $item['account']->name }}</td>
                                                <td>{{ __($item['account']->type) }}</td>
                                                <td>{{ number_format($item['debit'], 2) }}</td>
                                                <td>{{ number_format($item['credit'], 2) }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
