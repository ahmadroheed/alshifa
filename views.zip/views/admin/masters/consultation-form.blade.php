@extends('layouts.admin', ['title' => $config['title'], 'resource' => $resource])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ $record->exists ? __('Edit') : __('Create') }} {{ __($config['title']) }}</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="{{ $record->exists ? route('masters.update', [$resource, $record]) : route('masters.store', $resource) }}" id="consultation-form">
                        @csrf
                        @if ($record->exists)
                            @method('put')
                        @endif

                        @if(empty($options['patient_visit_id'] ?? []))
                            <div class="alert alert-warning">
                                <h5><i class="icon fas fa-exclamation-triangle"></i> {{ __('No Patient Visits Available') }}</h5>
                                <p>{{ __('All patient visits already have consultations. Please ensure new patient visits are created before attempting to create consultations.') }}</p>
                                <a href="{{ route('masters.index', 'patient-visits') }}" class="btn btn-primary">{{ __('View Patient Visits') }}</a>
                            </div>
                        @endif

                        <div class="row" @if(empty($options['patient_visit_id'] ?? [])) style="pointer-events: none; opacity: 0.5;" @endif>
                            @foreach ($config['fields'] as $name => $field)
                                @php
                                    $type = $field['type'] ?? 'text';
                                    $value = old($name, data_get($record, $name));
                                    if (!old($name) && isset($field['value'])) $value = $field['value'];
                                    if (($field['derived_from'] ?? null) === 'insurance' && old($name, null) === null) {
                                        $hasInsurance = data_get($record, 'insurance_company_id')
                                            || data_get($record, 'insurance_policy_number')
                                            || data_get($record, 'patient_type') === 'insured';
                                        $value = $hasInsurance ? '1' : '0';
                                    }
                                    if (! old($name) && $value instanceof \Illuminate\Support\Carbon) {
                                        $value = $type === 'datetime-local' ? $value->format('Y-m-d\TH:i') : $value->format('Y-m-d');
                                    }
                                    $isWide = in_array($type, ['textarea', 'multiselect', 'checkbox_group'], true);
                                    $selectedRelationIds = [];
                                    if (in_array($type, ['multiselect', 'checkbox_group'], true) && ! empty($field['relation']) && $record->exists) {
                                        $selectedRelationIds = $record->{$field['relation']}()->pluck('id')->map(fn ($id) => (string) $id)->all();
                                    }
                                    if (($field['derived_from'] ?? null) === 'permission_action' && old($name, null) === null) {
                                        $permissionName = data_get($record, 'name', '');
                                        $selectedRelationIds = str_contains($permissionName, '.') ? [str($permissionName)->afterLast('.')->toString()] : [];
                                    }
                                @endphp

                                <div
                                    class="col-md-{{ $isWide ? 12 : 6 }} mb-3"
                                    @if (! empty($field['show_if']))
                                        data-show-if-field="{{ $field['show_if']['field'] }}"
                                        data-show-if-value="{{ $field['show_if']['value'] }}"
                                    @endif
                                >
                                    <label for="{{ $name }}" class="form-label">{{ __((string) $field['label']) }}</label>

                                    @if ($type === 'textarea')
                                        <textarea id="{{ $name }}" name="{{ $name }}" class="form-control" rows="3">{{ $value }}</textarea>
                                    @elseif ($type === 'date')
                                        <input type="hidden" id="{{ $name }}" name="{{ $name }}" value="{{ $value }}">
                                        <input
                                            id="{{ $name }}_shamsi"
                                            type="text"
                                            class="form-control shamsi-datepicker"
                                            data-alt-field="#{{ $name }}"
                                            @if(! empty($field['readonly'])) readonly @endif
                                            @if(! empty($field['disabled'])) disabled @endif
                                        >
                                    @elseif ($type === 'select')
                                        @php
                                            $selectOptions = $field['choices'] ?? $options[$name] ?? [];
                                        @endphp
                                        @if (! empty($field['readonly']))
                                            <input type="hidden" id="{{ $name }}" name="{{ $name }}" value="{{ $value }}">
                                            <input type="text" class="form-control" value="{{ $selectOptions[$value] ?? $value }}" readonly @if(! empty($field['disabled'])) disabled @endif>
                                        @else
                                            <input type="hidden" id="{{ $name }}" name="{{ $name }}" value="{{ $value }}">
                                            <select id="{{ $name }}" name="{{ $name }}" class="form-control select2bs4" @if(! empty($field['disabled'])) disabled @endif>
                                                <option value="">{{ __('Select') }}</option>
                                                @if (filled($value) && ! in_array((string) $value, array_map('strval', array_keys($selectOptions)), true))
                                                    <option value="{{ $value }}" selected>{{ __($value) }}</option>
                                                @endif
                                                @foreach ($selectOptions as $optionValue => $optionLabel)
                                                    <option value="{{ $optionValue }}" @selected((string) $value === (string) $optionValue)>{{ __($optionLabel) }}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    @elseif ($type === 'multiselect')
                                        <select id="{{ $name }}" name="{{ $name }}[]" class="form-control select2bs4" multiple>
                                            @foreach (($options[$name] ?? []) as $optionValue => $optionLabel)
                                                <option value="{{ $optionValue }}" @selected(in_array((string) $optionValue, old($name, $selectedRelationIds), true))>{{ __($optionLabel) }}</option>
                                            @endforeach
                                        </select>
                                    @elseif ($type === 'checkbox_group')
                                        @php
                                            $checkedValues = array_map('strval', old($name, $selectedRelationIds));
                                            $checkboxOptions = $field['choices'] ?? $options[$name] ?? [];
                                            $isGrouped = collect($checkboxOptions)->contains(fn ($option) => is_array($option));
                                        @endphp

                                        <div class="border rounded p-3 bg-light">
                                            @if ($isGrouped)
                                                @foreach ($checkboxOptions as $group => $groupOptions)
                                                    <div class="mb-3">
                                                        <div class="font-weight-bold mb-2">{{ __(str($group)->replace('-', ' ')->title()->toString()) }}</div>
                                                        <div class="row">
                                                            @foreach ($groupOptions as $optionValue => $optionLabel)
                                                                <div class="col-md-4 col-sm-6 mb-2">
                                                                    <div class="form-check">
                                                                        <input id="{{ $name }}_{{ $optionValue }}" class="form-check-input" type="checkbox" name="{{ $name }}[]" value="{{ $optionValue }}" @checked(in_array((string) $optionValue, $checkedValues, true))>
                                                                        <label class="form-check-label" for="{{ $name }}_{{ $optionValue }}">{{ __((string) $optionLabel) }}</label>
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @else
                                                <div class="row">
                                                    @foreach ($checkboxOptions as $optionValue => $optionLabel)
                                                        <div class="col-md-4 col-sm-6 mb-2">
                                                            <div class="form-check">
                                                                <input id="{{ $name }}_{{ $optionValue }}" class="form-check-input" type="checkbox" name="{{ $name }}[]" value="{{ $optionValue }}" @checked(in_array((string) $optionValue, $checkedValues, true))>
                                                                <label class="form-check-label" for="{{ $name }}_{{ $optionValue }}">{{ __((string) $optionLabel) }}</label>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                                    @elseif ($type === 'checkbox')
                                        <div class="form-check">
                                            <input id="{{ $name }}" type="checkbox" name="{{ $name }}" value="1" class="form-check-input" @checked(old($name, $value))>
                                            <label class="form-check-label" for="{{ $name }}">{{ __((string) $field['label']) }}</label>
                                        </div>
                                    @else
                                        <input
                                            id="{{ $name }}"
                                            type="{{ $type }}"
                                            name="{{ $name }}"
                                            value="{{ $type === 'password' ? '' : $value }}"
                                            class="form-control"
                                            @if($type === 'number') step="0.01" @endif
                                            @if(! empty($field['readonly'])) readonly @endif
                                            @if(! empty($field['disabled'])) disabled @endif
                                        >
                                    @endif

                                    @if (! empty($field['help']))
                                        <div class="form-text">{{ __((string) $field['help']) }}</div>
                                    @endif
                                </div>
                            @endforeach
                        </div>

                        <!-- Medicines Section -->
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0">{{ __('Prescribed Medicines') }}</h5>
                                    </div>
                                    <div class="card-body">
                                        <div id="medicines-container">
                                            @php
                                                $existingMedicines = $record->exists ? $record->prescriptionItems : collect();
                                                if ($existingMedicines->isEmpty() && $record->exists) {
                                                    $existingMedicines = $record->prescriptions->flatMap(fn ($prescription) => $prescription->items);
                                                }
                                            @endphp
                                            @foreach($existingMedicines as $medicineItem)
                                                <div class="medicine-item border rounded p-3 mb-3 bg-light">
                                                    <div class="row">
                                                        <div class="col-md-3">
                                                            <label class="form-label">{{ __('Medicine') }}</label>
                                                            <select name="medicines[][medicine_id]" class="form-control medicine-select select2bs4" required>
                                                                <option value="">{{ __('Select Medicine') }}</option>
                                                                @foreach($medicines ?? [] as $medicine)
                                                                    <option value="{{ $medicine->id }}" @selected($medicineItem->medicine_id === $medicine->id)>{{ $medicine->name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label class="form-label">{{ __('Dosage') }}</label>
                                                            <input type="text" name="medicines[][dosage]" class="form-control" value="{{ $medicineItem->dosage }}" placeholder="{{ __('e.g., 500mg') }}" required>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label class="form-label">{{ __('Frequency') }}</label>
                                                            <input type="text" name="medicines[][frequency]" class="form-control" value="{{ $medicineItem->frequency }}" placeholder="{{ __('e.g., 3 times daily') }}" required>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label class="form-label">{{ __('Duration') }}</label>
                                                            <input type="text" name="medicines[][duration]" class="form-control" value="{{ $medicineItem->duration }}" placeholder="{{ __('e.g., 7 days') }}" required>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label class="form-label">{{ __('Quantity') }}</label>
                                                            <input type="number" name="medicines[][quantity]" class="form-control" value="{{ $medicineItem->quantity }}" min="1" required>
                                                        </div>
                                                        <div class="col-md-1 d-flex align-items-end">
                                                            <button type="button" class="btn btn-danger btn-sm remove-medicine">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="row mt-2">
                                                        <div class="col-md-12">
                                                            <label class="form-label">{{ __('Instructions') }}</label>
                                                            <textarea name="medicines[][instructions]" class="form-control" rows="2" placeholder="{{ __('Special instructions...') }}">{{ $medicineItem->instructions }}</textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                        <button type="button" class="btn btn-outline-primary btn-sm" id="add-medicine-btn">
                                            <i class="fas fa-plus"></i> {{ __('Add Medicine') }}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Lab Tests Section -->
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0">{{ __('Requested Lab Tests') }}</h5>
                                    </div>
                                    <div class="card-body">
                                        <div id="lab-tests-container">
                                            @php
                                                $existingLabTests = $record->exists ? $record->labRequestItems : collect();
                                            @endphp
                                            @foreach($existingLabTests as $labTestItem)
                                                <div class="lab-test-item border rounded p-3 mb-3 bg-light">
                                                    <div class="row">
                                                        <div class="col-md-5">
                                                            <label class="form-label">{{ __('Lab Test') }}</label>
                                                            <select name="lab_tests[][lab_test_id]" class="form-control lab-test-select select2bs4" required>
                                                                <option value="">{{ __('Select Lab Test') }}</option>
                                                                @foreach($labTests ?? [] as $test)
                                                                    <option value="{{ $test->id }}" @selected($labTestItem->lab_test_id === $test->id)>{{ $test->name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">{{ __('Priority') }}</label>
                                                            <select name="lab_tests[][priority]" class="form-control select2bs4">
                                                                <option value="routine" @selected($labTestItem->labRequest?->priority === 'routine')>{{ __('Routine') }}</option>
                                                                <option value="urgent" @selected($labTestItem->labRequest?->priority === 'urgent')>{{ __('Urgent') }}</option>
                                                                <option value="stat" @selected($labTestItem->labRequest?->priority === 'stat')>{{ __('STAT') }}</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <label class="form-label">{{ __('Clinical Notes') }}</label>
                                                            <textarea name="lab_tests[][clinical_notes]" class="form-control" rows="2" placeholder="{{ __('Clinical notes...') }}">{{ $labTestItem->labRequest?->clinical_notes }}</textarea>
                                                        </div>
                                                        <div class="col-md-1 d-flex align-items-end">
                                                            <button type="button" class="btn btn-danger btn-sm remove-lab-test">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                        <button type="button" class="btn btn-outline-primary btn-sm" id="add-lab-test-btn">
                                            <i class="fas fa-plus"></i> {{ __('Add Lab Test') }}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group mt-4 text-right">
                            @if(!empty($options['patient_visit_id'] ?? []))
                            <button class="btn btn-primary mr-2" type="submit">
                                <i class="fas fa-save"></i> {{ __('Save') }}
                            </button>
                            @endif
                            <a class="btn btn-secondary" href="{{ route('masters.index', $resource) }}">
                                <i class="fas fa-times"></i> {{ __('Cancel') }}
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Medicine Template -->
    <script type="text/template" id="medicine-template">
        <div class="medicine-item border rounded p-3 mb-3 bg-light">
            <div class="row">
                <div class="col-md-3">
                    <label class="form-label">{{ __('Medicine') }}</label>
                    <select name="medicines[][medicine_id]" class="form-control medicine-select select2bs4" required>
                        <option value="">{{ __('Select Medicine') }}</option>
                        @foreach($medicines ?? [] as $medicine)
                            <option value="{{ $medicine->id }}">{{ $medicine->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">{{ __('Dosage') }}</label>
                    <input type="text" name="medicines[][dosage]" class="form-control" placeholder="{{ __('e.g., 500mg') }}" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">{{ __('Frequency') }}</label>
                    <input type="text" name="medicines[][frequency]" class="form-control" placeholder="{{ __('e.g., 3 times daily') }}" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">{{ __('Duration') }}</label>
                    <input type="text" name="medicines[][duration]" class="form-control" placeholder="{{ __('e.g., 7 days') }}" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label">{{ __('Quantity') }}</label>
                    <input type="number" name="medicines[][quantity]" class="form-control" min="1" required>
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <button type="button" class="btn btn-danger btn-sm remove-medicine">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-12">
                    <label class="form-label">{{ __('Instructions') }}</label>
                    <textarea name="medicines[][instructions]" class="form-control" rows="2" placeholder="{{ __('Special instructions...') }}"></textarea>
                </div>
            </div>
        </div>
    </script>

    <!-- Lab Test Template -->
    <script type="text/template" id="lab-test-template">
        <div class="lab-test-item border rounded p-3 mb-3 bg-light">
            <div class="row">
                <div class="col-md-5">
                    <label class="form-label">{{ __('Lab Test') }}</label>
                    <select name="lab_tests[][lab_test_id]" class="form-control lab-test-select select2bs4" required>
                        <option value="">{{ __('Select Lab Test') }}</option>
                        @foreach($labTests ?? [] as $test)
                            <option value="{{ $test->id }}">{{ $test->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">{{ __('Priority') }}</label>
                    <select name="lab_tests[][priority]" class="form-control select2bs4">
                        <option value="routine">{{ __('Routine') }}</option>
                        <option value="urgent">{{ __('Urgent') }}</option>
                        <option value="stat">{{ __('STAT') }}</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">{{ __('Clinical Notes') }}</label>
                    <textarea name="lab_tests[][clinical_notes]" class="form-control" rows="2" placeholder="{{ __('Clinical notes...') }}"></textarea>
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <button type="button" class="btn btn-danger btn-sm remove-lab-test">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    </script>

    <script>
        // Wait for jQuery to be loaded
        function initializeConsultationForm() {
            if (typeof $ === 'undefined') {
                setTimeout(initializeConsultationForm, 100);
                return;
            }

            $(document).ready(function() {
                const conditionalFields = document.querySelectorAll('[data-show-if-field]');
                const medicineTemplate = document.getElementById('medicine-template').innerHTML;
                const labTestTemplate = document.getElementById('lab-test-template').innerHTML;
                const $medicinesContainer = $('#medicines-container');
                const $labTestsContainer = $('#lab-tests-container');

                // Conditional fields logic
                conditionalFields.forEach((wrapper) => {
                    const controller = document.querySelector(`[name="${wrapper.dataset.showIfField}"]`);
                    const inputs = wrapper.querySelectorAll('input, select, textarea');

                    if (! controller) {
                        return;
                    }

                    const updateVisibility = () => {
                        const shouldShow = controller.value === wrapper.dataset.showIfValue;

                        wrapper.style.display = shouldShow ? '' : 'none';
                        inputs.forEach((input) => {
                            input.disabled = ! shouldShow;
                        });
                    };

                    controller.addEventListener('change', updateVisibility);
                    updateVisibility();
                });

                // Function to initialize Select2 on a container
                function initializeSelect2($container) {
                    $container.find('select.select2bs4').not('.select2-hidden-accessible').each(function() {
                        $(this).select2({
                            theme: 'bootstrap4',
                            width: '100%'
                        });
                    });
                }

                // Add medicine functionality
                $('#add-medicine-btn').on('click', function(e) {
                    e.preventDefault();
                    $medicinesContainer.append(medicineTemplate);

                    // Initialize select2 for the new medicine select
                    const $newMedicineItem = $medicinesContainer.children().last();
                    initializeSelect2($newMedicineItem);
                });

                // Add lab test functionality
                $('#add-lab-test-btn').on('click', function(e) {
                    e.preventDefault();
                    $labTestsContainer.append(labTestTemplate);

                    // Initialize select2 for the new lab test selects
                    const $newLabTestItem = $labTestsContainer.children().last();
                    initializeSelect2($newLabTestItem);
                });

                // Remove medicine functionality
                $(document).on('click', '.remove-medicine', function(e) {
                    e.preventDefault();
                    $(this).closest('.medicine-item').remove();
                });

                // Remove lab test functionality
                $(document).on('click', '.remove-lab-test', function(e) {
                    e.preventDefault();
                    $(this).closest('.lab-test-item').remove();
                });

                // Form validation before submission
                $('form').on('submit', function(e) {
                    let isValid = true;
                    let errorMessages = [];

                    // Validate medicine entries
                    $('.medicine-item').each(function(index) {
                        const $item = $(this);
                        const medicineId = $item.find('select[name="medicines[][medicine_id]"]').val();
                        const dosage = $item.find('input[name="medicines[][dosage]"]').val();
                        const frequency = $item.find('input[name="medicines[][frequency]"]').val();
                        const duration = $item.find('input[name="medicines[][duration]"]').val();
                        const quantity = $item.find('input[name="medicines[][quantity]"]').val();

                        if (!medicineId || !dosage || !frequency || !duration || !quantity) {
                            isValid = false;
                            errorMessages.push(@json(__('Medicine #:number: All fields are required')).replace(':number', index + 1));
                            $item.addClass('border-danger');
                        } else {
                            $item.removeClass('border-danger');
                        }
                    });

                    // Validate lab test entries
                    $('.lab-test-item').each(function(index) {
                        const $item = $(this);
                        const labTestId = $item.find('select[name="lab_tests[][lab_test_id]"]').val();

                        if (!labTestId) {
                            isValid = false;
                            errorMessages.push(@json(__('Lab Test #:number: Lab test selection is required')).replace(':number', index + 1));
                            $item.addClass('border-danger');
                        } else {
                            $item.removeClass('border-danger');
                        }
                    });

                    if (!isValid) {
                        e.preventDefault();
                        alert(@json(__('Please complete all medicine and lab test fields or remove incomplete entries.')) + '\n\n' + errorMessages.join('\n'));
                        return false;
                    }

                    return true;
                });

                // Initialize existing consultation selects
                initializeSelect2($medicinesContainer);
                initializeSelect2($labTestsContainer);
            });
        }

        // Start initialization
        initializeConsultationForm();
    </script>
@endsection