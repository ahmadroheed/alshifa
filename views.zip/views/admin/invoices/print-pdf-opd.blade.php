<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{ app()->getLocale() === 'fa' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ __('OPD Invoice') }} {{ $invoice->invoice_number }}</title>
    <style>
        @page { size: A4 portrait; margin: 7mm; }
        body { font-family: 'DejaVu Sans', sans-serif; margin: 0; padding: 0; color: #1a1a2e; font-size: 9px; line-height: 1.25; }
        .invoice-copy { page-break-inside: avoid; break-inside: avoid; border-bottom: 1px dashed #888; margin-bottom: 3mm; }
        .copy-label { margin-bottom: 3px; color: #555; font-size: 8px; font-weight: 700; letter-spacing: .8px; text-transform: uppercase; }
        .header { border-bottom: 1px solid #e8e8e8; padding-bottom: 5px; margin-bottom: 8px; }
        .header-inner { width: 100%; }
        .brand { display: inline-block; }
        .brand h1 { font-size: 14px; margin: 0; color: #1a1a2e; }
        .brand .subtitle { font-size: 9px; color: #666; margin: 2px 0 0; }
        .invoice-meta { float: right; text-align: right; }
        .invoice-meta .number { font-size: 12px; font-weight: 700; margin: 0; }
        .status { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 8px; font-weight: 700; text-transform: uppercase; }
        .status.paid { background: #e6f7ed; color: #0d6832; }
        .status.partial { background: #fff8e1; color: #8d6200; }
        .status.unpaid { background: #fce8e6; color: #b3261e; }
        .info-section { margin-bottom: 8px; }
        .info-section table { width: 100%; }
        .info-section td { vertical-align: top; padding: 0; }
        .info-section h3 { font-size: 8px; text-transform: uppercase; letter-spacing: 1px; color: #888; margin: 0 0 3px; }
        .info-section .name { font-size: 11px; font-weight: 600; }
        .info-section .detail { font-size: 9px; color: #555; margin-top: 1px; }
        table.items { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
        table.items thead th { font-size: 8px; text-transform: uppercase; letter-spacing: .8px; color: #888; padding: 4px 6px; text-align: left; border-bottom: 1px solid #e8e8e8; }
        table.items thead th.right { text-align: right; }
        table.items thead th.center { text-align: center; }
        table.items tbody td { padding: 3px 6px; border-bottom: 1px solid #f0f0f0; font-size: 9px; }
        table.items tbody td.right { text-align: right; }
        table.items tbody td.center { text-align: center; }
        .totals { width: 250px; margin-left: auto; }
        .totals table { width: 100%; }
        .totals td { padding: 2px 0; font-size: 9px; }
        .totals td.label { color: #666; }
        .totals td.value { text-align: right; font-weight: 500; }
        .totals tr.total td { border-top: 1px solid #e8e8e8; padding-top: 4px; }
        .totals tr.total td.label { font-weight: 600; color: #1a1a2e; font-size: 11px; }
        .totals tr.total td.value { font-weight: 700; color: #1a1a2e; font-size: 12px; }
        .totals tr.paid td { color: #0d6832; font-weight: 600; }
        .totals tr.due td { color: #b3261e; font-weight: 600; }
        .footer { border-top: 1px solid #f0f0f0; padding-top: 5px; margin-top: 5px; font-size: 8px; color: #666; text-align: center; }
        .clearfix::after { content: ''; display: table; clear: both; }
    </style>
    <link rel="stylesheet" href="{{ asset('vendor/fonts/dari.css') }}?v={{ filemtime(public_path('vendor/fonts/dari.css')) }}">
@include('admin.invoices.partials.dari-font')
</head>
<body>
    @foreach ([__('Patient Copy'), __('Hospital Copy')] as $copyLabel)
    <div class="invoice-copy">
    <div class="header clearfix">
        <div class="brand">
            <div class="copy-label">{{ $copyLabel }}</div>
            <h1>{{ setting('site_name', __('Alshefa HMS')) }}</h1>
            <div class="subtitle">{{ __('OPD Invoice') }}</div>
        </div>
        <div class="invoice-meta">
            <div class="status {{ $invoice->status }}">{{ __(str($invoice->status)->replace('_', ' ')->title()->toString()) }}</div>
            <p class="number">{{ $invoice->invoice_number }}</p>
        </div>
    </div>

    <div class="info-section">
        <table>
            <tr>
                <td style="width: 50%;">
                    <h3>{{ __('Patient') }}</h3>
                    <div class="name">{{ $invoice->patient?->display_name ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('MRN') }}:</strong> {{ $invoice->patient?->mrn ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Phone') }}:</strong> {{ $invoice->patient?->phone ?? __('Not set') }}</div>
                </td>
                <td style="width: 50%; text-align: right;">
                    <h3>{{ __('Invoice Details') }}</h3>
                    <div class="detail"><strong>{{ __('Type') }}:</strong> {{ __($invoice->invoice_type) }}</div>
                    <div class="detail"><strong>{{ __('Visit') }}:</strong> {{ $invoice->patientVisit?->visit_code ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Doctor') }}:</strong> {{ $invoice->patientVisit?->doctor?->display_name ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Department') }}:</strong> {{ $invoice->patientVisit?->department?->name ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Created By') }}:</strong> {{ $invoice->createdBy?->name ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Date') }}:</strong> {{ displayDate($invoice->created_at, 'Y-m-d H:i') }}</div>
                </td>
            </tr>
        </table>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th>{{ __('Description') }}</th>
                <th class="center">{{ __('Qty') }}</th>
                <th class="right">{{ __('Unit Price') }}</th>
                <th class="right">{{ __('Total') }}</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($invoice->items as $item)
                <tr>
                    <td>{{ $item->description }}</td>
                    <td class="center">{{ $item->quantity }}</td>
                    <td class="right">{{ number_format((float) $item->unit_price, 2) }}</td>
                    <td class="right">{{ number_format((float) $item->total, 2) }}</td>
                </tr>
            @empty
                <tr><td colspan="4" style="text-align:center;color:#888;padding:20px;">{{ __('No items') }}</td></tr>
            @endforelse
        </tbody>
    </table>

    <div class="totals">
        <table>
            <tr><td class="label">{{ __('Subtotal') }}</td><td class="value">{{ number_format((float) $invoice->subtotal, 2) }}</td></tr>
            <tr><td class="label">{{ __('Discount') }}</td><td class="value">{{ number_format((float) $invoice->discount, 2) }}</td></tr>
            @php $paymentDiscount = $invoice->payments->where('status', 'completed')->sum('discount_amount'); @endphp
            @if ($paymentDiscount > 0)
            <tr><td class="label" style="color:#888;">{{ __('Payment Discount') }}</td><td class="value" style="color:#888;">-{{ number_format((float) $paymentDiscount, 2) }}</td></tr>
            @endif
            <tr><td class="label">{{ __('Tax') }}</td><td class="value">{{ number_format((float) $invoice->tax, 2) }}</td></tr>
            <tr class="total"><td class="label">{{ __('Total') }}</td><td class="value">{{ number_format((float) $invoice->total, 2) }}</td></tr>
            <tr class="paid"><td class="label">{{ __('Paid Amount') }}</td><td class="value">{{ number_format((float) $invoice->paid_amount, 2) }}</td></tr>
            <tr class="due"><td class="label">{{ __('Due Amount') }}</td><td class="value">{{ number_format((float) $invoice->due_amount, 2) }}</td></tr>
        </table>
    </div>

    <div class="footer">{{ __('Thank you for your visit') }} — {{ setting('footer_text', '') }}</div>
    </div>
    @endforeach
</body>
</html>
