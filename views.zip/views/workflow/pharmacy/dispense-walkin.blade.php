@php $title = __('Dispense - :name', ['name' => $visit->patient->full_name]); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-8">
        <form id="dispense-form">
            @csrf
            <div class="card card-success">
                <div class="card-header"><h3 class="card-title"><i class="fas fa-pills"></i> {{ __('Dispense Medicine') }}</h3></div>
                <div class="card-body">
                    <div class="callout callout-info">
                        <h5><i class="fas fa-file-invoice"></i> {{ __('Paid Invoice') }}: {{ $invoice->invoice_number }}</h5>
                        <p class="mb-0">{{ __('Total Paid') }}: <strong>{{ number_format($invoice->total, 2) }} {{ __('AFN') }}</strong></p>
                    </div>

                    <div class="form-group">
                        <label>{{ __('Select Medicine') }}</label>
                        <select class="form-control select2" id="medicine-select" style="width:100%">
                            <option value="">{{ __('Select Medicine') }}</option>
                            @foreach ($medicines as $m)
                                <option value="{{ $m->id }}" data-batches='@json($m->batches->map(fn($b)=>["id"=>$b->id,"sale_price"=>$b->sale_price,"stock"=>$b->remaining_quantity,"batch_number"=>$b->batch_number]))'>
                                    {{ $m->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <table class="table table-sm table-bordered" id="items-table">
                        <thead>
                            <tr>
                                <th>{{ __('Medicine') }}</th>
                                <th>{{ __('Batch') }}</th>
                                <th>{{ __('Price') }}</th>
                                <th>{{ __('Qty') }}</th>
                                <th>{{ __('Total') }}</th>
                                <th>{{ __('Action') }}</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                        <tfoot>
                            <tr class="font-weight-bold">
                                <td colspan="4" class="text-right">{{ __('Total') }}:</td>
                                <td id="grand-total">0.00 {{ __('AFN') }}</td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>

                    <button type="submit" class="btn btn-success btn-lg mt-2"><i class="fas fa-check"></i> {{ __('Confirm Dispense') }}</button>
                    <a href="{{ route('workflow.pharmacy.pending') }}" class="btn btn-default btn-lg mt-2">{{ __('Cancel') }}</a>
                </div>
            </div>
        </form>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><h3 class="card-title">{{ __('Patient Info') }}</h3></div>
            <div class="card-body">
                <dl>
                    <dt>{{ __('Name') }}</dt><dd><strong>{{ $visit->patient->full_name }}</strong></dd>
                    <dt>{{ __('MRN') }}</dt><dd>{{ $visit->patient->mrn }}</dd>
                    <dt>{{ __('Phone') }}</dt><dd>{{ $visit->patient->phone }}</dd>
                    <dt>{{ __('Gender') }}</dt><dd>{{ __(ucfirst($visit->patient->gender)) }}</dd>
                    <dt>{{ __('Visit Code') }}</dt><dd>{{ $visit->visit_code }}</dd>
                </dl>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3 class="card-title">{{ __('Invoice Items') }}</h3></div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    @foreach($invoice->items as $item)
                    <li class="list-group-item d-flex justify-content-between">
                        <span>{{ $item->service->name }}</span>
                        <span>{{ number_format($item->total, 2) }} {{ __('AFN') }}</span>
                    </li>
                    @endforeach
                    <li class="list-group-item d-flex justify-content-between font-weight-bold">
                        <span>{{ __('Total') }}</span>
                        <span>{{ number_format($invoice->total, 2) }} {{ __('AFN') }}</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

@push('js')
<script>
$(document).ready(function() {
    $('.select2').select2({theme: 'bootstrap4'});
    var items = [];
    var idx = 0;

    $('#medicine-select').on('change', function() {
        var id = $(this).val();
        if (!id) return;
        var opt = $(this).find('option:selected');
        var name = opt.text();
        var batches = opt.data('batches') || [];
        if (!batches.length) { alert(@json(__('No stock available for this medicine.'))); $(this).val('').trigger('change'); return; }
        if (items.some(function(i) { return i.medicine_id == id; })) { alert(@json(__('Already added.'))); $(this).val('').trigger('change'); return; }
        items.push({ index: idx, medicine_id: id, name: name, batches: batches, selected_batch: batches[0]?.id || '', qty: 1 });
        renderTable();
        idx++;
        $(this).val('').trigger('change');
    });

    function renderTable() {
        var tbody = $('#items-table tbody');
        tbody.empty();
        var grandTotal = 0;
        items.forEach(function(item) {
            var batch = item.batches.find(function(b) { return b.id == item.selected_batch; });
            var price = batch ? parseFloat(batch.sale_price) : 0;
            var total = price * item.qty;
            grandTotal += total;
            var batchOpts = item.batches.map(function(b) {
                return '<option value="'+b.id+'" '+(b.id == item.selected_batch ? 'selected' : '')+'>'+b.batch_number+' ('+b.stock+' @ '+parseFloat(b.sale_price).toFixed(2)+')</option>';
            }).join('');
            tbody.append(
                '<tr>' +
                '<td>'+item.name+'<input type="hidden" name="items['+item.index+'][medicine_id]" value="'+item.medicine_id+'"></td>' +
                '<td><select class="form-control form-control-sm batch-select" data-idx="'+item.index+'">'+batchOpts+'</select></td>' +
                '<td>'+price.toFixed(2)+'</td>' +
                '<td><input type="number" class="form-control form-control-sm qty-input" data-idx="'+item.index+'" value="'+item.qty+'" min="1" max="'+(batch ? batch.stock : 0)+'" style="width:80px"></td>' +
                '<td>'+total.toFixed(2)+' {{ __('AFN') }}</td>' +
                '<td><button type="button" class="btn btn-sm btn-danger remove-item" data-idx="'+item.index+'"><i class="fas fa-times"></i></button></td>' +
                '</tr>'
            );
        });
        $('#grand-total').text(grandTotal.toFixed(2)+' {{ __('AFN') }}');
    }

    $(document).on('change', '.batch-select', function() {
        var idx = $(this).data('idx');
        var item = items.find(function(i) { return i.index == idx; });
        if (item) { item.selected_batch = $(this).val(); renderTable(); }
    });

    $(document).on('change', '.qty-input', function() {
        var idx = $(this).data('idx');
        var item = items.find(function(i) { return i.index == idx; });
        if (item) { item.qty = parseInt($(this).val()) || 1; renderTable(); }
    });

    $(document).on('click', '.remove-item', function() {
        var idx = $(this).data('idx');
        items = items.filter(function(i) { return i.index != idx; });
        renderTable();
    });

    $('#dispense-form').on('submit', function(e) {
        e.preventDefault();
        if (!items.length) { alert(@json(__('Please add at least one medicine.'))); return; }
        var formData = $(this).serialize();
        var btn = $(this).find('button[type="submit"]').html('<i class="fas fa-spinner fa-spin"></i> {{ __('Processing...') }}').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.pharmacy.dispense-walkin", $visit->id) }}',
            method: 'POST',
            data: formData,
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function(xhr) {
                var msg = '<div class="alert alert-danger"><ul>';
                var errors = xhr.responseJSON?.errors;
                if (errors) { $.each(errors, function(k,v) { msg += '<li>'+v[0]+'</li>'; }); }
                else { msg += '<li>Error processing request.</li>'; }
                msg += '</ul></div>';
                if (!$('#dispense-form .alert-danger').length) $('#dispense-form').prepend(msg);
                btn.html('<i class="fas fa-check"></i> Confirm Dispense').prop('disabled', false);
            }
        });
    });
});
</script>
@endpush
@endsection