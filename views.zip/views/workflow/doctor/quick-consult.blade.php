@php $title = __('Quick Action - :name', ['name' => $visit->patient->full_name]); @endphp
@extends('layouts.admin')
@section('content')
<div class="card card-success">
    <div class="card-body py-3">
        <div class="row align-items-center">
            <div class="col-lg-4">
                <div class="d-flex align-items-center">
                    <div class="mr-3">
                        <span class="fa-stack fa-lg text-success">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fas fa-bolt fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div>
                        <div class="text-muted small">{{ __('Patient') }}</div>
                        <h4 class="mb-0">{{ $visit->patient->full_name }}</h4>
                        <div class="text-muted small">{{ $visit->patient->mrn }} | {{ $visit->visit_code }}</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row">
                    <div class="col-4">
                        <div class="description-block border-right">
                            <span class="description-text">{{ __('Gender') }}</span>
                            <h5 class="description-header">{{ __(ucfirst($visit->patient->gender)) }}</h5>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="description-block border-right">
                            <span class="description-text">{{ __('Age') }}</span>
                            <h5 class="description-header">{{ $visit->patient->date_of_birth?->age ?? __('N/A') }}</h5>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="description-block">
                            <span class="description-text">{{ __('Phone') }}</span>
                            <h5 class="description-header">{{ $visit->patient->phone ?: '-' }}</h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 text-lg-right">
                <h5 class="mb-0 text-success">{{ __('Consultation Fee') }}: <strong>{{ number_format($charge->consultation_fee, 2) }} {{ __('AFN') }}</strong></h5>
            </div>
        </div>
    </div>
</div>

<form id="quick-consult-form">
    @csrf
    <div class="row">
        <div class="col-md-8">
            <div class="card card-success">
                <div class="card-header"><h3 class="card-title"><i class="fas fa-notes-medical"></i> {{ __('Clinical Note') }}</h3></div>
                <div class="card-body">
                    <div class="form-group">
                        <label>{{ __('Chief Complaint') }} <span class="text-danger">*</span></label>
                        <textarea name="chief_complaint" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>{{ __('Diagnosis') }}</label>
                        <textarea name="diagnosis" class="form-control" rows="2" placeholder="{{ __('Enter diagnosis') }}"></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-warning">
                <div class="card-header"><h3 class="card-title"><i class="fas fa-money-bill-wave"></i> {{ __('Charges') }}</h3></div>
                <div class="card-body">
                    <div class="form-group">
                        <label>{{ __('Consultation Fee') }}</label>
                        <div class="input-group">
                            <input type="text" class="form-control" value="{{ number_format($charge->consultation_fee, 2) }}" readonly>
                            <div class="input-group-append"><span class="input-group-text">{{ __('AFN') }}</span></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>{{ __('Additional Amount') }} <small class="text-muted">({{ __('optional') }})</small></label>
                        <div class="input-group">
                            <input type="number" name="additional_amount" class="form-control" min="0" step="0.01" value="0" id="additional-amount">
                            <div class="input-group-append"><span class="input-group-text">{{ __('AFN') }}</span></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>{{ __('Discount') }} <small class="text-muted">({{ __('optional') }})</small></label>
                        <div class="input-group">
                            <input type="number" name="discount_amount" class="form-control" min="0" step="0.01" value="0" id="discount-amount">
                            <div class="input-group-append"><span class="input-group-text">{{ __('AFN') }}</span></div>
                        </div>
                    </div>
                    <hr>
                    <div class="form-group mb-0">
                        <label class="font-weight-bold text-success">{{ __('Total to Collect') }}</label>
                        <h3 class="text-success font-weight-bold" id="total-display">{{ number_format($charge->consultation_fee, 2) }} {{ __('AFN') }}</h3>
                    </div>
                </div>
            </div>

            <div class="card card-info">
                <div class="card-header"><h3 class="card-title"><i class="fas fa-sticky-note"></i> {{ __('Notes') }}</h3></div>
                <div class="card-body">
                    <div class="form-group mb-0">
                        <textarea name="notes" class="form-control" rows="3" placeholder="{{ __('Additional notes...') }}"></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-md-12">
            <button type="submit" class="btn btn-success btn-lg"><i class="fas fa-save"></i> {{ __('Save & Send to Collection') }}</button>
            <a href="{{ route('workflow.quick-action.pending') }}" class="btn btn-default btn-lg">{{ __('Cancel') }}</a>
        </div>
    </div>
</form>
@endsection

@push('js')
<script>
$(document).ready(function() {
    var consultationFee = {{ $charge->consultation_fee }};

    function updateTotal() {
        var additional = parseFloat($('#additional-amount').val()) || 0;
        var discount = parseFloat($('#discount-amount').val()) || 0;
        var total = Math.max(0, consultationFee + additional - discount);
        $('#total-display').text(total.toFixed(2) + ' {{ __('AFN') }}');
    }

    $('#additional-amount, #discount-amount').on('input', updateTotal);

    $('#quick-consult-form').on('submit', function(e) {
        e.preventDefault();
        var btn = $(this).find('button[type="submit"]');
        btn.html('<i class="fas fa-spinner fa-spin"></i> {{ __("Saving...") }}').prop('disabled', true);

        $.ajax({
            url: '{{ route("workflow.quick-action.save", $visit->id) }}',
            method: 'POST',
            data: $(this).serialize(),
            success: function(res) {
                if (res.success) window.location.href = res.redirect;
            },
            error: function(xhr) {
                var errors = xhr.responseJSON?.errors;
                var msg = '<div class="alert alert-danger"><ul>';
                if (errors) { $.each(errors, function(k,v) { msg += '<li>'+v[0]+'</li>'; }); }
                else { msg += '<li>' + (xhr.responseJSON?.message || '{{ __("Something went wrong.") }}') + '</li>'; }
                msg += '</ul></div>';
                $('#quick-consult-form .alert-danger').remove();
                $('#quick-consult-form').prepend(msg);
                btn.html('<i class="fas fa-save"></i> {{ __("Save & Send to Collection") }}').prop('disabled', false);
            }
        });
    });
});
</script>
@endpush