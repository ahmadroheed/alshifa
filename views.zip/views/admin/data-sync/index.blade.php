@extends('layouts.admin', ['title' => __('Data Synchronization')])

@section('content')
<div class="sync-page">
    <div class="sync-hero">
        <div><div class="sync-hero__icon"><i class="fas fa-cloud-upload-alt"></i></div><div><h2>{{ __('Local to Online Synchronization') }}</h2><p>{{ __('Securely upload changed local records to the online system.') }}</p></div></div>
        <span class="sync-state sync-state--{{ $connection->enabled ? 'on' : 'off' }}"><i class="fas fa-circle"></i> {{ $connection->enabled ? __('Automatic Sync Enabled') : __('Automatic Sync Disabled') }}</span>
    </div>

    <div class="row mt-3">
        <div class="col-lg-8 mb-3">
            <div class="card h-100"><div class="card-header"><h3 class="card-title"><i class="fas fa-cog mr-2"></i>{{ __('Connection Settings') }}</h3></div>
                <form method="POST" action="{{ route('data-sync.update', $connection) }}">@csrf @method('PUT')
                    <div class="card-body"><div class="row">
                        <div class="col-md-6"><div class="form-group"><label>{{ __('Local Instance Name') }}</label><input class="form-control" name="instance_name" value="{{ old('instance_name', $connection->instance_name) }}" required></div></div>
                        <div class="col-md-6"><div class="form-group"><label>{{ __('Instance ID') }}</label><input class="form-control" value="{{ $connection->instance_uuid }}" readonly></div></div>
                        <div class="col-12"><div class="form-group"><label>{{ __('Online System URL') }}</label><input class="form-control" type="url" name="remote_url" value="{{ old('remote_url', $connection->remote_url) }}" placeholder="https://online.example.com" required><small class="form-text text-muted">{{ __('Use HTTPS in production. Do not include /api/sync in the URL.') }}</small></div></div>
                        <div class="col-12"><div class="form-group"><label>{{ __('Synchronization API Token') }}</label><input class="form-control" type="password" name="api_token" autocomplete="new-password" placeholder="{{ $connection->api_token ? __('Token saved — leave blank to keep it') : __('Enter the token configured on the online server') }}"></div></div>
                        <div class="col-md-6"><div class="form-group"><label>{{ __('Sync Interval (minutes)') }}</label><input class="form-control" type="number" name="interval_minutes" min="5" max="1440" value="{{ old('interval_minutes', $connection->interval_minutes) }}" required></div></div>
                        <div class="col-md-6"><div class="form-group"><label>{{ __('Batch Size') }}</label><input class="form-control" type="number" name="batch_size" min="10" max="1000" value="{{ old('batch_size', $connection->batch_size) }}" required></div></div>
                        <div class="col-12"><div class="custom-control custom-switch"><input type="hidden" name="enabled" value="0"><input class="custom-control-input" type="checkbox" id="enabled" name="enabled" value="1" @checked($connection->enabled)><label class="custom-control-label" for="enabled">{{ __('Enable automatic synchronization') }}</label></div></div>
                    </div></div>
                    <div class="card-footer bg-white d-flex flex-wrap gap-2"><button class="btn btn-primary mr-2"><i class="fas fa-save mr-1"></i>{{ __('Save Settings') }}</button></form>
                    <form method="POST" action="{{ route('data-sync.test', $connection) }}" class="d-inline mr-2">@csrf<button class="btn btn-outline-info"><i class="fas fa-plug mr-1"></i>{{ __('Test Connection') }}</button></form>
                    <form method="POST" action="{{ route('data-sync.run', $connection) }}" class="d-inline">@csrf<button class="btn btn-success"><i class="fas fa-sync-alt mr-1"></i>{{ __('Sync Now') }}</button></form></div>
            </div>
        </div>
        <div class="col-lg-4 mb-3"><div class="card h-100"><div class="card-header"><h3 class="card-title"><i class="fas fa-heartbeat mr-2"></i>{{ __('Synchronization Status') }}</h3></div><div class="card-body sync-summary">
            <div><span>{{ __('Last Successful Sync') }}</span><strong>{{ $connection->last_success_at ? displayDate($connection->last_success_at, 'Y-m-d H:i') : __('Never') }}</strong></div>
            <div><span>{{ __('Last Attempt') }}</span><strong>{{ $connection->last_attempt_at ? displayDate($connection->last_attempt_at, 'Y-m-d H:i') : __('Never') }}</strong></div>
            <div><span>{{ __('Online Destination') }}</span><strong class="text-break">{{ $connection->remote_url ?: __('Not configured') }}</strong></div>
            @if($connection->last_error)<div class="alert alert-danger mb-0"><strong>{{ __('Last Error') }}</strong><br>{{ $connection->last_error }}</div>@endif
            <div class="alert alert-info mb-0"><i class="fas fa-shield-alt mr-1"></i>{{ __('Online records are stored by instance and source ID, preventing one facility from overwriting another.') }}</div>
        </div></div></div>
    </div>

    <div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-history mr-2"></i>{{ __('Synchronization History') }}</h3></div><div class="card-body p-0 table-responsive"><table class="table mb-0"><thead><tr><th>{{ __('Started') }}</th><th>{{ __('Trigger') }}</th><th>{{ __('Status') }}</th><th>{{ __('Found') }}</th><th>{{ __('Sent') }}</th><th>{{ __('Failed') }}</th><th>{{ __('Started By') }}</th><th>{{ __('Message') }}</th></tr></thead><tbody>
    @forelse($runs as $run)<tr><td>{{ displayDate($run->started_at, 'Y-m-d H:i') }}</td><td>{{ __(ucfirst($run->trigger)) }}</td><td><span class="badge badge-{{ $run->status === 'completed' ? 'success' : ($run->status === 'failed' ? 'danger' : 'warning') }}">{{ __(ucfirst($run->status)) }}</span></td><td>{{ $run->records_found }}</td><td>{{ $run->records_sent }}</td><td>{{ $run->records_failed }}</td><td>{{ $run->startedBy?->name ?? __('System') }}</td><td class="text-danger">{{ $run->error_message }}</td></tr>@empty<tr><td colspan="8" class="text-center py-4 text-muted">{{ __('No synchronization runs yet.') }}</td></tr>@endforelse
    </tbody></table></div><div class="card-footer">{{ $runs->links('vendor.pagination.bootstrap-4') }}</div></div>
</div>
@endsection

@push('css')<style>
.sync-hero{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:1.4rem 1.5rem;border-radius:20px;color:#fff;background:linear-gradient(125deg,var(--secondary),var(--primary));box-shadow:0 10px 28px rgba(46,125,50,.2)}.sync-hero>div{display:flex;align-items:center;gap:1rem}.sync-hero__icon{display:grid;place-items:center;width:58px;height:58px;border-radius:17px;background:rgba(255,255,255,.16);font-size:1.35rem}.sync-hero h2{margin:0 0 .2rem;font-size:1.35rem;font-weight:800}.sync-hero p{margin:0;opacity:.82}.sync-state{padding:.48rem .75rem;border-radius:20px;font-size:.78rem;font-weight:700;background:rgba(255,255,255,.15)}.sync-state i{font-size:.55rem;margin-inline-end:.25rem}.sync-state--on i{color:#a5d6a7}.sync-state--off i{color:#ffcc80}.sync-summary>div:not(.alert){display:flex;justify-content:space-between;gap:1rem;padding:.8rem 0;border-bottom:1px dashed #e4ebe8}.sync-summary span{color:#78909c;font-size:.82rem}.sync-summary strong{text-align:end;color:#37474f;font-size:.85rem}.sync-summary .alert{margin-top:1rem;border:0;border-radius:12px;font-size:.82rem}@media(max-width:767px){.sync-hero{align-items:flex-start;flex-direction:column}.sync-hero__icon{display:none}}
</style>@endpush
