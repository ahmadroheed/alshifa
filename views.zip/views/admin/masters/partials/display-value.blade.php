@php
    $type = $field['type'] ?? null;
    $value = data_get($record, $name);
    $displayValue = $value;

    if (in_array($type, ['multiselect', 'checkbox_group'], true) && ! empty($field['relation'])) {
        $displayValue = $record->{$field['relation']}->pluck($field['options'][1])->join(', ');
    } elseif (($field['derived_from'] ?? null) === 'permission_action') {
        $action = str((string) data_get($record, 'name'))->afterLast('.')->toString();
        $displayValue = $field['choices'][$action] ?? $action;
    } elseif ($type === 'checkbox') {
        $displayValue = $record->{$name} ? 'Yes' : 'No';
    } elseif ($type === 'file' && filled($value)) {
        $disk = $field['disk'] ?? 'public';
        $url = Storage::disk($disk)->url($value);
        $displayValue = '<a href="' . $url . '" target="_blank" rel="noopener noreferrer">' . basename($value) . '</a>';
    } elseif (isset($field['choices'])) {
        $displayValue = $field['choices'][$value] ?? $value;
    } elseif (isset($field['options'][0], $field['options'][1])) {
        $relatedModel = $field['options'][0];
        $displayColumn = $field['options'][1];
        $related = null;
        $relationNames = [];

        if (str_ends_with($name, '_id')) {
            $relationNames[] = \Illuminate\Support\Str::camel(\Illuminate\Support\Str::beforeLast($name, '_id'));
        } elseif (str_ends_with($name, '_by')) {
            $relationNames[] = \Illuminate\Support\Str::camel($name);
        }

        foreach ($relationNames as $relationName) {
            if ($record->relationLoaded($relationName)) {
                $related = $record->getRelation($relationName);
                break;
            }
        }

        if (! $related) {
            $related = collect($record->getRelations())
                ->first(fn ($relation) => $relation instanceof \Illuminate\Database\Eloquent\Model && $relation instanceof $relatedModel);
        }

        $displayValue = $related ? data_get($related, $displayColumn, $value) : $value;
    } elseif ($name === 'patient_visit_id' && $record->relationLoaded('patientVisit')) {
        $displayValue = $record->patientVisit->visit_code ?? $value;
    } elseif ($name === 'value' && $record->offsetExists('type')) {
        $settingType = $record->type;
        $displayValue = match ($settingType) {
            'color' => filled($value) ? '<span class="d-inline-block align-middle" style="width:24px;height:24px;border-radius:4px;border:1px solid #ccc;background:' . e($value) . ';margin-right:6px"></span> <code>' . e($value) . '</code>' : null,
            'boolean' => $value === '1' || $value === 1 || $value === true ? __('Yes') : __('No'),
            'file', 'image' => filled($value) ? '<a href="' . e(Storage::disk('public')->url($value)) . '" target="_blank" rel="noopener noreferrer">' . e(basename($value)) . '</a>' : null,
            'url' => filled($value) ? '<a href="' . e($value) . '" target="_blank" rel="noopener noreferrer">' . e($value) . '</a>' : null,
            'email' => filled($value) ? '<a href="mailto:' . e($value) . '">' . e($value) . '</a>' : null,
            'json' => filled($value) ? '<pre class="mb-0" style="max-height:120px;overflow:auto;font-size:12px">' . e(json_encode(json_decode($value), JSON_PRETTY_PRINT)) . '</pre>' : null,
            default => filled($value) ? e($value) : null,
        };
    }
@endphp

@if ($name === 'value' && $record->offsetExists('type') && filled($displayValue) && str_starts_with(trim($displayValue), '<'))
    {!! $displayValue !!}
@elseif ($type === 'file' && filled($displayValue))
    {!! $displayValue !!}
@else
    {{ filled($displayValue) ? __((string) $displayValue) : __('Not set') }}
@endif
