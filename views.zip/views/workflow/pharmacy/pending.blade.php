@php $title = __('Pharmacy Workflow'); @endphp
@extends('layouts.admin')
@section('content')
@if($pharmacyVisits->count())
<div class="row">
    <div class="col-md-12"><div class="card card-success">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-shopping-cart"></i> {{ __('Direct Pharmacy Requests (Walk-in)') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <thead><tr><th>{{ __('Visit Code') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Phone') }}</th><th>{{ __('Date') }}</th><th>{{ __('Action') }}</th></tr></thead>
                <tbody>@foreach($pharmacyVisits as $v)<tr>
                    <td>{{ $v->visit_code }}</td>
                    <td><strong>{{ $v->patient->full_name }}</strong></td>
                    <td>{{ $v->patient->phone }}</td>
                    <td>{{ displayDate($v->created_at, 'Y-m-d H:i') }}</td>
                    <td><a href="{{ route('workflow.pharmacy.dispense-walkin', $v->id) }}" class="btn btn-success btn-sm"><i class="fas fa-pills"></i> {{ __('Dispense') }}</a></td>
                </tr>@endforeach</tbody>
            </table>
        </div>
    </div></div>
</div>
@endif

<div class="row mt-3">
    <div class="col-md-12"><div class="card card-info">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-prescription"></i> {{ __('Prescriptions Ready to Dispense') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <thead><tr><th>{{ __('Prescription') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Doctor') }}</th><th>{{ __('Items') }}</th><th>{{ __('Date') }}</th><th>{{ __('Action') }}</th></tr></thead>
                <tbody>@forelse($pendingPrescriptions as $p)<tr>
                    <td>{{ $p->prescription_code }}</td>
                    <td><strong>{{ $p->consultation->patientVisit->patient->full_name }}</strong></td>
                    <td>{{ $p->consultation->doctor?->employee?->full_name ?? 'N/A' }}</td>
                    <td><ul class="list-unstyled mb-0">@foreach($p->items as $item)<li>{{ $item->medicine_name }} x {{ $item->quantity }} ({{ $item->dosage }} {{ $item->frequency }})</li>@endforeach</ul></td>
                    <td>{{ displayDate($p->prescription_date, 'Y-m-d') }}</td>
                    <td><button class="btn btn-success btn-sm dispense-btn" data-prescription="{{ $p->id }}"><i class="fas fa-pills"></i> {{ __('Dispense') }}</button></td>
                </tr>@empty<tr><td colspan="6" class="text-center text-muted">{{ __('No prescriptions ready for dispensing') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>

<div class="row mt-3">
    <div class="col-md-6"><div class="card">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-check-circle"></i> {{ __('Dispensed Today') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Sale') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Total') }}</th><th>{{ __('Status') }}</th></tr></thead>
                <tbody>@forelse($completedSales as $s)<tr>
                    <td>{{ $s->sale_code }}</td>
                    <td>{{ $s->patientVisit->patient->full_name }}</td>
                    <td>{{ number_format($s->total_amount, 2) }}</td>
                    <td><span class="badge badge-success">{{ __(ucfirst($s->flow_status)) }}</span></td>
                </tr>@empty<tr><td colspan="4" class="text-center text-muted">{{ __('No dispensing today') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>

@push('js')
<script>
$(document).ready(function() {
    $('.dispense-btn').on('click', function() {
        var btn = $(this);
        var id = btn.data('prescription');
        if (!confirm(@json(__('Dispense this prescription?')))) return;
        btn.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.pharmacy.dispense", "__ID__") }}'.replace('__ID__', id),
            method: 'POST',
            data: {_token: '{{ csrf_token() }}'},
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function() { alert(@json(__('Error dispensing.'))); btn.html('<i class="fas fa-pills"></i> {{ __('Dispense') }}').prop('disabled', false); }
        });
    });
});
</script>
@endpush
@endsection
