@php $title = __('Consultation - :name', ['name' => $visit->patient->full_name]); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-8"><div class="card card-primary">
        <div class="card-header"><h3 class="card-title">{{ __('Patient') }}: {{ $visit->patient->full_name }} ({{ $visit->patient->mrn }})</h3></div>
        <div class="card-body">
            @if($invoice)
            <div class="alert alert-success">
                <h5><i class="fas fa-check-circle"></i> {{ __('Invoice Generated') }}</h5>
                <p>{{ __('Invoice #') }}: <strong>{{ $invoice->invoice_number }}</strong> | {{ __('Total') }}: <strong>{{ number_format($invoice->total, 2) }} {{ __('AFN') }}</strong></p>
                <a href="{{ route('invoices.print', $invoice->id) }}" class="btn btn-primary"><i class="fas fa-print"></i> {{ __('Print Bill') }}</a>
                <button class="btn btn-success confirm-payment" data-invoice="{{ $invoice->id }}"><i class="fas fa-check"></i> {{ __('Confirm Payment & Refer to Doctor') }}</button>
            </div>
            @else
            <form id="consultation-bill-form" method="POST" action="{{ route('workflow.reception.generate-bill', $visit->id) }}">
                @csrf
                <div class="callout callout-info">
                    <h5><i class="fas fa-info-circle"></i> {{ __('Consultation Fee') }}</h5>
                    <p class="mb-0">{{ __('Doctor') }}: <strong>{{ $visit->doctor?->employee?->full_name ?? 'N/A' }}</strong></p>
                    <p class="mb-0">{{ __('Consultation Fee') }}: <strong>{{ number_format($visit->doctor?->consultation_fee ?? 0, 2) }} {{ __('AFN') }}</strong></p>
                    <input type="hidden" name="registration_fee" value="{{ $visit->doctor?->consultation_fee ?? 0 }}">
                </div>
                <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-file-invoice"></i> {{ __('Generate Consultation Bill') }}</button>
            </form>
            @endif
        </div>
    </div></div>
    <div class="col-md-4">
        <div class="card"><div class="card-header"><h3 class="card-title">{{ __('Patient Info') }}</h3></div>
            <div class="card-body">
                <dl><dt>{{ __('Name') }}</dt><dd>{{ $visit->patient->full_name }}</dd><dt>{{ __('MRN') }}</dt><dd>{{ $visit->patient->mrn }}</dd><dt>{{ __('Phone') }}</dt><dd>{{ $visit->patient->phone }}</dd><dt>{{ __('Doctor') }}</dt><dd>{{ $visit->doctor?->employee?->full_name ?? 'N/A' }}</dd><dt>{{ __('Visit Code') }}</dt><dd>{{ $visit->visit_code }}</dd></dl>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="bankModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">{{ __('Select Bank Account') }}</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <div class="form-group">
                    <label>{{ __('Bank Account') }}</label>
                    <select id="bank_account_id" class="form-control">
                        <option value="">{{ __('Cash (On Hand)') }}</option>
                        @foreach($bankAccounts as $ba)
                            <option value="{{ $ba->id }}">{{ $ba->account_name }} ({{ $ba->bank_name }} - {{ $ba->account_number }})</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-success" id="confirmCollect">{{ __('Confirm & Collect') }}</button>
            </div>
        </div>
    </div>
</div>

@push('js')
<script>
$(document).ready(function() {
    var pendingInvoiceId = null;

    $('#consultation-bill-form').on('submit', function(e) {
        e.preventDefault();
        var btn = $(this).find('button[type="submit"]').html('<i class="fas fa-spinner fa-spin"></i> Generating...').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.reception.generate-bill", $visit->id) }}',
            method: 'POST',
            data: $(this).serialize(),
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function(xhr) { alert(@json(__('Error:')) + ' ' + (xhr.responseJSON?.message || xhr.statusText || @json(__('Unknown'))) + '\n' + (xhr.responseJSON?.exception || '')); btn.html('<i class="fas fa-file-invoice"></i> {{ __("Generate Consultation Bill") }}').prop('disabled', false); }
        });
    });

    $(document).on('click', '.confirm-payment', function() {
        pendingInvoiceId = $(this).data('invoice');
        $('#bankModal').modal('show');
    });

    $('#confirmCollect').on('click', function() {
        if (!pendingInvoiceId) return;
        $('#confirmCollect').html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.reception.confirm-payment", ["invoice" => "__INVOICE__"]) }}'.replace('__INVOICE__', pendingInvoiceId),
            method: 'POST',
            data: {_token: '{{ csrf_token() }}', bank_account_id: $('#bank_account_id').val()},
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function() { alert('{{ __("Error processing payment.") }}'); $('#confirmCollect').html('{{ __("Confirm & Collect") }}').prop('disabled', false); $('#bankModal').modal('hide'); }
        });
    });
});
</script>
@endpush
@endsection
