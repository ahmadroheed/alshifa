@php $title = __('Quick Action - Collections'); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card card-success">
            <div class="card-header"><h3 class="card-title"><i class="fas fa-bolt"></i> {{ __('Quick Action - Pending Collections') }}</h3></div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>{{ __('Patient') }}</th>
                            <th>{{ __('MRN') }}</th>
                            <th>{{ __('Doctor') }}</th>
                            <th>{{ __('Consultation Fee') }}</th>
                            <th>{{ __('Additional') }}</th>
                            <th>{{ __('Discount') }}</th>
                            <th>{{ __('Total') }}</th>
                            <th>{{ __('Action') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($visits as $v)
                        @php $charge = $v->quickActionCharge; @endphp
                        <tr>
                            <td><strong>{{ $v->patient->full_name }}</strong></td>
                            <td>{{ $v->patient->mrn }}</td>
                            <td>{{ $v->doctor?->employee?->full_name ?? __('N/A') }}</td>
                            <td>{{ number_format($charge?->consultation_fee ?? 0, 2) }}</td>
                            <td>{{ number_format($charge?->additional_amount ?? 0, 2) }}</td>
                            <td class="text-danger">-{{ number_format($charge?->discount_amount ?? 0, 2) }}</td>
                            <td><strong class="text-success">{{ number_format($charge?->total_amount ?? 0, 2) }} {{ __('AFN') }}</strong></td>
                            <td>
                                <button class="btn btn-success btn-sm collect-btn" data-visit="{{ $v->id }}">
                                    <i class="fas fa-check"></i> {{ __('Collect') }}
                                </button>
                                <a href="{{ route('workflow.quick-action.print', $v->id) }}" class="btn btn-info btn-sm" target="_blank">
                                    <i class="fas fa-print"></i>
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="8" class="text-center text-muted">{{ __('No pending quick action collections') }}</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if($visits->hasPages())<div class="card-footer clearfix">{{ $visits->links('vendor.pagination.bootstrap-4') }}</div>@endif
        </div>
    </div>
</div>

<div class="row mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><h3 class="card-title"><i class="fas fa-check-circle"></i> {{ __("Today's Collections") }}</h3></div>
            <div class="card-body">
                <h4 class="text-success">{{ number_format($totalToday, 2) }} AFN {{ __('Collected Today') }}</h4>
                <div class="table-responsive mt-2">
                    <table class="table table-sm">
                        <thead><tr><th>{{ __('Patient') }}</th><th>{{ __('Amount') }}</th><th>{{ __('Time') }}</th></tr></thead>
                        <tbody>
                            @forelse($recentCollections as $p)
                            <tr>
                                <td>{{ $p->invoice?->patientVisit?->patient?->full_name ?? __('N/A') }}</td>
                                <td>{{ number_format($p->amount, 2) }} {{ __('AFN') }}</td>
                                <td>{{ displayDate($p->created_at, 'H:i') }}</td>
                            </tr>
                            @empty
                            <tr><td colspan="3" class="text-center text-muted">{{ __('No collections today') }}</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="bankModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">{{ __('Collect Payment') }}</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <div class="form-group">
                    <label>{{ __('Discount') }} <small class="text-muted">({{ __('optional') }})</small></label>
                    <div class="input-group">
                        <input type="number" id="discount_amount" class="form-control" min="0" step="0.01" value="0" placeholder="0.00">
                        <div class="input-group-append"><span class="input-group-text">{{ __('AFN') }}</span></div>
                    </div>
                </div>
                <div class="form-group">
                    <label>{{ __('Bank Account') }}</label>
                    <select id="bank_account_id" class="form-control">
                        <option value="">{{ __('Cash (On Hand)') }}</option>
                        @foreach($bankAccounts as $ba)
                            <option value="{{ $ba->id }}">{{ $ba->account_name }} ({{ $ba->bank_name }} - {{ $ba->account_number }})</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-success" id="confirmCollect">{{ __('Confirm & Collect') }}</button>
            </div>
        </div>
    </div>
</div>

@push('js')
<script>
$(document).ready(function() {
    var pendingVisitId = null;

    $('.collect-btn').on('click', function() {
        pendingVisitId = $(this).data('visit');
        $('#bankModal').modal('show');
    });

    $('#confirmCollect').on('click', function() {
        if (!pendingVisitId) return;
        $('#confirmCollect').html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.quick-action.collect", ["visit" => "__VISIT__"]) }}'.replace('__VISIT__', pendingVisitId),
            method: 'POST',
            data: {_token: '{{ csrf_token() }}', bank_account_id: $('#bank_account_id').val(), discount_amount: $('#discount_amount').val()},
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function() { alert('{{ __("Error processing payment.") }}'); $('#confirmCollect').html('{{ __("Confirm & Collect") }}').prop('disabled', false); $('#bankModal').modal('hide'); }
        });
    });
});
</script>
@endpush
@endsection