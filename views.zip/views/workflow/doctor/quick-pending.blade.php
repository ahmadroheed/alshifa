@php $title = __('Quick Action - My Patients'); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-12"><div class="card card-success">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-bolt"></i> {{ __('Pending Quick Actions') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <thead><tr><th>{{ __('Visit Code') }}</th><th>{{ __('Patient') }}</th><th>{{ __('MRN') }}</th><th>{{ __('Phone') }}</th><th>{{ __('Fee') }}</th><th>{{ __('Registered At') }}</th><th>{{ __('Action') }}</th></tr></thead>
                <tbody>@forelse($pendingVisits as $v)<tr>
                    <td><span class="badge badge-success">{{ $v->visit_code }}</span></td>
                    <td><strong>{{ $v->patient->full_name }}</strong></td>
                    <td>{{ $v->patient->mrn }}</td>
                    <td>{{ $v->patient->phone }}</td>
                    <td>{{ number_format($v->quickActionCharge?->consultation_fee ?? $v->doctor?->consultation_fee ?? 0, 2) }} {{ __('AFN') }}</td>
                    <td>{{ displayDate($v->created_at, 'Y-m-d H:i') }}</td>
                    <td><a href="{{ route('workflow.quick-action.consult', $v->id) }}" class="btn btn-success btn-sm"><i class="fas fa-bolt"></i> {{ __('Quick Consult') }}</a></td>
                </tr>@empty<tr><td colspan="7" class="text-center text-muted">{{ __('No pending quick actions') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>

<div class="row mt-3">
    <div class="col-md-12"><div class="card">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-check-circle"></i> {{ __('Completed Quick Actions') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Date') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Diagnosis') }}</th><th>{{ __('Total') }}</th><th>{{ __('Payment') }}</th></tr></thead>
                <tbody>@forelse($completedVisits as $v)
                    @php
                        $inv = $v->invoices->where('source_type', 'quick_action')->first();
                        $payStatus = $inv ? $inv->status : 'unpaid';
                        $badge = $payStatus === 'paid' ? 'success' : ($payStatus === 'partial' ? 'warning' : 'danger');
                    @endphp
                    <tr>
                        <td>{{ displayDate($v->consultation?->consultation_date, 'Y-m-d H:i') }}</td>
                        <td>{{ $v->patient->full_name }}</td>
                        <td>{{ $v->consultation?->diagnoses?->pluck('diagnosis_name')->implode(', ') ?: __('N/A') }}</td>
                        <td>{{ number_format($v->quickActionCharge?->total_amount ?? 0, 2) }} {{ __('AFN') }}</td>
                        <td><span class="badge badge-{{ $badge }}">{{ __(ucfirst($payStatus)) }}</span></td>
                    </tr>
                @empty<tr><td colspan="5" class="text-center text-muted">{{ __('No completed quick actions') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>
@endsection