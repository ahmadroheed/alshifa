@php
    $selectedIds = array_map('strval', old($name, session()->hasOldInput() ? [] : $selectedRelationIds));
    $availablePermissions = \App\Models\Permission::orderBy('module')->orderBy('display_name')->get();
    $permissionGroups = $availablePermissions->groupBy('module');
    $copyRoles = \App\Models\Role::with('permissions:id,name,status')->orderBy('display_name')->get();
    $copyRolePermissions = $copyRoles->mapWithKeys(fn ($role) => [$role->id => $role->permissions->pluck('id')->map(fn ($id) => (string) $id)->all()]);
    $inheritedRoles = $copyRoles->where('status', 'active')->mapWithKeys(fn ($role) => [$role->id => $role->permissions->where('status', 'active')->pluck('id')->map(fn ($id) => (string) $id)->values()->all()]);
@endphp
<div class="permission-picker border rounded p-3" data-permission-picker>
    <div class="d-flex flex-wrap align-items-center justify-content-between mb-2">
        <div><strong>{{ __('Page and action access') }}</strong> <span class="badge badge-primary" data-selection-count aria-live="polite"></span></div>
        <small class="text-muted">{{ __('Changes take effect when you save.') }}</small>
    </div>
    @if($resource === 'users')
        <p class="text-muted small">{{ __('These are extra permissions in addition to the selected roles. Unchecking an extra permission does not remove access granted by a role.') }}</p>
        <p class="small text-info" data-inherited-count aria-live="polite"></p>
        <script type="application/json" data-inherited-permissions>{!! json_encode($inheritedRoles, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!}</script>
    @endif
    <div class="row mb-3">
        <div class="col-md-8 mb-2">
            <input type="search" class="form-control" data-permission-search placeholder="{{ __('Search pages, modules, or actions…') }}" aria-label="{{ __('Search permissions') }}">
        </div>
        <div class="col-md-4 mb-2">
            <select class="form-control" data-permission-filter aria-label="{{ __('Filter permissions') }}">
                <option value="all">{{ __('All permissions') }}</option>
                <option value="selected">{{ __('Selected only') }}</option>
                <option value="unselected">{{ __('Not selected') }}</option>
            </select>
        </div>
    </div>
    <div class="d-flex flex-wrap mb-3" style="gap: .5rem">
        <button type="button" class="btn btn-outline-primary btn-sm" data-permission-bulk="all">{{ __('Select visible') }}</button>
        <button type="button" class="btn btn-outline-secondary btn-sm" data-permission-bulk="read">{{ __('Select visible read access') }}</button>
        <button type="button" class="btn btn-outline-danger btn-sm" data-permission-bulk="clear">{{ __('Clear visible') }}</button>
        <button type="button" class="btn btn-light btn-sm" data-permission-expand="true">{{ __('Expand all') }}</button>
        <button type="button" class="btn btn-light btn-sm" data-permission-expand="false">{{ __('Collapse all') }}</button>
    </div>
    @if($resource === 'roles')
        <div class="border rounded p-2 mb-3 bg-light">
            <label for="copy-role-permissions">{{ __('Start from an existing role') }}</label>
            <div class="input-group">
                <select id="copy-role-permissions" class="form-control" data-copy-role>
                    <option value="">{{ __('Choose a role') }}</option>
                    @foreach($copyRoles as $copyRole)
                        <option value="{{ $copyRole->id }}">{{ __($copyRole->display_name) }} ({{ $copyRole->permissions->count() }})</option>
                    @endforeach
                </select>
                <div class="input-group-append">
                    <button type="button" class="btn btn-outline-primary" data-copy-mode="add">{{ __('Add permissions') }}</button>
                    <button type="button" class="btn btn-outline-secondary" data-copy-mode="replace">{{ __('Replace selection') }}</button>
                </div>
            </div>
            <small class="text-muted">{{ __('Copies permissions only. The original role stays unchanged.') }}</small>
        </div>
        <script type="application/json" data-copy-permissions>{!! json_encode($copyRolePermissions, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!}</script>
    @endif
    <p class="small text-muted">{{ __('Read access selects list, view, and pending pages. Create, update, delete, payment collection, and other actions stay individually selectable.') }}</p>
    <div style="max-height: 650px; overflow-y: auto" class="pr-1">
        @foreach($permissionGroups as $group => $permissions)
            <details class="border rounded mb-2 permission-group" open data-permission-group>
                <summary class="p-2 bg-light" style="cursor: pointer">
                    <strong>{{ __(str($group)->replace(['.', '-'], ' ')->title()->toString()) }}</strong>
                    <span class="badge badge-secondary ml-2" dir="ltr" data-group-count></span>
                </summary>
                <div class="p-3">
                    <div class="mb-2">
                        <button type="button" class="btn btn-link btn-sm p-0 mr-3" data-group-bulk="all">{{ __('Select visible in module') }}</button>
                        <button type="button" class="btn btn-link btn-sm p-0" data-group-bulk="clear">{{ __('Clear visible in module') }}</button>
                    </div>
                    <div class="row">
                        @foreach($permissions as $permission)
                            @php
                                $action = str($permission->name)->afterLast('.')->toString();
                                $isRead = in_array($action, ['index', 'show', 'pending', 'patients', 'result'], true);
                            @endphp
                            <div class="col-lg-4 col-sm-6 mb-3" data-permission-item data-search="{{ mb_strtolower($group.' '.$permission->name.' '.$permission->display_name.' '.$permission->description) }}">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="{{ $name }}[]" id="permission_{{ $permission->id }}" value="{{ $permission->id }}" data-permission-input data-read="{{ $isRead ? '1' : '0' }}" @checked(in_array((string) $permission->id, $selectedIds, true))>
                                    <label class="form-check-label" for="permission_{{ $permission->id }}">{{ __($permission->display_name) }}</label>
                                    @if($resource === 'users')<span class="badge badge-info" data-inherited-badge hidden>{{ __('Via role') }}</span>@endif
                                    <small class="d-block text-muted" style="overflow-wrap: anywhere">{{ $permission->name }}</small>
                                    @if($permission->description)<small class="d-block text-muted">{{ $permission->description }}</small>@endif
                                    @if($permission->status !== 'active')<span class="badge badge-warning">{{ __('Inactive — does not grant access') }}</span>@endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </details>
        @endforeach
    </div>
    <p class="text-muted mt-3 mb-0" data-no-permissions hidden>{{ __('No permissions match your search.') }}</p>
</div>
<script>
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-permission-picker]').forEach(picker => {
        const inputs = Array.from(picker.querySelectorAll('[data-permission-input]'));
        const search = picker.querySelector('[data-permission-search]');
        const filter = picker.querySelector('[data-permission-filter]');
        const groups = Array.from(picker.querySelectorAll('[data-permission-group]'));
        const inheritedData = picker.querySelector('[data-inherited-permissions]');
        const roleInputs = Array.from(picker.closest('form').querySelectorAll('input[name="roles[]"]'));
        const countLabel = @json(__('Selected: :count of :total'));
        const digits = new Intl.NumberFormat(document.documentElement.lang === 'fa' ? 'fa-AF' : 'en');
        const update = () => {
            if (inheritedData) {
                const inheritedMap = JSON.parse(inheritedData.textContent);
                const inherited = new Set(roleInputs.filter(input => input.checked).flatMap(input => inheritedMap[input.value] || []));
                inputs.forEach(input => input.closest('[data-permission-item]').querySelector('[data-inherited-badge]').hidden = !inherited.has(input.value));
                picker.querySelector('[data-inherited-count]').textContent = `${inherited.size} {{ __('active permissions granted by selected roles') }}`;
            }
            const term = search.value.trim().toLocaleLowerCase();
            let visible = 0;
            inputs.forEach(input => {
                const item = input.closest('[data-permission-item]');
                item.hidden = !item.dataset.search.includes(term) || (filter.value === 'selected' && !input.checked) || (filter.value === 'unselected' && input.checked);
                if (!item.hidden) visible++;
            });
            groups.forEach(group => {
                const groupInputs = Array.from(group.querySelectorAll('[data-permission-input]'));
                group.hidden = groupInputs.every(input => input.closest('[data-permission-item]').hidden);
                group.querySelector('[data-group-count]').textContent = `${digits.format(groupInputs.filter(input => input.checked).length)} / ${digits.format(groupInputs.length)}`;
                if (term && !group.hidden) group.open = true;
            });
            picker.querySelector('[data-selection-count]').textContent = countLabel.replace(':count', digits.format(inputs.filter(input => input.checked).length)).replace(':total', digits.format(inputs.length));
            picker.querySelector('[data-no-permissions]').hidden = visible > 0;
        };
        roleInputs.forEach(input => input.addEventListener('change', update));
        search.addEventListener('input', update);
        filter.addEventListener('change', update);
        inputs.forEach(input => input.addEventListener('change', update));
        picker.addEventListener('click', event => {
            const bulk = event.target.closest('[data-permission-bulk], [data-group-bulk]');
            if (bulk) {
                const scope = bulk.hasAttribute('data-group-bulk') ? bulk.closest('[data-permission-group]') : picker;
                const action = bulk.dataset.groupBulk || bulk.dataset.permissionBulk;
                Array.from(scope.querySelectorAll('[data-permission-input]')).filter(input => !input.closest('[data-permission-item]').hidden).forEach(input => {
                    if (action !== 'read' || input.dataset.read === '1') input.checked = action !== 'clear';
                });
                update();
            }
            const expand = event.target.closest('[data-permission-expand]');
            if (expand) groups.forEach(group => group.open = expand.dataset.permissionExpand === 'true');
            const copy = event.target.closest('[data-copy-mode]');
            if (copy) {
                const roleId = picker.querySelector('[data-copy-role]').value;
                if (!roleId) return;
                const rolePermissions = JSON.parse(picker.querySelector('[data-copy-permissions]').textContent);
                const ids = new Set(rolePermissions[roleId] || []);
                inputs.forEach(input => {
                    if (copy.dataset.copyMode === 'replace' || ids.has(input.value)) input.checked = ids.has(input.value);
                });
                update();
            }
        });
        update();
    });
});
</script>
