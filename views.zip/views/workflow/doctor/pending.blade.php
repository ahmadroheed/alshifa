@php $title = __('My Patients'); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-12"><div class="card card-primary">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-clock"></i> {{ __('Pending Consultations') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <thead><tr><th>{{ __('Visit Code') }}</th><th>{{ __('Patient') }}</th><th>{{ __('MRN') }}</th><th>{{ __('Phone') }}</th><th>{{ __('Registered At') }}</th><th>{{ __('Action') }}</th></tr></thead>
                <tbody>@forelse($pendingVisits as $v)<tr>
                    <td>{{ $v->visit_code }}</td>
                    <td><strong>{{ $v->patient->full_name }}</strong></td>
                    <td>{{ $v->patient->mrn }}</td>
                    <td>{{ $v->patient->phone }}</td>
                    <td>{{ displayDate($v->created_at, 'Y-m-d H:i') }}</td>
                    <td><a href="{{ route('workflow.doctor.consult', $v->id) }}" class="btn btn-primary btn-sm"><i class="fas fa-stethoscope"></i> {{ __('Consult') }}</a></td>
                </tr>@empty<tr><td colspan="6" class="text-center text-muted">{{ __('No pending consultations') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
        @if($pendingVisits->hasPages())<div class="card-footer clearfix">{{ $pendingVisits->links('vendor.pagination.bootstrap-4') }}</div>@endif
    </div></div>
</div>

<div class="row mt-3">
    <div class="col-md-12"><div class="card">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-check-circle"></i> {{ __('Recent Consultations') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Date') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Diagnosis') }}</th><th>{{ __('Prescriptions') }}</th><th>{{ __('Lab Tests') }}</th></tr></thead>
                <tbody>@forelse($completedVisits as $v)<tr>
                    <td>{{ displayDate($v->consultation?->consultation_date, 'Y-m-d H:i') }}</td>
                    <td>{{ $v->patient->full_name }}</td>
                    <td>{{ $v->consultation?->diagnoses?->pluck('diagnosis_name')->implode(', ') ?: __('N/A') }}</td>
                    <td>{{ $v->prescriptions->count() }}</td>
                    <td>{{ $v->labRequests->count() }}</td>
                </tr>@empty<tr><td colspan="5" class="text-center text-muted">{{ __('No consultations yet') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>
@endsection
