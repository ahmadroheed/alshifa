@props(['status'])

@if ($status)
    <div class="flex items-center gap-2.5 px-4 py-3 bg-teal-50 border border-teal-200 text-teal-700 rounded-xl text-sm">
        <span class="material-icons text-teal-500 text-base">check_circle</span>
        <span>{{ $status }}</span>
    </div>
@endif
