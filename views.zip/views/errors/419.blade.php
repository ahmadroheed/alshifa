<x-guest-layout>
    <div class="m3-title">
        <p>419</p>
        <h1>{{ __('Session expired') }}</h1>
        <p>{{ __('Your session has expired. Please sign in again.') }}</p>
        <p><a href="{{ url('/') }}">{{ __('Back to home') }}</a></p>
    </div>
</x-guest-layout>
