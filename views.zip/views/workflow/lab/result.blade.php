@php
    $title = __('Lab Result - :name', ['name' => $labResult->labRequest->patientVisit->patient->full_name]);
@endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card card-outline card-info">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">
                    <i class="fas fa-flask mr-2"></i>{{ __('Lab Result Details') }}
                </h3>
                <div>
                    <span class="badge badge-{{ $labResult->status === 'completed' ? 'success' : 'secondary' }} px-3 py-2 mr-2">
                        {{ __(ucfirst($labResult->status)) }}
                    </span>
                    <a href="{{ route('workflow.lab.pending') }}" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-arrow-left mr-1"></i>{{ __('Back') }}
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th width="22%">{{ __('Test') }}</th>
                            <th width="15%">{{ __('Result') }}</th>
                            <th width="12%">{{ __('Normal Range') }}</th>
                            <th width="10%">{{ __('Unit') }}</th>
                            <th width="8%">{{ __('Flag') }}</th>
                            <th>{{ __('Remarks') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($labResult->items as $item)
                        @php
                            $flagClass = $item->flag === 'normal' ? 'success' : ($item->flag === 'critical' ? 'danger' : ($item->flag === 'abnormal' ? 'warning' : 'secondary'));
                            $isAbnormal = $item->flag && $item->flag !== 'normal';
                        @endphp
                        <tr class="{{ $isAbnormal ? 'table-active' : '' }}">
                            <td><strong>{{ $item->test_name }}</strong></td>
                            <td>
                                <span class="font-weight-bold {{ $isAbnormal ? 'text-danger' : 'text-success' }}" style="font-size:1.1em">
                                    {{ $item->result_value }}
                                </span>
                            </td>
                            <td><small class="text-muted">{{ $item->normal_range ?? '—' }}</small></td>
                            <td><small class="text-muted">{{ $item->unit ?? '—' }}</small></td>
                            <td>
                                @if($item->flag)
                                <span class="badge badge-{{ $flagClass }} px-2 py-1">
                                    @if($item->flag === 'critical')<i class="fas fa-exclamation-triangle mr-1"></i>@endif
                                    {{ __(ucfirst($item->flag)) }}
                                </span>
                                @else
                                <span class="text-muted">—</span>
                                @endif
                            </td>
                            <td><small>{{ $item->remarks ?? '—' }}</small></td>
                        </tr>
                        @empty
                        <tr><td colspan="6" class="text-center text-muted py-3">{{ __('No result items.') }}</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if($labResult->file_path)
        <div class="card card-outline card-info">
            <div class="card-header">
                <h4 class="card-title"><i class="fas fa-paperclip mr-2"></i>{{ __('Attached File') }}</h4>
                <div class="card-tools">
                    <a href="{{ Storage::disk('public')->url($labResult->file_path) }}" target="_blank" class="btn btn-sm btn-outline-info" rel="noopener noreferrer">
                        <i class="fas fa-download mr-1"></i>{{ __('Download') }}
                    </a>
                </div>
            </div>
            <div class="card-body text-center p-0">
                @if(in_array($labResult->file_type, ['jpg','jpeg','png','gif','webp']))
                <a href="{{ Storage::disk('public')->url($labResult->file_path) }}" target="_blank" rel="noopener noreferrer">
                    <img src="{{ Storage::disk('public')->url($labResult->file_path) }}"
                         alt="Lab Result File"
                         class="img-fluid"
                         style="max-height:500px;object-fit:contain;cursor:zoom-in">
                </a>
                @else
                <div class="py-5">
                    <i class="fas fa-file-{{ $labResult->file_type === 'pdf' ? 'pdf' : 'alt' }} text-muted" style="font-size:64px"></i>
                    <p class="mt-2 mb-0"><strong>{{ basename($labResult->file_path) }}</strong></p>
                    <p class="text-muted small">{{ strtoupper($labResult->file_type) }} {{ __('file') }}</p>
                    <a href="{{ Storage::disk('public')->url($labResult->file_path) }}" target="_blank" class="btn btn-info btn-sm" rel="noopener noreferrer">
                        <i class="fas fa-download mr-1"></i>{{ __('Download') }}
                    </a>
                </div>
                @endif
            </div>
        </div>
        @endif
    </div>

    <div class="col-md-4">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user mr-2"></i>{{ __('Patient Info') }}</h3>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <div class="d-inline-block bg-primary rounded-circle p-3 mb-2" style="width:70px;height:70px">
                        <i class="fas fa-user-injured text-white" style="font-size:28px;line-height:44px"></i>
                    </div>
                    <h5 class="mb-0">{{ $labResult->labRequest->patientVisit->patient->full_name }}</h5>
                    <small class="text-muted">{{ __('MRN') }}: {{ $labResult->labRequest->patientVisit->patient->mrn }}</small>
                </div>
                <hr class="my-3">
                <dl class="row mb-0">
                    <dt class="col-sm-5 text-muted">{{ __('Doctor') }}</dt>
                    <dd class="col-sm-7">{{ $labResult->doctor?->employee?->full_name ?? 'N/A' }}</dd>
                    <dt class="col-sm-5 text-muted">{{ __('Request Code') }}</dt>
                    <dd class="col-sm-7"><code>{{ $labResult->labRequest->request_code }}</code></dd>
                    <dt class="col-sm-5 text-muted">{{ __('Result Date') }}</dt>
                    <dd class="col-sm-7">{{ displayDate($labResult->result_date, 'Y-m-d H:i') }}</dd>
                    <dt class="col-sm-5 text-muted">{{ __('Uploaded By') }}</dt>
                    <dd class="col-sm-7">{{ $labResult->uploadedBy?->name ?? 'N/A' }}</dd>
                    @if($labResult->approvedBy)
                    <dt class="col-sm-5 text-muted">{{ __('Approved By') }}</dt>
                    <dd class="col-sm-7">{{ $labResult->approvedBy->name }}</dd>
                    @endif
                </dl>
            </div>
        </div>
    </div>
</div>
@endsection