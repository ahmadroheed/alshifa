@extends('layouts.admin', ['title' => $title ?? __('Dashboard')])

@section('content')
<div class="dashboard-shell">
    <div class="row">
        <div class="col-12">
            <section class="dashboard-hero">
                <div class="dashboard-hero__eyebrow"><span class="workspace-dot" aria-hidden="true"></span> {{ __('Your care workspace') }}</div>
                <h2>{{ __('Welcome back, :name.', ['name' => auth()->user()->name]) }}</h2>
                <p>{{ __('A clear view of your hospital. More time for the people who matter.') }}</p>
                <div class="dashboard-hero__meta"><span><i class="far fa-calendar-alt" aria-hidden="true"></i> {{ displayDate(now(), 'd M Y') }}</span><span><i class="fas fa-user-shield" aria-hidden="true"></i> {{ __(str($role)->replace('-', ' ')->title()->toString()) }}</span></div>
                <div class="dashboard-hero__art" aria-hidden="true"><span class="hero-orbit"></span><span class="hero-cross"><i class="fas fa-plus"></i></span><span class="hero-art-label">{{ __('Connected care') }}</span></div>
            </section>
        </div>
    </div>

    <div class="row mt-4">
        @foreach ($cards as $card)
            <div class="col-xl-3 col-lg-4 col-md-6 mb-3">
                <div class="material-metric material-metric--{{ in_array($card['color'] ?? 'info', ['info','success','warning','danger','primary']) ? ($card['color'] ?? 'info') : 'primary' }}">
                    <div class="material-metric__icon"><i class="{{ $card['icon'] }}"></i></div>
                    <div class="material-metric__value">{{ $card['value'] }}</div>
                    <div class="material-metric__label">{{ __($card['label']) }}</div>
                </div>
            </div>
        @endforeach
    </div>

    @if($role === 'super-admin' && isset($additionalData['recentPatients']))
        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Recent Patients') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['recentPatients'] as $patient)
                                <li class="list-group-item">{{ $patient->full_name }} - {{ $patient->mrn }}</li>
                            @empty
                                <li class="list-group-item">{{ __('No recent patients') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Recent Users') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['recentUsers'] as $user)
                                <li class="list-group-item">{{ $user->name }} - {{ $user->email }}</li>
                            @empty
                                <li class="list-group-item">{{ __('No recent users') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Today\'s Activities') }}</h3>
                    </div>
                    <div class="card-body">
                        <p>{{ __('Lab Requests: :count', ['count' => $additionalData['todayActivities']['labRequests']]) }}</p>
                        <p>{{ __('Pharmacy Sales: :count', ['count' => $additionalData['todayActivities']['pharmacySales']]) }}</p>
                        <p>{{ __('Invoices: :count', ['count' => $additionalData['todayActivities']['invoices']]) }}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('System Statistics') }}</h3>
                    </div>
                    <div class="card-body">
                        <p>{{ __('Total Revenue: :amount AFN', ['amount' => number_format($additionalData['systemStats']['totalRevenue'], 2)]) }}</p>
                        <p>{{ __('Pending Payments: :amount AFN', ['amount' => number_format($additionalData['systemStats']['pendingPayments'], 2)]) }}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Recent Consultations') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['recentConsultations'] as $consultation)
                                <li class="list-group-item">
                                    {{ $consultation->patientVisit?->patient?->full_name ?? __('N/A') }} - {{ __('Dr.') }} {{ $consultation->doctor?->employee?->full_name ?? __('N/A') }} - {{ $consultation->consultation_date }}
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No recent consultations') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if($role === 'super-admin' && isset($additionalData['accountingData']))
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Accounting Overview') }}</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="small-box bg-success">
                                    <div class="inner">
                                        <h3>{{ number_format($additionalData['accountingData']['todayRevenue'], 2) }}</h3>
                                        <p>{{ __('Today\'s Revenue') }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-dollar-sign"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="small-box bg-info">
                                    <div class="inner">
                                        <h3>{{ number_format($additionalData['accountingData']['monthlyRevenue'], 2) }}</h3>
                                        <p>{{ __('Monthly Revenue') }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="small-box bg-warning">
                                    <div class="inner">
                                        <h3>{{ number_format($additionalData['accountingData']['outstandingPayments'], 2) }}</h3>
                                        <p>{{ __('Outstanding Payments') }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="small-box bg-primary">
                                    <div class="inner">
                                        <h3>{{ number_format($additionalData['accountingData']['todayPharmacyRevenue'], 2) }}</h3>
                                        <p>{{ __('Today\'s Pharmacy Revenue') }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-pills"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Recent Invoices') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['accountingData']['recentInvoices'] as $invoice)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $invoice->invoice_number }}</strong><br>
                                        <small>{{ $invoice->patient?->full_name ?? __('Deleted Patient') }} - {{ displayDate($invoice->created_at, 'M d, Y') }}</small>
                                    </div>
                                    <span class="badge badge-{{ $invoice->status === 'paid' ? 'success' : ($invoice->status === 'partial' ? 'warning' : 'danger') }}">
                                         {{ number_format($invoice->total, 2) }} {{ __('AFN') }}
                                     </span>
                                 </li>
                             @empty
                                 <li class="list-group-item">{{ __('No recent invoices') }}</li>
                             @endforelse
                         </ul>
                     </div>
                 </div>
             </div>
             <div class="col-md-6">
                 <div class="card">
                     <div class="card-header">
                         <h3 class="card-title">{{ __('Unpaid Invoices') }}</h3>
                     </div>
                     <div class="card-body">
                         <ul class="list-group list-group-flush">
                             @forelse($additionalData['accountingData']['unpaidInvoices'] as $invoice)
                                 <li class="list-group-item d-flex justify-content-between align-items-center">
                                     <div>
                                         <strong>{{ $invoice->invoice_number }}</strong><br>
                                         <small>{{ $invoice->patient?->full_name ?? __('Deleted Patient') }} - {{ displayDate($invoice->created_at, 'M d, Y') }}</small>
                                     </div>
                                     <span class="badge badge-danger">
                                         {{ number_format($invoice->total, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No unpaid invoices') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Recent Pharmacy Sales') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['accountingData']['recentPharmacySales'] as $sale)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $sale->sale_code }}</strong><br>
                                        <small>{{ $sale->patientVisit?->patient?->full_name ?? __('N/A') }} - {{ displayDate($sale->sale_date, 'M d, Y') }}</small>
                                    </div>
                                    <span class="badge badge-{{ $sale->payment_status === 'paid' ? 'success' : 'warning' }}">
                                        {{ number_format($sale->total_amount, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No recent pharmacy sales') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if($role === 'doctor' && isset($additionalData['pendingConsultationPatients']))
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Pending Consultation Patients') }}</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>{{ __('Patient Name') }}</th>
                                        <th>{{ __('MRN') }}</th>
                                        <th>{{ __('Visit Date') }}</th>
                                        <th>{{ __('Referral Source') }}</th>
                                        <th>{{ __('Status') }}</th>
                                        <th>{{ __('Actions') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($additionalData['pendingConsultationPatients'] as $visit)
                                        <tr>
                                            <td>{{ $visit->patient?->full_name ?? __('Unknown') }}</td>
                                            <td>{{ $visit->patient?->mrn ?? __('N/A') }}</td>
                                            <td>{{ displayDate($visit->visit_date, 'Y-m-d') }}</td>
                                            <td>{{ $visit->referralSource?->name ?? __('N/A') }}</td>
                                            <td>
                                                <span class="badge badge-warning">{{ __(ucwords(str_replace('_', ' ', $visit->status))) }}</span>
                                            </td>
                                            <td>
                                                <a href="{{ route('masters.show', ['resource' => 'patients', 'id' => $visit->patient_id]) }}" class="btn btn-sm btn-primary">
                                                    {{ __('View') }}
                                                </a>
                                                <a href="{{ route('masters.create', ['consultations']) }}?patient_visit_id={{ $visit->id }}" class="btn btn-sm btn-success">
                                                    {{ __('Consult') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center">{{ __('No pending consultation patients') }}</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Total Income') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ number_format($additionalData['income'], 2) }} {{ __('AFN') }}</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Monthly Income') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ number_format($additionalData['monthlyIncome'] ?? 0, 2) }} {{ __('AFN') }}</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Total Patients') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ $additionalData['totalPatients'] ?? 0 }}</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Surgery Charges') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ number_format($additionalData['surgeryCharges'] ?? 0, 2) }} {{ __('AFN') }}</h4>
                    </div>
                </div>
            </div>
        </div>

        @if(isset($additionalData['labResults']))
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">{{ __('Recent Lab Results') }}</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>{{ __('Patient') }}</th>
                                            <th>{{ __('Consultation') }}</th>
                                            <th>{{ __('Request') }}</th>
                                            <th>{{ __('Tests') }}</th>
                                            <th>{{ __('Result Date') }}</th>
                                            <th>{{ __('Status') }}</th>
                                            <th>{{ __('Actions') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($additionalData['labResults'] as $result)
                                            <tr>
                                                <td>{{ $result->labRequest?->patientVisit?->patient?->full_name ?? __('Unknown') }}</td>
                                                <td>{{ $result->consultation?->display_name ?? __('N/A') }}</td>
                                                <td>{{ $result->labRequest?->request_code ?? __('N/A') }}</td>
                                                <td>
                                                    @foreach($result->items as $item)
                                                        <span class="badge badge-info">{{ $item->labTest?->name ?? $item->test_name }}</span>
                                                    @endforeach
                                                </td>
                                                <td>{{ displayDate($result->result_date, 'Y-m-d') }}</td>
                                                <td>
                                                    <span class="badge badge-success">{{ __(ucwords(str_replace('_', ' ', $result->status))) }}</span>
                                                </td>
                                                <td>
                                                    <a href="{{ route('masters.show', ['resource' => 'lab-results', 'id' => $result->id]) }}" class="btn btn-sm btn-primary">
                                                        {{ __('View') }}
                                                    </a>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="7" class="text-center">{{ __('No recent lab results') }}</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    @endif

    @if($role === 'lab-technician' && isset($additionalData['pendingLabPatients']))
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Pending Lab Patients') }}</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>{{ __('Patient Name') }}</th>
                                        <th>{{ __('MRN') }}</th>
                                        <th>{{ __('Lab Tests') }}</th>
                                        <th>{{ __('Request Date') }}</th>
                                        <th>{{ __('Status') }}</th>
                                        <th>{{ __('Actions') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($additionalData['pendingLabPatients'] as $patient)
                                        @php
                                            $latestRequest = $patient->labRequests->first();
                                        @endphp
                                        <tr>
                                            <td>{{ $patient->full_name }}</td>
                                            <td>{{ $patient->mrn }}</td>
                                            <td>
                                                @foreach($latestRequest?->items ?? [] as $item)
                                                    <span class="badge badge-info">{{ $item->labTest->name }}</span>
                                                @endforeach
                                            </td>
                                            <td>{{ displayDate($latestRequest?->request_date, 'Y-m-d') }}</td>
                                            <td>
                                                <span class="badge badge-warning">{{ __('Lab Assigned') }}</span>
                                            </td>
                                            <td>
                                                <a href="{{ route('masters.show', ['resource' => 'patients', 'id' => $patient->id]) }}" class="btn btn-sm btn-primary">
                                                    {{ __('View') }}
                                                </a>
                                                <a href="{{ route('masters.edit', ['lab-requests', $latestRequest?->id]) }}" class="btn btn-sm btn-success">
                                                    {{ __('Process') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center">{{ __('No pending lab patients') }}</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Total Patients Served') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ $additionalData['totalPatientsServed'] ?? 0 }}</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Lab Income') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ number_format($additionalData['labIncome'], 2) }} {{ __('AFN') }}</h4>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if($role === 'pharmacist' && isset($additionalData['pendingMedicationPatients']))
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Pending Medication Patients') }}</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>{{ __('Patient Name') }}</th>
                                        <th>{{ __('MRN') }}</th>
                                        <th>{{ __('Medicines') }}</th>
                                        <th>{{ __('Prescription Date') }}</th>
                                        <th>{{ __('Status') }}</th>
                                        <th>{{ __('Actions') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($additionalData['pendingMedicationPatients'] as $patient)
                                        @php
                                            $latestPrescription = $patient->prescriptions->first();
                                        @endphp
                                        <tr>
                                            <td>{{ $patient->full_name }}</td>
                                            <td>{{ $patient->mrn }}</td>
                                            <td>
                                                @foreach($latestPrescription?->items ?? [] as $item)
                                                    <span class="badge badge-info">{{ $item->medicine_name }}</span>
                                                @endforeach
                                            </td>
                                            <td>{{ displayDate($latestPrescription?->prescription_date, 'Y-m-d') }}</td>
                                            <td>
                                                <span class="badge badge-warning">{{ __('Medication Assigned') }}</span>
                                            </td>
                                            <td>
                                                <a href="{{ route('masters.show', ['resource' => 'patients', 'id' => $patient->id]) }}" class="btn btn-sm btn-primary">
                                                    {{ __('View') }}
                                                </a>
                                                <a href="{{ route('masters.create', ['pharmacy-sales']) }}?prescription_id={{ $latestPrescription?->id }}" class="btn btn-sm btn-success">
                                                    {{ __('Dispense') }}
                                                </a>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center">{{ __('No pending medication patients') }}</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Low Stock Medicines') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['lowStock'] as $batch)
                                <li class="list-group-item">{{ $batch->medicine->name }} - {{ $batch->remaining_quantity }} {{ __('remaining') }}</li>
                            @empty
                                <li class="list-group-item">{{ __('All medicines in stock') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Total Patients Served') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ $additionalData['totalPatientsServed'] ?? 0 }}</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Pharmacy Income') }}</h3>
                    </div>
                    <div class="card-body">
                        <h4>{{ number_format($additionalData['pharmacyIncome'], 2) }} {{ __('AFN') }}</h4>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if($role === 'receptionist' && isset($additionalData['todayRegistrations']))
        <div class="row mt-3">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header"><h3 class="card-title">{{ __('Today Registrations') }}</h3></div>
                    <div class="card-body"><h4>{{ $additionalData['todayRegistrations'] }}</h4></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header"><h3 class="card-title">{{ __("Today's Collections") }}</h3></div>
                    <div class="card-body"><h4 class="text-success">{{ number_format($additionalData['todayCollections'], 2) }} {{ __('AFN') }}</h4></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header"><h3 class="card-title">{{ __('Pending Collections') }}</h3></div>
                    <div class="card-body"><h4 class="text-danger">{{ number_format($additionalData['pendingCollections'], 2) }} {{ __('AFN') }}</h4></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header"><h3 class="card-title">{{ __('Total Patients') }}</h3></div>
                    <div class="card-body"><h4>{{ $additionalData['totalPatients'] }}</h4></div>
                </div>
            </div>
        </div>
    @endif

    @if($role === 'cashier' && isset($additionalData['pendingPayments']))
        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Pending Payments') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['pendingPayments'] as $invoice)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $invoice->invoice_number }}</strong><br>
                                        <small>{{ $invoice->patient?->full_name ?? __('Deleted Patient') }} - {{ displayDate($invoice->created_at, 'M d, Y') }}</small>
                                    </div>
                                    <span class="badge badge-danger">
                                        {{ number_format($invoice->total, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No pending payments') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Unpaid Pharmacy Sales') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['unpaidPharmacySales'] as $sale)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $sale->sale_code }}</strong><br>
                                        <small>{{ $sale->patientVisit?->patient?->full_name ?? __('N/A') }} - {{ displayDate($sale->sale_date, 'M d, Y') }}</small>
                                    </div>
                                    <span class="badge badge-warning">
                                        {{ number_format($sale->total_amount, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No unpaid pharmacy sales') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Today\'s Collections') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['todayCollections'] as $invoice)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $invoice->invoice_number }}</strong><br>
                                        <small>{{ $invoice->patient?->full_name ?? __('Deleted Patient') }}</small>
                                    </div>
                                    <span class="badge badge-success">
                                        {{ number_format($invoice->total, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No collections today') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Today\'s Pharmacy Collections') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['todayPharmacyCollections'] as $sale)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $sale->sale_code }}</strong><br>
                                        <small>{{ $sale->patientVisit?->patient?->full_name ?? __('N/A') }}</small>
                                    </div>
                                    <span class="badge badge-success">
                                        {{ number_format($sale->total_amount, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No pharmacy collections today') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if($role === 'accountant' && isset($additionalData['monthlyRevenue']))
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Financial Overview') }}</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="small-box bg-success">
                                    <div class="inner">
                                        <h3>{{ number_format($additionalData['monthlyRevenue'], 2) }}</h3>
                                        <p>{{ __('Monthly Revenue') }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-dollar-sign"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="small-box bg-info">
                                    <div class="inner">
                                        <h3>{{ number_format($additionalData['pharmacyMonthlyRevenue'], 2) }}</h3>
                                        <p>{{ __('Pharmacy Revenue') }}</p>
                                    </div>
                                    <div class="icon">
                                        <i class="fas fa-pills"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title">{{ __('Revenue by Service Type') }}</h4>
                                    </div>
                                    <div class="card-body">
                                        <ul class="list-group list-group-flush">
                                            @forelse($additionalData['revenueByType'] as $revenue)
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <span>{{ __($revenue->invoice_type) }}</span>
                                                    <strong>{{ number_format($revenue->total_revenue, 2) }} {{ __('AFN') }}</strong>
                                                </li>
                                            @empty
                                                <li class="list-group-item">{{ __('No revenue data available') }}</li>
                                            @endforelse
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Outstanding Payments by Patient') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['outstandingByPatient'] as $outstanding)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $outstanding->patient?->full_name ?? __('N/A') }}</strong><br>
                                        <small>{{ $outstanding->patient?->mrn ?? __('N/A') }}</small>
                                    </div>
                                    <span class="badge badge-danger">
                                        {{ number_format($outstanding->total_outstanding, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No outstanding payments') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Recent Payments') }}</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @forelse($additionalData['recentPayments'] as $payment)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{{ $payment->invoice_number }}</strong><br>
                                        <small>{{ $payment->patient?->full_name ?? __('Deleted Patient') }} - {{ displayDate($payment->updated_at, 'M d, Y H:i') }}</small>
                                    </div>
                                    <span class="badge badge-success">
                                        {{ number_format($payment->total, 2) }} {{ __('AFN') }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item">{{ __('No recent payments') }}</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection
