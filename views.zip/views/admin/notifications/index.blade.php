@extends('layouts.admin', ['title' => 'Notifications'])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">{{ __('Notifications') }}</h3>
                    <form method="post" action="{{ route('notifications.markAllRead') }}">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-primary">
                            {{ __('Mark all as read') }}
                        </button>
                    </form>
                </div>
                <div class="card-body">
                    @if ($notifications->isEmpty())
                        <div class="alert alert-info">{{ __('No notifications yet.') }}</div>
                    @else
                        <div class="list-group">
                            @foreach ($notifications as $notification)
                                <a href="{{ $notification->data['url'] ?? '#' }}" class="list-group-item list-group-item-action {{ $notification->read_at ? '' : 'bg-light' }}">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1">{{ __($notification->data['title'] ?? 'Referral Notification') }}</h5>
                                        <small>{{ $notification->created_at->diffForHumans() }}</small>
                                    </div>
                                    <p class="mb-1">{{ \App\Support\NotificationText::message($notification->data) }}</p>
                                    @if (! empty($notification->data['type']))
                                        <small class="text-muted">{{ __('Type') }}: {{ __(str($notification->data['type'])->replace('-', ' ')->title()->toString()) }}</small>
                                    @endif
                                </a>
                            @endforeach
                        </div>

                        <div class="mt-3">
                            {{ $notifications->links('vendor.pagination.bootstrap-4') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
