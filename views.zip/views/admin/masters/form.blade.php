@extends('layouts.admin', ['title' => $config['title'], 'resource' => $resource])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ $record->exists ? __('Edit') : __('Create') }} {{ __($config['title']) }}</h3>
                </div>
                <div class="card-body">
                    @if($errors->any())
                        <div class="alert alert-danger" role="alert">
                            <strong>{{ __('Please correct the following:') }}</strong>
                            <ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
                        </div>
                    @endif
                    <form method="post" action="{{ $record->exists ? route('masters.update', [$resource, $record]) : route('masters.store', $resource) }}" enctype="multipart/form-data">
                        @csrf
                        @if ($record->exists)
                            @method('put')
                        @endif

                        <div class="row">
                            @foreach ($config['fields'] as $name => $field)
                                @php
                                    $type = $field['type'] ?? 'text';
                                    $value = old($name, data_get($record, $name));
                                    if (!old($name) && isset($field['value'])) $value = $field['value'];
                                    if (($field['derived_from'] ?? null) === 'insurance' && old($name, null) === null) {
                                        $hasInsurance = data_get($record, 'insurance_company_id')
                                            || data_get($record, 'insurance_policy_number')
                                            || data_get($record, 'patient_type') === 'insured';
                                        $value = $hasInsurance ? '1' : '0';
                                    }
                                    if (! old($name) && $value instanceof \Illuminate\Support\Carbon) {
                                        $value = $type === 'datetime-local' ? $value->format('Y-m-d\TH:i') : $value->format('Y-m-d');
                                    }
                                    $isWide = in_array($type, ['textarea', 'multiselect', 'checkbox_group'], true);
                                    $selectedRelationIds = [];
                                    if (in_array($type, ['multiselect', 'checkbox_group'], true) && ! empty($field['relation']) && $record->exists) {
                                        $selectedRelationIds = $record->{$field['relation']}()->pluck('id')->map(fn ($id) => (string) $id)->all();
                                    }
                                    if (($field['derived_from'] ?? null) === 'permission_action' && old($name, null) === null) {
                                        $permissionName = data_get($record, 'name', '');
                                        $selectedRelationIds = str_contains($permissionName, '.') ? [str($permissionName)->afterLast('.')->toString()] : [];
                                    }
                                @endphp

                                <div
                                    class="col-md-{{ $isWide ? 12 : 6 }} mb-3"
                                    @if (! empty($field['show_if']))
                                        data-show-if-field="{{ $field['show_if']['field'] }}"
                                        data-show-if-value="{{ $field['show_if']['value'] }}"
                                    @endif
                                >
                                    <label for="{{ $name }}" class="form-label">{{ __((string) $field['label']) }}</label>

                                    @if ($type === 'textarea')
                                        <textarea id="{{ $name }}" name="{{ $name }}" class="form-control" rows="3">{{ $value }}</textarea>
                                    @elseif ($type === 'date')
                                        <input type="hidden" id="{{ $name }}" name="{{ $name }}" value="{{ $value }}">
                                        <input
                                            id="{{ $name }}_shamsi"
                                            type="text"
                                            class="form-control shamsi-datepicker"
                                            data-alt-field="#{{ $name }}"
                                            @if(! empty($field['readonly']) || ($resource === 'permissions' && $name === 'name' && $record->exists && array_key_exists($record->name, \App\Support\AccessCatalog::definitions()))) readonly @endif
                                            @if(! empty($field['disabled'])) disabled @endif
                                        >
                                    @elseif ($type === 'select')
                                        @php
                                            $selectOptions = $field['choices'] ?? $options[$name] ?? [];
                                        @endphp
                                        @if (! empty($field['readonly']))
                                            <input type="hidden" id="{{ $name }}" name="{{ $name }}" value="{{ $value }}">
                                            <input type="text" class="form-control" value="{{ $selectOptions[$value] ?? $value }}" readonly @if(! empty($field['disabled'])) disabled @endif>
                                        @else
                                            <input type="hidden" id="{{ $name }}" name="{{ $name }}" value="{{ $value }}">
                                            <select id="{{ $name }}" name="{{ $name }}" class="form-control select2bs4" @if(! empty($field['disabled'])) disabled @endif>
                                                <option value="">{{ __('Select') }}</option>
                                                @if (filled($value) && ! in_array((string) $value, array_map('strval', array_keys($selectOptions)), true))
                                                    <option value="{{ $value }}" selected>{{ __($value) }}</option>
                                                @endif
                                                @foreach ($selectOptions as $optionValue => $optionLabel)
                                                    <option value="{{ $optionValue }}" @selected((string) $value === (string) $optionValue)>{{ __($optionLabel) }}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    @elseif ($type === 'multiselect')
                                        <select id="{{ $name }}" name="{{ $name }}[]" class="form-control select2bs4" multiple>
                                            @foreach (($options[$name] ?? []) as $optionValue => $optionLabel)
                                                <option value="{{ $optionValue }}" @selected(in_array((string) $optionValue, old($name, session()->hasOldInput() ? [] : $selectedRelationIds), true))>{{ __($optionLabel) }}</option>
                                            @endforeach
                                        </select>
                                    @elseif ($type === 'checkbox_group' && $name === 'permissions' && in_array($resource, ['roles', 'users'], true))
                                        @include('admin.masters.partials.permission-picker')
                                    @elseif ($type === 'checkbox_group')
                                        @php
                                            $checkedValues = array_map('strval', old($name, session()->hasOldInput() ? [] : $selectedRelationIds));
                                            $checkboxOptions = $field['choices'] ?? $options[$name] ?? [];
                                            $isGrouped = collect($checkboxOptions)->contains(fn ($option) => is_array($option));
                                        @endphp

                                        <div class="border rounded p-3 bg-light">
                                            @if ($isGrouped)
                                                @foreach ($checkboxOptions as $group => $groupOptions)
                                                    <div class="mb-3">
                                                        <div class="font-weight-bold mb-2">{{ __(str($group)->replace('-', ' ')->title()->toString()) }}</div>
                                                        <div class="row">
                                                            @foreach ($groupOptions as $optionValue => $optionLabel)
                                                                <div class="col-md-4 col-sm-6 mb-2">
                                                                    <div class="form-check">
                                                                        <input id="{{ $name }}_{{ $optionValue }}" class="form-check-input" type="checkbox" name="{{ $name }}[]" value="{{ $optionValue }}" @checked(in_array((string) $optionValue, $checkedValues, true))>
                                                                        <label class="form-check-label" for="{{ $name }}_{{ $optionValue }}">{{ __((string) $optionLabel) }}</label>
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @else
                                                <div class="row">
                                                    @foreach ($checkboxOptions as $optionValue => $optionLabel)
                                                        <div class="col-md-4 col-sm-6 mb-2">
                                                            <div class="form-check">
                                                                <input id="{{ $name }}_{{ $optionValue }}" class="form-check-input" type="checkbox" name="{{ $name }}[]" value="{{ $optionValue }}" @checked(in_array((string) $optionValue, $checkedValues, true))>
                                                                <label class="form-check-label" for="{{ $name }}_{{ $optionValue }}">{{ __((string) $optionLabel) }}</label>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                                    @elseif ($type === 'checkbox')
                                        <div class="form-check">
                                            <input id="{{ $name }}" type="checkbox" name="{{ $name }}" value="1" class="form-check-input" @checked(old($name, $value))>
                                            <label class="form-check-label" for="{{ $name }}">{{ __((string) $field['label']) }}</label>
                                        </div>
                                    @elseif ($type === 'dynamic')
                                        @php
                                            $dependsOn = $field['depends_on'] ?? 'type';
                                            $currentDynamicType = data_get($record, $dependsOn, 'text');
                                            $currentFileUrl = null;
                                            if ($currentDynamicType === 'file' && filled($value)) {
                                                $currentFileUrl = Storage::disk('public')->url($value);
                                            }
                                        @endphp
                                        <div class="dynamic-value-wrapper"
                                             data-dynamic-field="{{ $name }}"
                                             data-depends-on="{{ $dependsOn }}"
                                             data-current-type="{{ $currentDynamicType }}"
                                             data-current-value="{{ $value }}"
                                             data-current-file-url="{{ $currentFileUrl }}"
                                             data-record-exists="{{ $record->exists ? '1' : '0' }}">
                                        </div>
                                    @else
                                        <input
                                            id="{{ $name }}"
                                            type="{{ $type }}"
                                            name="{{ $name }}"
                                            @if($type !== 'file') value="{{ $type === 'password' ? '' : $value }}" @endif
                                            class="form-control"
                                            @if($type === 'number') step="0.01" @endif
                                            @if(! empty($field['readonly']) || ($resource === 'permissions' && $name === 'name' && $record->exists && array_key_exists($record->name, \App\Support\AccessCatalog::definitions()))) readonly @endif
                                            @if(! empty($field['disabled'])) disabled @endif
                                        >
                                        @if ($type === 'file' && $record->exists && filled($value))
                                            @php
                                                $fileUrl = Storage::disk($field['disk'] ?? 'public')->url($value);
                                            @endphp
                                            <div class="mt-2">
                                                <a href="{{ $fileUrl }}" target="_blank" rel="noopener noreferrer">{{ basename($value) }}</a>
                                            </div>
                                        @endif
                                    @endif

                                    @if (! empty($field['help']))
                                        <div class="form-text">{{ __((string) $field['help']) }}</div>
                                    @endif
                                </div>
                            @endforeach
                        </div>

                        <div class="form-group mt-4 text-right">
                            <button class="btn btn-primary mr-2" type="submit">
                                <i class="fas fa-save"></i> {{ __('Save') }}
                            </button>
                            <a class="btn btn-secondary" href="{{ route('masters.index', $resource) }}">
                                <i class="fas fa-times"></i> {{ __('Cancel') }}
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            @if ($resource === 'payments' && $record->amount)
            var amountInput = document.getElementById('amount');
            var discountInput = document.getElementById('discount_amount');
            if (discountInput) {
                var wrapper = discountInput.closest('.mb-3');
                if (wrapper) {
                    var netGroup = document.createElement('div');
                    netGroup.className = 'input-group mt-2';
                    netGroup.innerHTML = '<span class="input-group-text text-muted">{{ __("Net") }}:</span>' +
                        '<input type="text" id="net_amount_display" class="form-control font-weight-bold text-success" value="{{ number_format($record->amount, 2) }}" readonly>' +
                        '<span class="input-group-text">{{ __("AFN") }}</span>';
                    wrapper.appendChild(netGroup);
                }
                discountInput.setAttribute('max', amountInput ? amountInput.value : {{ $record->amount }});
                function updateNet() {
                    var amount = parseFloat(amountInput ? amountInput.value : {{ $record->amount }}) || 0;
                    var discount = parseFloat(discountInput.value) || 0;
                    if (discount > amount) {
                        discountInput.value = amount.toFixed(2);
                        discount = amount;
                        discountInput.classList.add('is-invalid');
                    } else {
                        discountInput.classList.remove('is-invalid');
                    }
                    var netEl = document.getElementById('net_amount_display');
                    if (netEl) netEl.value = (amount - discount).toFixed(2);
                }
                discountInput.addEventListener('input', updateNet);
                updateNet();
            }
            @endif
            const conditionalFields = document.querySelectorAll('[data-show-if-field]');

            conditionalFields.forEach((wrapper) => {
                const controller = document.querySelector(`[name="${wrapper.dataset.showIfField}"]`);
                const inputs = wrapper.querySelectorAll('input, select, textarea');

                if (! controller) {
                    return;
                }

                const updateVisibility = () => {
                    const shouldShow = controller.value === wrapper.dataset.showIfValue;

                    wrapper.style.display = shouldShow ? '' : 'none';
                    inputs.forEach((input) => {
                        input.disabled = ! shouldShow;
                    });
                };

                controller.addEventListener('change', updateVisibility);
                updateVisibility();
            });

            // Dynamic field type switching
            const dynamicWrappers = document.querySelectorAll('.dynamic-value-wrapper');

            dynamicWrappers.forEach((wrapper) => {
                const fieldName = wrapper.dataset.dynamicField;
                const dependsOn = wrapper.dataset.dependsOn;
                const currentType = wrapper.dataset.currentType;
                const currentValue = wrapper.dataset.currentValue;
                const recordExists = wrapper.dataset.recordExists === '1';

                const controllerSelect = document.querySelector(`select[name="${dependsOn}"]`);

                const renderDynamicField = (type, value) => {
                    const inputTypes = {
                        'text': () => `<input id="${fieldName}" name="${fieldName}" type="text" value="${escapeHtml(value)}" class="form-control">`,
                        'number': () => `<input id="${fieldName}" name="${fieldName}" type="number" step="0.01" value="${escapeHtml(value)}" class="form-control">`,
                        'boolean': () => `<input type="hidden" name="${fieldName}" value="0"><div class="form-check"><input id="${fieldName}" name="${fieldName}" type="checkbox" value="1" class="form-check-input"${value === '1' || value === 1 || value === true ? ' checked' : ''}><label class="form-check-label" for="${fieldName}">${wrapper.closest('.mb-3').querySelector('.form-label').textContent}</label></div>`,
                        'color': () => `<input id="${fieldName}" name="${fieldName}" type="color" value="${value || '#2e7d32'}" class="form-control form-control-color" style="height:38px;padding:4px">`,
                        'textarea': () => `<textarea id="${fieldName}" name="${fieldName}" class="form-control" rows="3">${escapeHtml(value)}</textarea>`,
                        'email': () => `<input id="${fieldName}" name="${fieldName}" type="email" value="${escapeHtml(value)}" class="form-control">`,
                        'url': () => `<input id="${fieldName}" name="${fieldName}" type="url" value="${escapeHtml(value)}" class="form-control">`,
                        'password': () => `<input id="${fieldName}" name="${fieldName}" type="password" class="form-control" placeholder="{{ __('Enter new value') }}">`,
                        'file': () => {
                            let html = `<input id="${fieldName}" name="${fieldName}" type="file" class="form-control-file">`;
                            if (recordExists && value) {
                                const fileUrl = wrapper.dataset.currentFileUrl;
                                html += `<div class="mt-2"><a href="${fileUrl}" target="_blank" rel="noopener noreferrer">${escapeHtml(value.split('/').pop())}</a></div>`;
                            }
                            return html;
                        },
                        'image': () => {
                            let html = `<input id="${fieldName}" name="${fieldName}" type="file" accept="image/*" class="form-control-file">`;
                            if (recordExists && value) {
                                const fileUrl = wrapper.dataset.currentFileUrl;
                                html += `<div class="mt-2"><img src="${fileUrl}" class="img-thumbnail current-image-preview" style="max-height:100px" alt="Current"></div>`;
                            }
                            return html;
                        },
                        'json': () => `<textarea id="${fieldName}" name="${fieldName}" class="form-control" rows="5">${escapeHtml(value)}</textarea>`
                    };

                    const renderer = inputTypes[type] || inputTypes['text'];
                    wrapper.innerHTML = renderer();

                    const col = wrapper.closest('.mb-3');
                    if (type === 'textarea' || type === 'json') {
                        col.classList.remove('col-md-6');
                        col.classList.add('col-md-12');
                    } else {
                        col.classList.remove('col-md-12');
                        col.classList.add('col-md-6');
                    }
                };

                const escapeHtml = (str) => {
                    if (!str) return '';
                    const div = document.createElement('div');
                    div.textContent = String(str);
                    return div.innerHTML;
                };

                if (controllerSelect) {
                    controllerSelect.addEventListener('change', () => {
                        const oldValue = document.querySelector(`[name="${fieldName}"]`)?.value || '';
                        renderDynamicField(controllerSelect.value, oldValue);
                    });
                }

                renderDynamicField(currentType, currentValue);
            });
        });
    </script>
@endsection
