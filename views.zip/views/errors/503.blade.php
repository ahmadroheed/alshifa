<x-guest-layout>
    <div class="m3-title">
        <p>503</p>
        <h1>{{ __('Temporarily unavailable') }}</h1>
        <p>{{ __('The system is temporarily unavailable. Please try again later.') }}</p>
        <p><a href="{{ url('/') }}">{{ __('Back to home') }}</a></p>
    </div>
</x-guest-layout>
