@php $title = __('Lab Workflow'); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-12"><div class="card card-info">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-clock"></i> {{ __('Pending Lab Tests') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <thead><tr><th>{{ __('Request Code') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Tests') }}</th><th>{{ __('Requested') }}</th><th>{{ __('Action') }}</th></tr></thead>
                <tbody>@forelse($pendingRequests as $req)<tr>
                    <td>{{ $req->request_code }}</td>
                    <td><strong>{{ $req->patientVisit->patient->full_name }}</strong></td>
                    <td>{{ $req->items->pluck('labTest.name')->implode(', ') }}</td>
                    <td>{{ displayDate($req->request_date, 'Y-m-d H:i') }}</td>
                    <td><a href="{{ route('workflow.lab.process', $req->id) }}" class="btn btn-info btn-sm"><i class="fas fa-flask"></i> {{ __('Process') }}</a></td>
                </tr>@empty<tr><td colspan="5" class="text-center text-muted">{{ __('No pending lab requests') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
        @if($pendingRequests->hasPages())<div class="card-footer clearfix">{{ $pendingRequests->links('vendor.pagination.bootstrap-4') }}</div>@endif
    </div></div>
</div>
<div class="row mt-3">
    <div class="col-md-12"><div class="card">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-check-circle"></i> {{ __('Completed Results') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Date') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Tests') }}</th><th>{{ __('Result') }}</th></tr></thead>
                <tbody>@forelse($completedResults as $r)<tr>
                    <td>{{ displayDate($r->result_date, 'Y-m-d') }}</td>
                    <td>{{ $r->labRequest->patientVisit->patient->full_name }}</td>
                    <td>{{ $r->items->pluck('test_name')->implode(', ') }}</td>
                    <td><a href="{{ route('workflow.lab.result', $r->id) }}" class="btn btn-sm btn-info"><i class="fas fa-eye mr-1"></i>{{ __('View') }}</a></td>
                </tr>@empty<tr><td colspan="4" class="text-center text-muted">{{ __('No completed results') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>
@endsection
