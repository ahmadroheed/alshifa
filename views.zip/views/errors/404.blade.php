<x-guest-layout>
    <div class="m3-title">
        <p>404</p>
        <h1>{{ __('Page not found') }}</h1>
        <p>{{ __('The page you requested could not be found.') }}</p>
        <p><a href="{{ url('/') }}">{{ __('Back to home') }}</a></p>
    </div>
</x-guest-layout>
