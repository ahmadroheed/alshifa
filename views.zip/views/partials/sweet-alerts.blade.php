@php
    $statusMessages = [
        'profile-updated' => __('Profile updated successfully.'),
        'password-updated' => __('Password updated successfully.'),
        'verification-link-sent' => __('A new verification link has been sent to your email address.'),
    ];

    $status = session('status');
    $successMessage = session('success') ?? ($status ? ($statusMessages[$status] ?? $status) : null);
    $errorMessages = collect($errors->getBags())
        ->flatMap(fn ($bag) => $bag->all())
        ->unique()
        ->values()
        ->all();
@endphp

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const successMessage = @json($successMessage);
        const warningMessage = @json(session('warning'));
        const errorMessage = @json(session('error'));
        const validationErrors = @json($errorMessages);
        const escapeHtml = (value) => String(value)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');

        if (successMessage) {
            Swal.fire({
                icon: 'success',
                title: @json(__('Success')),
                text: successMessage,
                timer: 2500,
                timerProgressBar: true
            });
        }

        if (warningMessage) {
            Swal.fire({
                icon: 'warning',
                title: @json(__('Warning')),
                text: warningMessage
            });
        }

        if (errorMessage) {
            Swal.fire({
                icon: 'error',
                title: @json(__('Error')),
                text: errorMessage
            });
        }

        if (validationErrors.length > 0) {
            Swal.fire({
                icon: 'error',
                title: @json(__('Please check the form')),
                html: `<ul class="text-start mb-0">${validationErrors.map((message) => `<li>${escapeHtml(message)}</li>`).join('')}</ul>`
            });
        }

        document.querySelectorAll('form[data-confirm]').forEach((form) => {
            form.addEventListener('submit', (event) => {
                if (form.dataset.confirmed === 'true') {
                    return;
                }

                event.preventDefault();

                Swal.fire({
                    icon: 'warning',
                    title: form.dataset.confirmTitle || @json(__('Are you sure?')),
                    text: form.dataset.confirm || @json(__('This action cannot be undone.')),
                    showCancelButton: true,
                    confirmButtonText: form.dataset.confirmButton || @json(__('Yes, continue')),
                    cancelButtonText: @json(__('Cancel')),
                    confirmButtonColor: '#dc3545'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.dataset.confirmed = 'true';
                        form.submit();
                    }
                });
            });
        });
    });
</script>
