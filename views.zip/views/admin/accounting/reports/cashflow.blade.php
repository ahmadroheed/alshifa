@extends('layouts.admin', ['title' => __('Cashflow Report')])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ __('Cashflow Report') }}</h3>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <div class="info-box bg-success">
                                <span class="info-box-icon"><i class="fas fa-arrow-down"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{{ __('Cash Receipts') }}</span>
                                    <span class="info-box-number">{{ number_format($totalReceipts, 2) }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="info-box bg-danger">
                                <span class="info-box-icon"><i class="fas fa-arrow-up"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{{ __('Cash Payments') }}</span>
                                    <span class="info-box-number">{{ number_format($totalPayments, 2) }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="info-box bg-primary">
                                <span class="info-box-icon"><i class="fas fa-balance-scale"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text">{{ __('Net Cash Flow') }}</span>
                                    <span class="info-box-number">{{ number_format($netCashFlow, 2) }}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <h5>{{ __('Recent Cash Receipts') }}</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>{{ __('Date') }}</th>
                                            <th>{{ __('Payment') }}</th>
                                            <th>{{ __('Invoice') }}</th>
                                            <th>{{ __('Amount') }}</th>
                                            <th>{{ __('Method') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($cashReceipts as $payment)
                                            <tr>
                                                <td>{{ displayDate($payment->payment_date, 'Y-m-d') }}</td>
                                                <td>{{ $payment->payment_number }}</td>
                                                <td>{{ optional($payment->invoice)->invoice_number }}</td>
                                                <td>{{ number_format($payment->amount, 2) }}</td>
                                                <td>{{ optional($payment->paymentMethod)->name }}</td>
                                            </tr>
                                        @empty
                                            <tr><td colspan="5">{{ __('No completed receipts found.') }}</td></tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h5>{{ __('Recent Cash Payments') }}</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>{{ __('Date') }}</th>
                                            <th>{{ __('Expense') }}</th>
                                            <th>{{ __('Category') }}</th>
                                            <th>{{ __('Amount') }}</th>
                                            <th>{{ __('Status') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($cashPayments as $expense)
                                            <tr>
                                                <td>{{ displayDate($expense->expense_date, 'Y-m-d') }}</td>
                                                <td>{{ $expense->expense_number }}</td>
                                                <td>{{ optional($expense->category)->name }}</td>
                                                <td>{{ number_format($expense->amount, 2) }}</td>
                                                <td>{{ __(ucfirst($expense->status)) }}</td>
                                            </tr>
                                        @empty
                                            <tr><td colspan="5">{{ __('No approved expenses found.') }}</td></tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
