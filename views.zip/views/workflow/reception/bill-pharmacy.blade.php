@php $title = __('Pharmacy Request - :name', ['name' => $visit->patient->full_name]); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-8"><div class="card card-success">
        <div class="card-header"><h3 class="card-title">{{ __('Patient') }}: {{ $visit->patient->full_name }} ({{ $visit->patient->mrn }})</h3></div>
        <div class="card-body">
            @if($invoice)
            <div class="alert alert-success">
                <h5><i class="fas fa-check-circle"></i> {{ __('Invoice Generated') }}</h5>
                <p>{{ __('Invoice #') }}: <strong>{{ $invoice->invoice_number }}</strong> | {{ __('Total') }}: <strong>{{ number_format($invoice->total, 2) }} {{ __('AFN') }}</strong></p>
                <a href="{{ route('invoices.print', $invoice->id) }}" class="btn btn-primary"><i class="fas fa-print"></i> {{ __('Print Bill') }}</a>
                <button class="btn btn-success confirm-payment" data-invoice="{{ $invoice->id }}"><i class="fas fa-check"></i> {{ __('Confirm Payment') }}</button>
            </div>
            @else
            <form id="pharmacy-bill-form" method="POST" action="{{ route('workflow.reception.generate-bill', $visit->id) }}">
                @csrf
                <div class="form-group"><label>{{ __('Select Medicines') }} <span class="text-danger">*</span></label>
                    <select class="form-control select2" id="medicine-select" style="width:100%">
                        <option value="">{{ __('Select Medicine') }}</option>
                        @foreach ($medicines as $m)<option value="{{ $m->id }}" data-price="{{ $m->batches->first()?->sale_price ?? 0 }}" data-stock="{{ $m->batches->sum('remaining_quantity') }}">{{ $m->name }} - {{ number_format($m->batches->first()?->sale_price ?? 0, 2) }} {{ __('AFN') }} ({{ __('Stock') }}: {{ $m->batches->sum('remaining_quantity') }})</option>@endforeach
                    </select>
                </div>
                <table class="table table-sm" id="medicine-table">
                    <thead><tr><th>{{ __('Medicine') }}</th><th>{{ __('Price') }}</th><th>{{ __('Qty') }}</th><th>{{ __('Total') }}</th><th>{{ __('Action') }}</th></tr></thead>
                    <tbody></tbody>
                    <tfoot><tr class="font-weight-bold"><td colspan="3">{{ __('Total') }}</td><td id="total-amount">0.00 {{ __('AFN') }}</td><td></td></tr></tfoot>
                </table>
                <button type="submit" class="btn btn-success btn-lg"><i class="fas fa-file-invoice"></i> {{ __('Generate Bill') }}</button>
            </form>
            @endif
        </div>
    </div></div>
    <div class="col-md-4">
        <div class="card"><div class="card-header"><h3 class="card-title">{{ __('Patient Info') }}</h3></div>
            <div class="card-body">
                <dl><dt>{{ __('Name') }}</dt><dd>{{ $visit->patient->full_name }}</dd><dt>{{ __('MRN') }}</dt><dd>{{ $visit->patient->mrn }}</dd><dt>{{ __('Phone') }}</dt><dd>{{ $visit->patient->phone }}</dd><dt>{{ __('Visit Code') }}</dt><dd>{{ $visit->visit_code }}</dd></dl>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="bankModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">{{ __('Select Bank Account') }}</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <div class="form-group">
                    <label>{{ __('Bank Account') }}</label>
                    <select id="bank_account_id" class="form-control">
                        <option value="">{{ __('Cash (On Hand)') }}</option>
                        @foreach($bankAccounts as $ba)
                            <option value="{{ $ba->id }}">{{ $ba->account_name }} ({{ $ba->bank_name }} - {{ $ba->account_number }})</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-success" id="confirmCollect">{{ __('Confirm & Collect') }}</button>
            </div>
        </div>
    </div>
</div>

@push('js')
<script>
$(document).ready(function() {
    var pendingInvoiceId = null;

    $('.select2').select2({theme: 'bootstrap4'});
    var items = [];
    $('#medicine-select').on('change', function() {
        var id = $(this).val();
        if (!id) return;
        var opt = $(this).find('option:selected');
        var name = opt.text().split(' - ')[0];
        var price = parseFloat(opt.data('price'));
        var stock = parseInt(opt.data('stock'));
        if (items.find(function(i) { return i.id == id; })) { alert(@json(__('Already added.'))); return; }
        items.push({id: id, name: name, price: price, qty: 1, stock: stock});
        renderTable();
        $(this).val('').trigger('change');
    });
    function renderTable() {
        var tbody = $('#medicine-table tbody');
        tbody.empty();
        var total = 0;
        items.forEach(function(item, idx) {
            var lineTotal = item.price * item.qty;
            total += lineTotal;
            tbody.append('<tr><td>'+item.name+'<input type="hidden" name="items['+idx+'][medicine_id]" value="'+item.id+'"><input type="hidden" name="items['+idx+'][quantity]" value="'+item.qty+'"></td><td>'+item.price.toFixed(2)+'</td><td><input type="number" class="form-control form-control-sm qty-input" data-idx="'+idx+'" value="'+item.qty+'" min="1" max="'+item.stock+'" style="width:80px"></td><td>'+lineTotal.toFixed(2)+' {{ __('AFN') }}</td><td><button type="button" class="btn btn-sm btn-danger remove-item" data-idx="'+idx+'"><i class="fas fa-times"></i></button></td></tr>');
        });
        $('#total-amount').text(total.toFixed(2)+' {{ __('AFN') }}');
    }
    $(document).on('change', '.qty-input', function() {
        var idx = $(this).data('idx');
        items[idx].qty = parseInt($(this).val()) || 1;
        renderTable();
    });
    $(document).on('click', '.remove-item', function() {
        var idx = $(this).data('idx');
        items.splice(idx, 1);
        renderTable();
    });
    $('#pharmacy-bill-form').on('submit', function(e) {
        e.preventDefault();
        if (!items.length) { alert(@json(__('Please add at least one medicine.'))); return; }
        $.ajax({
            url: '{{ route("workflow.reception.generate-bill", $visit->id) }}',
            method: 'POST',
            data: $(this).serialize(),
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function(xhr) { alert(@json(__('Error:')) + ' ' + (xhr.responseJSON?.message || xhr.statusText || @json(__('Unknown')))); }
        });
    });
    $(document).on('click', '.confirm-payment', function() {
        pendingInvoiceId = $(this).data('invoice');
        $('#bankModal').modal('show');
    });

    $('#confirmCollect').on('click', function() {
        if (!pendingInvoiceId) return;
        $('#confirmCollect').html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.reception.confirm-payment", ["invoice" => "__INVOICE__"]) }}'.replace('__INVOICE__', pendingInvoiceId),
            method: 'POST',
            data: {_token: '{{ csrf_token() }}', bank_account_id: $('#bank_account_id').val()},
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function() { alert('{{ __("Error processing payment.") }}'); $('#confirmCollect').html('{{ __("Confirm & Collect") }}').prop('disabled', false); $('#bankModal').modal('hide'); }
        });
    });
});
</script>
@endpush
@endsection
