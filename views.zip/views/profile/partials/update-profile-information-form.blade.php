<div class="card-header">
    <h3 class="card-title mb-0">
        <i class="fas fa-id-card text-primary mr-2"></i>{{ __('Profile Information') }}
    </h3>
    <div class="card-subtitle">{{ __("Keep your account details and profile photo up to date.") }}</div>
</div>

<div class="card-body">
    <form id="send-verification" method="post" action="{{ route('verification.send') }}">
        @csrf
    </form>

    <form method="post" action="{{ route('profile.update') }}" enctype="multipart/form-data">
        @csrf
        @method('patch')

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="name">{{ __('Name') }} <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                        </div>
                        <input id="name" name="name" type="text" class="form-control @error('name') is-invalid @enderror" value="{{ old('name', $user->name) }}" required autofocus autocomplete="name">
                        @error('name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="email">{{ __('Email') }} <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        </div>
                        <input id="email" name="email" type="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email', $user->email) }}" required autocomplete="username">
                        @error('email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
        </div>

        @if ($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail())
            <div class="alert alert-warning d-flex align-items-center">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <div>
                    {{ __('Your email address is unverified.') }}
                    <button form="send-verification" class="btn btn-link btn-sm p-0 align-baseline">
                        {{ __('Re-send verification email') }}
                    </button>
                </div>
            </div>
        @endif

        <div class="profile-file mb-3">
            <label for="profile_picture" class="font-weight-bold">{{ __('Profile Picture') }}</label>
            <div class="row align-items-center">
                <div class="col-md-8">
                    <input id="profile_picture" name="profile_picture" type="file" class="form-control-file @error('profile_picture') is-invalid @enderror" accept="image/*">
                    <small class="form-text text-muted">{{ __('JPEG, PNG, JPG, or GIF. Maximum size: 2 MB.') }}</small>
                    @error('profile_picture')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-4 text-md-right mt-3 mt-md-0">
                    <img src="{{ $user->profile_picture ? asset('storage/' . $user->profile_picture) : asset('dist/img/user2-160x160.jpg') }}" alt="{{ __('Profile Picture') }}" class="img-circle elevation-2" style="width:72px;height:72px;object-fit:cover;">
                </div>
            </div>
        </div>

        <div class="text-right">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save mr-1"></i>{{ __('Save Changes') }}
            </button>
        </div>
    </form>
</div>
