@php $title = __('Lab Results - :name', ['name' => $labRequest->patientVisit->patient->full_name]); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card card-info card-outline">
            <div class="card-header border-bottom-0">
                <h3 class="card-title">
                    <i class="fas fa-flask mr-2"></i>{{ __('Test Results Entry') }}
                </h3>
                <div class="card-tools">
                    <span class="badge badge-{{ $labRequest->priority === 'urgent' ? 'danger' : ($labRequest->priority === 'stat' ? 'warning' : 'info') }} px-3 py-2">
                        <i class="fas fa-{{ $labRequest->priority === 'urgent' ? 'exclamation-circle' : ($labRequest->priority === 'stat' ? 'bolt' : 'clock') }} mr-1"></i>
                        {{ __(ucfirst($labRequest->priority)) }}
                    </span>
                </div>
            </div>
            <form id="lab-results-form" enctype="multipart/form-data">
                @csrf
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-top-0" width="25%">{{ __('Test') }}</th>
                                    <th class="border-top-0" width="20%">{{ __('Normal Range') }}</th>
                                    <th class="border-top-0" width="35%">{{ __('Result') }} <span class="text-danger">*</span></th>
                                    <th class="border-top-0" width="20%">{{ __('Remarks') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($labRequest->items as $item)
                                <tr>
                                    <td class="align-middle">
                                        <strong>{{ $item->labTest->name }}</strong>
                                        <input type="hidden" name="results[{{ $loop->index }}][lab_request_item_id]" value="{{ $item->id }}">
                                    </td>
                                    <td class="align-middle">
                                        <small class="text-muted">
                                            {{ $item->labTest->normal_range ?? '—' }}
                                            {{ $item->labTest->unit ?? '' }}
                                        </small>
                                    </td>
                                    <td>
                                        <input type="text" name="results[{{ $loop->index }}][result_value]"
                                               class="form-control form-control-sm" required
                                               placeholder="{{ __('Enter result value') }}">
                                    </td>
                                    <td>
                                        <input type="text" name="results[{{ $loop->index }}][remarks]"
                                               class="form-control form-control-sm"
                                               placeholder="{{ __('Optional') }}">
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="custom-file">
                                <input type="file" name="file" class="custom-file-input" id="labFile"
                                       accept=".pdf,.jpg,.png,.doc,.docx">
                                <label class="custom-file-label" for="labFile">{{ __('Choose file (optional)') }}</label>
                            </div>
                            <small class="text-muted">{{ __('PDF, JPG, PNG, DOC — max 10MB') }}</small>
                        </div>
                        <div class="col-md-6 text-md-right mt-3 mt-md-0">
                            <a href="{{ route('workflow.lab.pending') }}" class="btn btn-outline-secondary mr-2">
                                <i class="fas fa-times mr-1"></i>{{ __('Cancel') }}
                            </a>
                            <button type="submit" class="btn btn-info px-4">
                                <i class="fas fa-save mr-1"></i>{{ __('Save Results') }}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-user mr-2"></i>{{ __('Patient Info') }}</h3>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <div class="d-inline-block bg-primary rounded-circle p-3 mb-2" style="width: 70px; height: 70px;">
                        <i class="fas fa-user-injured text-white" style="font-size: 28px; line-height: 44px;"></i>
                    </div>
                    <h5 class="mb-0">{{ $labRequest->patientVisit->patient->full_name }}</h5>
                    <small class="text-muted">{{ __('MRN') }}: {{ $labRequest->patientVisit->patient->mrn }}</small>
                </div>
                <hr class="my-3">
                <dl class="row mb-0">
                    <dt class="col-sm-5 text-muted">{{ __('Doctor') }}</dt>
                    <dd class="col-sm-7">{{ $labRequest->doctor?->employee?->full_name ?? 'N/A' }}</dd>
                    <dt class="col-sm-5 text-muted">{{ __('Request Code') }}</dt>
                    <dd class="col-sm-7"><code>{{ $labRequest->request_code }}</code></dd>
                    <dt class="col-sm-5 text-muted">{{ __('Requested') }}</dt>
                    <dd class="col-sm-7">{{ displayDate($labRequest->request_date, 'Y-m-d H:i') }}</dd>
                    <dt class="col-sm-5 text-muted">{{ __('Tests') }}</dt>
                    <dd class="col-sm-7">{{ $labRequest->items->count() }}</dd>
                </dl>
            </div>
        </div>
        <div class="card card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-clipboard-list mr-2"></i>{{ __('Test Summary') }}</h3>
            </div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush">
                    @foreach($labRequest->items as $item)
                    <li class="list-group-item d-flex justify-content-between align-items-center py-2">
                        <span>{{ $item->labTest->name }}</span>
                        <span class="badge badge-light border">{{ number_format($item->price, 2) }} {{ __('AFN') }}</span>
                    </li>
                    @endforeach
                </ul>
            </div>
            <div class="card-footer text-right">
                <strong>{{ __('Total') }}: {{ number_format($labRequest->items->sum('price'), 2) }} {{ __('AFN') }}</strong>
            </div>
        </div>
    </div>
</div>

@push('js')
<script>
$(document).ready(function() {
    bsCustomFileInput ? bsCustomFileInput.init() : null;

    $('#lab-results-form').on('submit', function(e) {
        e.preventDefault();
        var btn = $(this).find('button[type="submit"]')
            .html('<i class="fas fa-spinner fa-spin mr-1"></i> Saving...')
            .prop('disabled', true);
        var formData = new FormData(this);
        $.ajax({
            url: '{{ route("workflow.lab.save-result", $labRequest->id) }}',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                if (res.success) window.location.href = res.redirect;
            },
            error: function(xhr) {
                alert(xhr.responseJSON?.message || '{{ __("Error saving results.") }}');
                btn.html('<i class="fas fa-save mr-1"></i>{{ __("Save Results") }}')
                    .prop('disabled', false);
            }
        });
    });
});
</script>
@endpush
@endsection