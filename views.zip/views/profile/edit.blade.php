@php
    $title = __('Profile');
    $profilePhoto = $user->profile_picture
        ? asset('storage/' . $user->profile_picture)
        : asset('dist/img/user2-160x160.jpg');
    $roles = $user->relationLoaded('roles') ? $user->roles : $user->roles()->get();
@endphp

@extends('layouts.admin')

@section('content')
<style>
    .profile-hero {
        background: #fff;
        border: 1px solid #e9ecef;
        border-radius: .5rem;
        box-shadow: 0 10px 30px rgba(33, 37, 41, .06);
        overflow: hidden;
    }

    .profile-hero-bar {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        height: 86px;
    }

    .profile-avatar {
        border: 4px solid #fff;
        box-shadow: 0 8px 20px rgba(0, 0, 0, .14);
        height: 112px;
        object-fit: cover;
        width: 112px;
    }

    .profile-hero-body {
        margin-top: -56px;
        padding: 0 1.5rem 1.5rem;
    }

    .profile-meta {
        color: #6c757d;
        font-size: .9rem;
    }

    .profile-card {
        border: 1px solid #e9ecef;
        border-radius: .5rem;
        box-shadow: 0 8px 24px rgba(33, 37, 41, .045);
    }

    .profile-card .card-header {
        background: #fff;
        border-bottom: 1px solid #eef0f2;
        padding: 1rem 1.25rem;
    }

    .profile-card .card-title {
        font-size: 1rem;
        font-weight: 700;
    }

    .profile-card .card-subtitle {
        color: #6c757d;
        font-size: .85rem;
        margin-top: .2rem;
    }

    .profile-danger-card {
        border-color: #f5c2c7;
    }

    .profile-danger-card .card-header {
        background: #fff8f8;
        border-bottom-color: #f5c2c7;
    }

    .profile-file {
        border: 1px dashed #ced4da;
        border-radius: .5rem;
        padding: 1rem;
    }
</style>

<div class="row">
    <div class="col-lg-4">
        <div class="profile-hero mb-4">
            <div class="profile-hero-bar"></div>
            <div class="profile-hero-body text-center">
                <img src="{{ $profilePhoto }}" alt="{{ $user->name }}" class="profile-avatar img-circle mb-3">
                <h3 class="mb-1">{{ $user->name }}</h3>
                <div class="profile-meta mb-3">{{ $user->email }}</div>

                <div class="mb-3">
                    @forelse($roles as $role)
                        <span class="badge badge-primary px-2 py-1">{{ __(str($role->name)->replace('-', ' ')->title()->toString()) }}</span>
                    @empty
                        <span class="badge badge-light border px-2 py-1">{{ __('No Role Assigned') }}</span>
                    @endforelse
                </div>

                <div class="row text-center">
                    <div class="col-6 border-right">
                        <div class="text-muted small">{{ __('Joined') }}</div>
                        <strong>{{ displayDate($user->created_at, 'Y-m-d') }}</strong>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small">{{ __('Email Status') }}</div>
                        @if($user->email_verified_at)
                            <strong class="text-success">{{ __('Verified') }}</strong>
                        @else
                            <strong class="text-warning">{{ __('Unverified') }}</strong>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <div class="card profile-card profile-danger-card">
            @include('profile.partials.delete-user-form')
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card profile-card mb-4">
            @include('profile.partials.update-profile-information-form')
        </div>

        <div class="card profile-card">
            @include('profile.partials.update-password-form')
        </div>
    </div>
</div>
@endsection
