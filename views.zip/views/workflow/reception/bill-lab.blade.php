@php $title = __('Lab Request - :name', ['name' => $visit->patient->full_name]); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-md-8"><div class="card card-info">
        <div class="card-header"><h3 class="card-title">{{ __('Patient') }}: {{ $visit->patient->full_name }} ({{ $visit->patient->mrn }})</h3></div>
        <div class="card-body">
            @if($invoice)
            <div class="alert alert-success">
                <h5><i class="fas fa-check-circle"></i> {{ __('Invoice Generated') }}</h5>
                <p>{{ __('Invoice #') }}: <strong>{{ $invoice->invoice_number }}</strong> | {{ __('Total') }}: <strong>{{ number_format($invoice->total, 2) }} {{ __('AFN') }}</strong></p>
                <a href="{{ route('invoices.print', $invoice->id) }}" class="btn btn-primary"><i class="fas fa-print"></i> {{ __('Print Bill') }}</a>
                <button class="btn btn-success confirm-payment" data-invoice="{{ $invoice->id }}"><i class="fas fa-check"></i> {{ __('Confirm Payment') }}</button>
            </div>
            @else
            <form id="lab-bill-form" method="POST" action="{{ route('workflow.reception.generate-bill', $visit->id) }}">
                @csrf
                <div class="form-group"><label>{{ __('Select Lab Tests') }} <span class="text-danger">*</span></label>
                    <select class="form-control select2" id="lab-test-select" multiple style="width:100%">
                        @foreach ($labTests as $t)<option value="{{ $t->id }}" data-price="{{ $t->price }}">{{ $t->name }} - {{ number_format($t->price, 2) }} {{ __('AFN') }}</option>@endforeach
                    </select>
                </div>
                <table class="table table-sm" id="selected-tests">
                    <thead><tr><th>{{ __('Test') }}</th><th>{{ __('Price') }}</th><th>{{ __('Action') }}</th></tr></thead>
                    <tbody></tbody>
                    <tfoot><tr class="font-weight-bold"><td>{{ __('Total') }}</td><td id="total-amount">0.00 {{ __('AFN') }}</td><td></td></tr></tfoot>
                </table>
                <button type="submit" class="btn btn-info btn-lg"><i class="fas fa-file-invoice"></i> {{ __('Generate Bill') }}</button>
            </form>
            @endif
        </div>
    </div></div>
    <div class="col-md-4">
        <div class="card"><div class="card-header"><h3 class="card-title">{{ __('Patient Info') }}</h3></div>
            <div class="card-body">
                <dl>
                    <dt>{{ __('Name') }}</dt><dd>{{ $visit->patient->full_name }}</dd>
                    <dt>{{ __('MRN') }}</dt><dd>{{ $visit->patient->mrn }}</dd>
                    <dt>{{ __('Phone') }}</dt><dd>{{ $visit->patient->phone }}</dd>
                    <dt>{{ __('Gender') }}</dt><dd>{{ __(ucfirst($visit->patient->gender)) }}</dd>
                    <dt>{{ __('Visit Code') }}</dt><dd>{{ $visit->visit_code }}</dd>
                </dl>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="bankModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">{{ __('Select Bank Account') }}</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <div class="form-group">
                    <label>{{ __('Bank Account') }}</label>
                    <select id="bank_account_id" class="form-control">
                        <option value="">{{ __('Cash (On Hand)') }}</option>
                        @foreach($bankAccounts as $ba)
                            <option value="{{ $ba->id }}">{{ $ba->account_name }} ({{ $ba->bank_name }} - {{ $ba->account_number }})</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-success" id="confirmCollect">{{ __('Confirm & Collect') }}</button>
            </div>
        </div>
    </div>
</div>

@push('js')
<script>
$(document).ready(function() {
    var pendingInvoiceId = null;

    $('.select2').select2({theme: 'bootstrap4'});
    var selected = {};
    $('#lab-test-select').on('change', function() {
        var ids = $(this).val() || [];
        var tbody = $('#selected-tests tbody');
        tbody.empty();
        var total = 0;
        ids.forEach(function(id) {
            var opt = $(this).find('option[value="'+id+'"]');
            var name = opt.text().split(' - ')[0];
            var price = parseFloat(opt.data('price'));
            total += price;
            tbody.append('<tr><td>'+name+'</td><td>'+price.toFixed(2)+' {{ __('AFN') }}</td><td><button type="button" class="btn btn-sm btn-danger remove-test" data-id="'+id+'"><i class="fas fa-times"></i></button></td></tr>');
        }.bind(this));
        $('#total-amount').text(total.toFixed(2)+' {{ __('AFN') }}');
    });
    $(document).on('click', '.remove-test', function() {
        var id = $(this).data('id');
        var select = $('#lab-test-select');
        var vals = select.val() || [];
        select.val(vals.filter(function(v) { return v != id; })).trigger('change');
    });
    $('#lab-bill-form').on('submit', function(e) {
        e.preventDefault();
        var ids = $('#lab-test-select').val();
        if (!ids || !ids.length) { alert(@json(__('Please select at least one test.'))); return; }
        $.ajax({
            url: '{{ route("workflow.reception.generate-bill", $visit->id) }}',
            method: 'POST',
            data: {_token: '{{ csrf_token() }}', lab_test_ids: ids},
            success: function(res) {
                if (res.success) { window.location.href = res.redirect; }
            },
            error: function(xhr) { alert(@json(__('Error:')) + ' ' + (xhr.responseJSON?.message || xhr.statusText || @json(__('Unknown')))); }
        });
    });
    $(document).on('click', '.confirm-payment', function() {
        pendingInvoiceId = $(this).data('invoice');
        $('#bankModal').modal('show');
    });

    $('#confirmCollect').on('click', function() {
        if (!pendingInvoiceId) return;
        $('#confirmCollect').html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.reception.confirm-payment", ["invoice" => "__INVOICE__"]) }}'.replace('__INVOICE__', pendingInvoiceId),
            method: 'POST',
            data: {_token: '{{ csrf_token() }}', bank_account_id: $('#bank_account_id').val()},
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function() { alert('{{ __("Error processing payment.") }}'); $('#confirmCollect').html('{{ __("Confirm & Collect") }}').prop('disabled', false); $('#bankModal').modal('hide'); }
        });
    });
});
</script>
@endpush
@endsection
