<div class="card-header">
    <h3 class="card-title mb-0 text-danger">
        <i class="fas fa-triangle-exclamation mr-2"></i>{{ __('Danger Zone') }}
    </h3>
    <div class="card-subtitle">{{ __('Permanent account actions are controlled here.') }}</div>
</div>

<div class="card-body">
    <p class="text-muted mb-3">
        {{ __('Deleting your account will permanently remove your access and account data. This action cannot be undone.') }}
    </p>

    <button type="button" class="btn btn-outline-danger btn-block" data-toggle="modal" data-target="#confirm-user-deletion">
        <i class="fas fa-trash-alt mr-1"></i>{{ __('Delete Account') }}
    </button>
</div>

<div class="modal fade" id="confirm-user-deletion" tabindex="-1" role="dialog" aria-labelledby="confirm-user-deletion-title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <form method="post" action="{{ route('profile.destroy') }}" class="modal-content">
            @csrf
            @method('delete')

            <div class="modal-header bg-danger">
                <h5 class="modal-title" id="confirm-user-deletion-title">
                    <i class="fas fa-trash-alt mr-2"></i>{{ __('Delete Account') }}
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="{{ __('Close') }}">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <p class="mb-3">
                    {{ __('Please enter your password to confirm you would like to permanently delete your account.') }}
                </p>

                <div class="form-group mb-0">
                    <label for="password">{{ __('Password') }}</label>
                    <input id="password" name="password" type="password" class="form-control @if($errors->userDeletion->has('password')) is-invalid @endif" placeholder="{{ __('Password') }}">
                    @if($errors->userDeletion->has('password'))
                        <div class="invalid-feedback">{{ $errors->userDeletion->first('password') }}</div>
                    @endif
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">{{ __('Cancel') }}</button>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-trash-alt mr-1"></i>{{ __('Delete Account') }}
                </button>
            </div>
        </form>
    </div>
</div>

@if($errors->userDeletion->isNotEmpty())
    @push('js')
        <script>
            $(function () {
                $('#confirm-user-deletion').modal('show');
            });
        </script>
    @endpush
@endif
