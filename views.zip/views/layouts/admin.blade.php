@php
    $isRtl = app()->getLocale() === 'fa';
@endphp
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{ $isRtl ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="calendar-type" content="{{ $system_settings['calendar_type'] ?? 'gregorian' }}">
    <title>{{ __($title ?? $system_settings['site_name']) }}</title>
    @vite(['resources/js/app.js'])
    <link rel="stylesheet" href="{{ asset('vendor/persian-datepicker/css/persian-datepicker.min.css') }}">
    <!-- Fonts -->
    <link rel="stylesheet" href="{{ asset('vendor/fonts/source-sans-pro.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/fonts/noto-naskh-arabic.css') }}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('vendor/fontawesome-free/css/all.min.css') }}">
    <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset('vendor/datatables/1.13.4/css/dataTables.bootstrap4.min.css') }}">
    <!-- Select2 -->
    <link rel="stylesheet" href="{{ asset('vendor/select2/4.0.13/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/select2/4.0.13/css/select2-bootstrap4.min.css') }}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('vendor/adminlte/3.2/css/adminlte.min.css') }}">
    @php
        $primary = $system_settings['primary_color'] ?? '#2e7d32';
        $secondary = $system_settings['secondary_color'] ?? '#1b5e20';
    @endphp
    <style>:root { --primary: {{ $primary }}; --secondary: {{ $secondary }}; }</style>
    <link rel="stylesheet" href="{{ asset('css/modern-admin.css') }}?v={{ filemtime(public_path('css/modern-admin.css')) }}">
    @stack('css')
    <link rel="stylesheet" href="{{ asset('vendor/fonts/dari.css') }}?v={{ filemtime(public_path('vendor/fonts/dari.css')) }}">
</head>
<body class="hold-transition sidebar-mini layout-fixed {{ request()->routeIs('dashboard') ? 'dashboard-page' : '' }}">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars" aria-hidden="true"></i><span class="sr-only">{{ __('Toggle navigation') }}</span></a>
      </li>
    </ul>

    <div class="workspace-context d-none d-md-flex"><span class="workspace-context__mark"><i class="fas fa-hospital" aria-hidden="true"></i></span><div><strong>{{ __('Hospital workspace') }}</strong><small>{{ __($title ?? 'Dashboard') }}</small></div></div>
    @auth
      @php
          $notifications = auth()->user()->hasPermission('notifications.index') ? auth()->user()->unreadNotifications()->latest()->take(5)->get() : collect();
          $notificationCount = $notifications->count();
      @endphp

      <ul class="navbar-nav ml-auto">
        <li class="nav-item workspace-date d-none d-lg-flex"><i class="far fa-calendar-alt" aria-hidden="true"></i><span>{{ displayDate(now(), 'd M Y') }}</span></li>
        <li class="nav-item dropdown">
          <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="far fa-bell"></i>
            @if ($notificationCount > 0)
              <span class="badge badge-warning navbar-badge">{{ $notificationCount }}</span>
            @endif
          </a>
          <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="min-width: 400px;">
            <span class="dropdown-header">{{ __(':count Notifications', ['count' => $notificationCount]) }}</span>
            <div class="dropdown-divider"></div>
            @forelse ($notifications as $notification)
              <a href="{{ $notification->data['url'] ?? '#' }}" class="dropdown-item notify-item" data-id="{{ $notification->id }}" data-url="{{ $notification->data['url'] ?? '#' }}">
                <i class="fas fa-envelope mr-2"></i> {{ \App\Support\NotificationText::message($notification->data) ?: __($notification->data['title'] ?? '') }}
                <span class="float-right text-muted text-sm">{{ $notification->created_at->diffForHumans() }}</span>
              </a>
              <div class="dropdown-divider"></div>
            @empty
              <span class="dropdown-item dropdown-header">{{ __('No new referrals') }}</span>
              <div class="dropdown-divider"></div>
            @endforelse
            <a href="{{ route('notifications.index') }}" class="dropdown-item dropdown-footer">{{ __('See all notifications') }}</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="fas fa-language"></i>
            <span>{{ app()->getLocale() === 'fa' ? __('Dari') : __('English') }}</span>
          </a>
          <div class="dropdown-menu dropdown-menu-right">
            <a href="{{ route('locale.switch', 'en') }}" class="dropdown-item {{ app()->getLocale() === 'en' ? 'active' : '' }}">{{ __('English') }}</a>
            <a href="{{ route('locale.switch', 'fa') }}" class="dropdown-item {{ app()->getLocale() === 'fa' ? 'active' : '' }}">{{ __('Dari') }}</a>
          </div>
        </li>
        <li class="nav-item dropdown user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
            @if(Auth::user()->profile_picture)
              <img src="{{ asset('storage/' . Auth::user()->profile_picture) }}" class="user-image img-circle" alt="{{ Auth::user()->name }}">
            @else
              <span class="user-avatar" aria-hidden="true">{{ mb_substr(Auth::user()->name, 0, 1) }}</span>
            @endif
            <span class="d-none d-md-inline">{{ Auth::user()->name }}</span>
          </a>
          <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <li class="user-header bg-primary">
              @if(Auth::user()->profile_picture)
                <img src="{{ asset('storage/' . Auth::user()->profile_picture) }}" class="img-circle" alt="{{ Auth::user()->name }}">
              @else
                <span class="user-avatar user-avatar--large" aria-hidden="true">{{ mb_substr(Auth::user()->name, 0, 1) }}</span>
              @endif
              <p>
                {{ Auth::user()->name }}
                <small>{{ Auth::user()->email }}</small>
              </p>
            </li>
            <!-- Menu Footer-->
            <li class="user-footer">
              <a href="{{ route('profile.edit') }}" class="btn btn-default btn-flat">{{ __('Profile') }}</a>
              <form method="POST" action="{{ route('logout') }}" style="display: inline;">
                @csrf
                <button type="submit" class="btn btn-default btn-flat float-right">{{ __('Sign out') }}</button>
              </form>
            </li>
          </ul>
        </li>
      </ul>
    @endauth
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/" class="brand-link text-center d-block">
      <span class="brand-symbol" aria-hidden="true"><i class="fas fa-plus"></i></span>
      <span class="brand-text"><strong>{{ __($system_settings['site_name'] ?? config('app.name', 'Alshefa HMS')) }}</strong><small>{{ __('Care, connected.') }}</small></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <div class="sidebar-workspace"><span class="workspace-dot" aria-hidden="true"></span>{{ __('Management workspace') }}</div>
      <div class="sidebar-search"><i class="fas fa-search" aria-hidden="true"></i><input type="search" id="admin-menu-search" placeholder="{{ __('Find a page...') }}" aria-label="{{ __('Search navigation') }}" autocomplete="off"><kbd>/</kbd></div>
      <p class="sidebar-search-empty" id="admin-menu-empty" hidden>{{ __('No matching pages') }}</p>
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          @php
            $icons = [
                'users' => 'fas fa-users',
                'roles' => 'fas fa-user-tag',
                'permissions' => 'fas fa-key',
                'hospital-branches' => 'fas fa-hospital',
                'departments' => 'fas fa-building',
                'designations' => 'fas fa-id-badge',
                'employees' => 'fas fa-user-tie',
                'doctors' => 'fas fa-user-md',
                'nurses' => 'fas fa-user-nurse',
                'lab-technicians' => 'fas fa-flask',
                'pharmacists' => 'fas fa-pills',
                'cashiers' => 'fas fa-cash-register',
                'patients' => 'fas fa-procedures',
                'patient-visits' => 'fas fa-calendar-check',
                'opd-registrations' => 'fas fa-clipboard-list',
                'patient-vitals' => 'fas fa-heartbeat',
                'appointments' => 'fas fa-calendar-check',
                'queue-tickets' => 'fas fa-ticket-alt',
                'emergency-triages' => 'fas fa-ambulance',
                'pregnancy-records' => 'fas fa-female',
                'delivery-records' => 'fas fa-baby-carriage',
                'newborn-records' => 'fas fa-baby',
                'blood-donors' => 'fas fa-hand-holding-heart',
                'blood-units' => 'fas fa-tint',
                'transfusion-requests' => 'fas fa-syringe',
                'wards' => 'fas fa-procedures',
                'rooms' => 'fas fa-door-closed',
                'beds' => 'fas fa-bed',
                'admissions' => 'fas fa-hospital-user',
                'bed-assignments' => 'fas fa-procedures',
                'ipd-daily-charges' => 'fas fa-file-invoice-dollar',
                'nursing-notes' => 'fas fa-notes-medical',
                'medicine-administrations' => 'fas fa-pills',
                'patient-progress-notes' => 'fas fa-notes-medical',
                'consultations' => 'fas fa-stethoscope',
                'consultation-symptoms' => 'fas fa-thermometer-half',
                'consultation-diagnoses' => 'fas fa-diagnoses',
                'prescriptions' => 'fas fa-prescription',
                'prescription-items' => 'fas fa-prescription-bottle',
                'doctor-notes' => 'fas fa-notes-medical',
                'follow-ups' => 'fas fa-calendar-plus',
                'lab-test-categories' => 'fas fa-vials',
                'lab-tests' => 'fas fa-microscope',
                'lab-requests' => 'fas fa-file-medical',
                'lab-request-items' => 'fas fa-file-alt',
                'lab-samples' => 'fas fa-syringe',
                'lab-results' => 'fas fa-chart-line',
                'lab-result-items' => 'fas fa-chart-bar',
                'radiology-categories' => 'fas fa-x-ray',
                'radiology-tests' => 'fas fa-radiation',
                'radiology-requests' => 'fas fa-file-image',
                'radiology-request-items' => 'fas fa-images',
                'radiology-results' => 'fas fa-image',
                'radiology-images' => 'fas fa-photo-video',
                'medicine-categories' => 'fas fa-tags',
                'medicine-units' => 'fas fa-balance-scale',
                'medicines' => 'fas fa-medkit',
                'medicine-batches' => 'fas fa-boxes',
                'suppliers' => 'fas fa-truck',
                'medicine-purchases' => 'fas fa-shopping-cart',
                'medicine-purchase-items' => 'fas fa-cart-plus',
                'pharmacy-sales' => 'fas fa-cash-register',
                'pharmacy-sale-items' => 'fas fa-receipt',
                'medicine-returns' => 'fas fa-undo',
                'stock-adjustments' => 'fas fa-adjust',
                'stock-ledgers' => 'fas fa-book',
                'pharmacy-bills' => 'fas fa-file-invoice-dollar',
                'accounting-entries' => 'fas fa-calculator',
                'patient-guardians' => 'fas fa-user-friends',
                'referral-sources' => 'fas fa-share-alt',
                'insurance-companies' => 'fas fa-shield-alt',
                'insurance-claims' => 'fas fa-file-medical-alt',
                'insurance-plans' => 'fas fa-file-contract',
                'insurance-authorizations' => 'fas fa-stamp',
                'companies' => 'fas fa-building',
                'operation-theaters' => 'fas fa-procedures',
                'surgery-categories' => 'fas fa-list-alt',
                'surgeries' => 'fas fa-user-md',
                'surgery-schedules' => 'fas fa-calendar-check',
                'surgery-team-members' => 'fas fa-user-nurse',
                'anesthesia-records' => 'fas fa-syringe',
                'operation-notes' => 'fas fa-notes-medical',
                'post-operation-notes' => 'fas fa-file-medical',
                'service-categories' => 'fas fa-tags',
                'services' => 'fas fa-concierge-bell',
                'system-settings' => 'fas fa-cog',
                'invoices' => 'fas fa-file-invoice-dollar',
                'opd-invoices' => 'fas fa-file-invoice-dollar',
                'ipd-invoices' => 'fas fa-file-invoice-dollar',
                'invoice-items' => 'fas fa-list',
                'payment-methods' => 'fas fa-credit-card',
                'payments' => 'fas fa-money-bill-wave',
                'discounts' => 'fas fa-percent',
                'refunds' => 'fas fa-undo-alt',
                'account-groups' => 'fas fa-folder',
                'chart-of-accounts' => 'fas fa-book',
                'journal-entries' => 'fas fa-journal-whills',
                'journal-entry-items' => 'fas fa-list',
                'cashier-sessions' => 'fas fa-cash-register',
                'cashier-collections' => 'fas fa-coins',
                'expense-categories' => 'fas fa-tags',
                'expenses' => 'fas fa-money-bill-wave',
            ];
            $modules = [
                'User Management' => [
                    'users' => 'Users',
                    'roles' => 'Roles',
                    'permissions' => 'Permissions',
                ],
                'Hospital Setup' => [
                    'hospital-branches' => 'Hospital Branches',
                    'departments' => 'Departments',
                    'designations' => 'Designations',
                ],
                'Staff' => [
                    'employees' => 'Employees',
                    'doctors' => 'Doctors',
                    'nurses' => 'Nurses',
                    'lab-technicians' => 'Lab Technicians',
                    'pharmacists' => 'Pharmacists',
                    'cashiers' => 'Cashiers',
                ],
                'Patients' => [
                    'patients' => 'Patient Records',
                    'appointments' => 'Appointments',
                    'queue-tickets' => 'Queue Tickets',
                    'patient-vitals' => 'Patient Vitals',
                ],
                'Emergency' => ['emergency-triages' => 'Emergency Triage'],
                'Maternal & Newborn' => [
                    'pregnancy-records' => 'Pregnancy Records',
                    'delivery-records' => 'Delivery Records',
                    'newborn-records' => 'Newborn Records',
                ],
                'Blood Bank' => [
                    'blood-donors' => 'Blood Donors',
                    'blood-units' => 'Blood Units',
                    'transfusion-requests' => 'Transfusion Requests',
                ],
                'In-Patient' => [
                    'wards' => 'Wards',
                    'rooms' => 'Rooms',
                    'beds' => 'Beds',
                    'admissions' => 'Admissions',
                    'bed-assignments' => 'Bed Assignments',
                    'ipd-daily-charges' => 'IPD Daily Charges',
                    'nursing-notes' => 'Nursing Notes',
                    'medicine-administrations' => 'Medicine Administrations',
                    'patient-progress-notes' => 'Patient Progress Notes',
                ],
                'Surgery / OT' => [
                    'operation-theaters' => 'Operation Theaters',
                    'surgery-categories' => 'Surgery Categories',
                    'surgeries' => 'Surgeries',
                    'surgery-schedules' => 'Surgery Schedules',
                    'surgery-team-members' => 'Surgery Team Members',
                    'anesthesia-records' => 'Anesthesia Records',
                    'operation-notes' => 'Operation Notes',
                    'post-operation-notes' => 'Post Operation Notes',
                ],
                'Billing' => [
                    'service-categories' => 'Service Categories',
                    'services' => 'Services',
                    'opd-invoices' => 'OPD Invoices',
                    'ipd-invoices' => 'IPD Invoices',
                    'payment-methods' => 'Payment Methods',
                    'payments' => 'Payments',
                    'insurance-claims' => 'Insurance Claims',
                    'insurance-plans' => 'Insurance Plans',
                    'insurance-authorizations' => 'Insurance Authorizations',
                    'discounts' => 'Discounts',
                    'refunds' => 'Refunds',
                ],
                'Accounting' => [
                    'account-groups' => 'Account Groups',
                    'chart-of-accounts' => 'Chart of Accounts',
                    'journal-entries' => 'Journal Entries',
                    'cashier-sessions' => 'Cashier Sessions',
                    'cashier-collections' => 'Cashier Collections',
                    'bank-accounts' => 'Bank Accounts',
                    'bank-transfers' => 'Bank Transfers',
                    'expense-categories' => 'Expense Categories',
                    'expenses' => 'Expenses',
                    'accounting-entries' => 'Accounting Entries',
                ],
                'Consultations' => [
                    'consultations' => 'Consultations',
                    'doctor-notes' => 'Doctor Notes',
                    'follow-ups' => 'Follow Ups',
                ],
                'Laboratory' => [
                    'lab-test-categories' => 'Lab Test Categories',
                    'lab-tests' => 'Lab Tests',
                    'lab-requests' => 'Lab Requests',
                    'lab-samples' => 'Lab Samples',
                    'lab-results' => 'Lab Results',
                ],
                'Radiology' => [
                    'radiology-categories' => 'Radiology Categories',
                    'radiology-tests' => 'Radiology Tests',
                    'radiology-requests' => 'Radiology Requests',
                    'radiology-results' => 'Radiology Results',
                ],
                'Pharmacy' => [
                    'medicine-categories' => 'Medicine Categories',
                    'medicine-units' => 'Medicine Units',
                    'medicines' => 'Medicines',
                    'medicine-batches' => 'Medicine Batches',
                    'suppliers' => 'Suppliers',
                    'medicine-purchases' => 'Medicine Purchases',
                    'pharmacy-sales' => 'Pharmacy Sales',
                    'medicine-returns' => 'Medicine Returns',
                    'stock-adjustments' => 'Stock Adjustments',
                    'stock-ledgers' => 'Stock Ledgers',
                    'pharmacy-bills' => 'Pharmacy Bills',
                    'prescriptions' => 'Prescriptions',
                ],
                'Settings' => [
                    'system-settings' => 'System Settings',
                ],
                'Others' => [
                    'patient-guardians' => 'Patient Guardians',
                    'referral-sources' => 'Referral Sources',
                    'insurance-companies' => 'Insurance Companies',
                    'companies' => 'Companies',
                ],
            ];
            $modulePermissions = [
                'User Management' => 'registration.index',
                'Hospital Setup' => 'registration.index',
                'Staff' => 'registration.index',
                'Patients' => 'registration.index',
                'Emergency' => 'consultation.index',
                'Maternal & Newborn' => 'consultation.index',
                'Blood Bank' => 'laboratory.index',
                'In-Patient' => 'ipd.index',
                'Surgery / OT' => 'ot.index',
                'Billing' => 'billing.index',
                'Accounting' => 'accounting.index',
                'Consultations' => 'consultation.index',
                'Laboratory' => 'laboratory.index',
                'Radiology' => 'radiology.index',
                'Pharmacy' => 'pharmacy.index',
                'Settings' => 'settings.index',
                'Others' => 'registration.index',
            ];
            $workflowLinks = [
                'receptionist' => [
                    ['url' => route('workflow.reception.register'), 'icon' => 'fas fa-user-plus', 'label' => __('Register Patient'), 'permission' => 'workflow.reception.register'],
                    ['url' => route('workflow.reception.collect-payments'), 'icon' => 'fas fa-hand-holding-usd', 'label' => __('Collect Payments'), 'permission' => 'workflow.reception.collect-payments'],
                    ['url' => route('workflow.quick-action.collections'), 'icon' => 'fas fa-bolt', 'label' => __('Quick Collections'), 'permission' => 'workflow.quick-action.collections'],
                ],
                'doctor' => [
                    ['url' => route('workflow.doctor.pending'), 'icon' => 'fas fa-stethoscope', 'label' => __('Pending Consultations'), 'permission' => 'workflow.doctor.pending'],
                    ['url' => route('workflow.quick-action.pending'), 'icon' => 'fas fa-bolt', 'label' => __('Quick Actions'), 'permission' => 'workflow.quick-action.pending'],
                    ['url' => route('workflow.doctor.patients'), 'icon' => 'fas fa-procedures', 'label' => __('My Patients'), 'permission' => 'workflow.doctor.patients'],
                ],
                'lab-technician' => [
                    ['url' => route('workflow.lab.pending'), 'icon' => 'fas fa-flask', 'label' => __('Pending Lab Tests'), 'permission' => 'workflow.lab.pending'],
                ],
                'pharmacist' => [
                    ['url' => route('workflow.pharmacy.pending'), 'icon' => 'fas fa-pills', 'label' => __('Dispense Medicine'), 'permission' => 'workflow.pharmacy.pending'],
                ],
                'cashier' => [
                    ['url' => route('workflow.cashier.pending'), 'icon' => 'fas fa-hand-holding-usd', 'label' => __('Pending Payments'), 'permission' => 'workflow.cashier.pending'],
                    ['url' => route('workflow.quick-action.collections'), 'icon' => 'fas fa-bolt', 'label' => __('Quick Collections'), 'permission' => 'workflow.quick-action.collections'],
                ],
                'super-admin' => [
                    ['url' => route('workflow.reception.register'), 'icon' => 'fas fa-user-plus', 'label' => __('Register Patient'), 'permission' => 'workflow.reception.register'],
                    ['url' => route('workflow.reception.collect-payments'), 'icon' => 'fas fa-hand-holding-usd', 'label' => __('Collect Payments'), 'permission' => 'workflow.reception.collect-payments'],
                    ['url' => route('workflow.quick-action.collections'), 'icon' => 'fas fa-bolt', 'label' => __('Quick Collections'), 'permission' => 'workflow.quick-action.collections'],
                    ['url' => route('workflow.quick-action.pending'), 'icon' => 'fas fa-bolt', 'label' => __('Quick Actions (Doctor)'), 'permission' => 'workflow.quick-action.pending'],
                    ['url' => route('workflow.reports.income'), 'icon' => 'fas fa-chart-bar', 'label' => __('Income Report'), 'permission' => 'workflow.reports.income'],
                    ['url' => route('workflow.reports.daily'), 'icon' => 'fas fa-calendar-day', 'label' => __('Daily Report'), 'permission' => 'workflow.reports.daily'],
                ],
            ];
            $workflows = collect($workflowLinks)
                ->flatten(1)
                ->unique('url')
                ->filter(fn ($link) => auth()->user()->hasPermission($link['permission']))
                ->values();
          @endphp
          @if(auth()->user()->hasPermission('dashboard.index'))
            <li class="nav-item"><a href="{{ route('dashboard') }}" class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}"><i class="nav-icon fas fa-th-large" aria-hidden="true"></i><p>{{ __('Overview') }}</p></a></li>
          @endif
          @if($workflows->isNotEmpty())
            <li class="nav-item has-treeview {{ request()->routeIs('workflow.*') ? 'menu-open' : '' }}">
              <a href="#" class="nav-link"><i class="nav-icon fas fa-heartbeat" aria-hidden="true"></i><p>{{ __('Daily workflows') }}<i class="right fas fa-angle-left" aria-hidden="true"></i></p></a>
              <ul class="nav nav-treeview">
            @foreach($workflows as $wl)
            <li class="nav-item">
                <a href="{{ $wl['url'] }}" class="nav-link">
                    <i class="nav-icon {{ $wl['icon'] }}"></i>
                    <p>{{ $wl['label'] }}</p>
                </a>
            </li>
            @endforeach
              </ul>
            </li>
            <li class="nav-header">{{ __('Management') }}</li>
          @endif
          @if(auth()->user()->hasPermission('data-sync.index'))
            <li class="nav-item">
                <a href="{{ route('data-sync.index') }}" class="nav-link {{ request()->routeIs('data-sync.*') ? 'active' : '' }}">
                    <i class="nav-icon fas fa-cloud-upload-alt"></i><p>{{ __('Data Synchronization') }}</p>
                </a>
            </li>
          @endif
          @php
            $resource = $resource ?? request()->route('resource');
            $activeModule = null;
            foreach ($modules as $module => $items) {
                if (array_key_exists($resource, $items)) {
                    $activeModule = $module;
                    break;
                }
            }
          @endphp
          @foreach ($modules as $module => $items)
            @php
                $modulePermission = $modulePermissions[$module] ?? null;
                $visibleItems = collect($items)->filter(fn ($label, $key) => array_key_exists($key, config('access.resources')))->filter(fn ($label, $key) => auth()->user()->hasPermission(\App\Http\Controllers\Admin\MasterResourceController::requiredPermission($key, 'index')));
            @endphp
            @if($visibleItems->isNotEmpty() && !($module === 'Pharmacy' && auth()->user()->hasRole('doctor')))
            <li class="nav-item has-treeview{{ $module === $activeModule ? ' menu-open' : '' }}">
              <a href="#" class="nav-link{{ $module === $activeModule ? ' active' : '' }}">
                <i class="nav-icon fas fa-folder"></i>
                <p>
                  {{ __($module) }}
                  <i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                @foreach ($visibleItems as $key => $label)
                  <li class="nav-item">
                    <a href="{{ route('masters.index', $key) }}" class="nav-link {{ ($resource ?? '') === $key ? 'active' : '' }}">
                      <i class="nav-icon {{ $icons[$key] ?? 'fas fa-circle' }}"></i>
                      <p>{{ __($label) }}</p>
                    </a>
                  </li>
                @endforeach
              </ul>
            </li>
            @endif
          @endforeach
          @if(auth()->user()->hasPermission('accounting.reports.index'))
            <li class="nav-item has-treeview">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-chart-line"></i>
                <p>
                  {{ __('Accounting Reports') }}
                  <i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="{{ route('accounting.reports.index') }}" class="nav-link {{ request()->routeIs('accounting.reports.*') ? 'active' : '' }}">
                    <i class="nav-icon fas fa-file-alt"></i>
                    <p>{{ __('Reports') }}</p>
                  </a>
                </li>
              </ul>
            </li>
          @endif
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <div class="page-eyebrow">{{ __('Workspace') }} <span>/</span> {{ __($title ?? 'Dashboard') }}</div>
            <h1 class="m-0">{{ __($title ?? 'Dashboard') }}</h1>
            <p class="page-description">{{ __('Everything you need, in one place.') }}</p>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        @yield('content')
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <strong>
      {{ __('Copyright') }} &copy; {{ displayDate(now(), 'Y') }}
      <a href="{{ route('dashboard') }}">{{ __($system_settings['site_name'] ?? config('app.name', 'Alshefa HMS')) }}</a>.
    </strong>
    <span class="footer-note">{{ __('Hospital Management System') }} <span class="workspace-dot" aria-hidden="true"></span></span>
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="{{ asset('vendor/jquery/3.6.0/jquery.min.js') }}"></script>
<!-- Persian Datepicker -->
<script src="{{ asset('vendor/persian-date/persian-date.min.js') }}"></script>
<script src="{{ asset('vendor/persian-datepicker/js/persian-datepicker.min.js') }}"></script>
<!-- Bootstrap 4 -->
<script src="{{ asset('vendor/bootstrap/4.6.2/js/bootstrap.bundle.min.js') }}"></script>
<!-- DataTables -->
<script src="{{ asset('vendor/datatables/1.13.4/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('vendor/datatables/1.13.4/js/dataTables.bootstrap4.min.js') }}"></script>
<!-- Select2 -->
<script src="{{ asset('vendor/select2/4.0.13/js/select2.min.js') }}"></script>
@if(app()->getLocale() === 'fa')
<script>
if ($.fn.select2) {
    $.fn.select2.amd.define('select2/i18n/fa', [], function () { return {
        errorLoading: function () { return @json(__('The results could not be loaded.')); },
        inputTooLong: function () { return @json(__('Please enter fewer characters.')); },
        inputTooShort: function () { return @json(__('Please enter more characters.')); },
        loadingMore: function () { return @json(__('Loading more results...')); },
        maximumSelected: function () { return @json(__('Selection limit reached.')); },
        noResults: function () { return @json(__('No results found.')); },
        searching: function () { return @json(__('Searching...')); },
        removeAllItems: function () { return @json(__('Remove all items')); }
    }; });
    $.fn.select2.defaults.set('language', 'fa');
    $.fn.select2.defaults.set('dir', 'rtl');
}
</script>
@endif
<!-- AdminLTE App -->
<script src="{{ asset('vendor/adminlte/3.2/js/adminlte.min.js') }}"></script>
<!-- SweetAlert2 -->
<script src="{{ asset('vendor/sweetalert2/11/sweetalert2.min.js') }}"></script>
<script>
$(document).ready(function() {
    // Initialize DataTables
    var locale = '{{ app()->getLocale() }}';
    if ($.fn.DataTable) {
        $('.table').DataTable({
            "paging": false,
            "lengthChange": false,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            "language": {
                @if(app()->getLocale() === 'fa')
                "url": "{{ asset('vendor/datatables/1.13.4/i18n/fa.json') }}",
                @endif
                "search": "{{ __('Search:') }}",
                "searchPlaceholder": "{{ __('Search...') }}",
                "info": "{{ __('Showing _START_ to _END_ of _TOTAL_ entries') }}",
                "infoEmpty": "{{ __('Showing 0 to 0 of 0 entries') }}",
                "infoFiltered": "{{ __('(filtered from _MAX_ total entries)') }}",
                "zeroRecords": "{{ __('No matching records found') }}",
                "emptyTable": "{{ __('No data available in table') }}"
            }
        });
    }

    // Initialize Select2 for all dropdowns except consultation form dynamic elements
    if ($.fn.select2) {
        $('select').not('.no-select2, #medicines-container select, #lab-tests-container select').each(function () {
            if (!$(this).hasClass('select2-hidden-accessible')) {
                $(this).select2({
                    theme: 'bootstrap4',
                    dir: document.documentElement.dir,
                    language: '{{ app()->getLocale() }}',
                    width: '100%'
                });
            }
        });
    }
});
</script>
<script>
$(document).ready(function() {
    $('.notify-item').on('click', function(e) {
        var item = $(this);
        var id = item.data('id');
        var url = item.data('url');
        if (!id || !url) return;

        e.preventDefault();

        var divider = item.next('.dropdown-divider');
        item.remove();
        divider.remove();

        var badge = $('.navbar-badge');
        if (badge.length) {
            var count = parseInt(badge.text());
            if (count > 1) {
                badge.text(count - 1);
            } else {
                badge.remove();
            }
        }

        var header = $('.dropdown-header');
        var remaining = $('.notify-item').length;
        header.text(remaining + ' {{ __("Notifications") }}');

        $.ajax({
            url: '{{ route("notifications.read", "__ID__") }}'.replace('__ID__', id),
            method: 'POST',
            data: {_token: '{{ csrf_token() }}'},
            complete: function() {
                window.location.href = url;
            }
        });
    });
});
</script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const search = document.getElementById('admin-menu-search');
    const menu = document.querySelector('.nav-sidebar');
    if (!search || !menu) return;
    const items = Array.from(menu.children).filter(item => item.classList.contains('nav-item'));
    let previousOpen = null;
    search.addEventListener('input', () => {
        const term = search.value.trim().toLocaleLowerCase();
        if (term && previousOpen === null) previousOpen = items.filter(item => item.classList.contains('menu-open'));
        let matches = 0;
        items.forEach(item => {
            const children = Array.from(item.querySelectorAll('.nav-treeview > .nav-item'));
            const link = Array.from(item.children).find(child => child.matches('a.nav-link'));
            const groupMatch = (link?.textContent || '').toLocaleLowerCase().includes(term);
            children.forEach(child => child.hidden = !!term && !groupMatch && !child.textContent.toLocaleLowerCase().includes(term));
            const visible = !term || groupMatch || children.some(child => !child.hidden);
            item.hidden = !visible;
            if (visible) matches++;
            if (term && children.length) item.classList.toggle('menu-open', visible);
            const tree = item.querySelector('.nav-treeview');
            if (tree) tree.style.display = term ? (visible ? 'block' : 'none') : '';
        });
        menu.querySelectorAll(':scope > .nav-header').forEach(header => header.hidden = !!term);
        if (!term && previousOpen !== null) {
            items.forEach(item => item.classList.toggle('menu-open', previousOpen.includes(item)));
            previousOpen = null;
        }
        document.getElementById('admin-menu-empty').hidden = matches > 0;
    });
    document.addEventListener('keydown', event => {
        if (event.key === '/' && !event.ctrlKey && !event.metaKey && !event.altKey && !event.target.closest('input, textarea, select, [contenteditable="true"]')) {
            event.preventDefault();
            search.focus();
        }
        if (event.key === 'Escape' && document.activeElement === search) {
            search.value = '';
            search.dispatchEvent(new Event('input'));
            search.blur();
        }
    });
});
</script>
@stack('js')
@include('partials.sweet-alerts')
</body>
</html>
