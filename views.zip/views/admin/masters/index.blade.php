@extends('layouts.admin', ['title' => $config['title'], 'resource' => $resource])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ __($config['title']) }}</h3>
                    <div class="card-tools">
                        @php
                            $userRoles = auth()->user()->roles->pluck('name')->toArray();
                            $restrictedRoles = ['doctor', 'lab-technician', 'pharmacist'];
                            $permissionFor = fn (string $action) => \App\Http\Controllers\Admin\MasterResourceController::requiredPermission($resource, $action);
                            $canCreate = auth()->user()->hasPermission($permissionFor('create')) && !($resource === 'patients' && array_intersect($userRoles, $restrictedRoles));
                        @endphp
                        @if($canCreate)
                        <a class="btn btn-primary btn-sm" href="{{ $resource === 'patients' ? route('workflow.reception.register') : route('masters.create', $resource) }}">
                            <i class="fas fa-plus"></i> {{ $resource === 'patients' ? __('Register Patient') : __('Create') }}
                        </a>
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    @if(in_array($resource, ['roles', 'permissions'], true))
                        <form method="get" class="row mb-3" action="{{ route('masters.index', $resource) }}">
                            <div class="col-md-7 mb-2"><input type="search" name="q" class="form-control" value="{{ request('q') }}" placeholder="{{ __('Search by name or key') }}" aria-label="{{ __('Search') }}"></div>
                            <div class="col-md-3 mb-2"><select name="status" class="form-control" aria-label="{{ __('Status') }}"><option value="">{{ __('All statuses') }}</option><option value="active" @selected(request('status') === 'active')>{{ __('Active') }}</option><option value="inactive" @selected(request('status') === 'inactive')>{{ __('Inactive') }}</option></select></div>
                            <div class="col-md-2 mb-2"><button class="btn btn-primary" type="submit">{{ __('Filter') }}</button> <a class="btn btn-light" href="{{ route('masters.index', $resource) }}">{{ __('Reset') }}</a></div>
                        </form>
                        <p class="text-muted small">{{ $resource === 'roles' ? __('Create a role, choose its permissions, then assign it to users. Users can have multiple roles.') : __('Friendly names and groups can be customized. Inactive permissions do not grant access. A custom permission key takes effect when a page or action checks that key.') }}</p>
                    @endif
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    @foreach ($config['columns'] as $column)
                                    <th>{{ __(str($column)->before('.')->replace('_id', '')->replace('_', ' ')->title()->toString()) }}</th>
                                @endforeach
                                <th>{{ __('Actions') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($records as $record)
                                <tr>
                                    @foreach ($config['columns'] as $column)
                                        <td>
                                            @include('admin.masters.partials.display-value', [
                                                'record' => $record,
                                                'name' => $column,
                                                'field' => $config['fields'][$column] ?? [],
                                            ])
                                        </td>
                                    @endforeach
                                    <td class="text-nowrap" style="white-space: nowrap;">
                                        @php
                                            $canShow = auth()->user()->hasPermission($permissionFor('show'));
                                            $canEdit = auth()->user()->hasPermission($permissionFor('edit'));
                                            $canDelete = auth()->user()->hasPermission($permissionFor('delete'));
                                            $canPrint = auth()->user()->hasPermission('invoices.print');
                                            $canCollectPayment = auth()->user()->hasPermission('workflow.reception.collect-payments');
                                            $canResetPassword = auth()->user()->hasPermission('users.reset-password');
                                            $canAcceptLabRequest = auth()->user()->hasPermission('lab-requests.accept');
                                        @endphp
                                        @if ($canShow)
                                        <a href="{{ route('masters.show', [$resource, $record]) }}" class="btn btn-info btn-sm" title="{{ __('View') }}" aria-label="{{ __('View') }}">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        @endif
                                        @if (in_array($resource, ['invoices', 'opd-invoices', 'ipd-invoices'], true))
                                            @if ($canPrint)
                                            <a href="{{ route('invoices.print', $record) }}" class="btn btn-success btn-sm" title="{{ __('Print') }}" aria-label="{{ __('Print') }}">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            @endif
                                        @endif
                                        @if ($resource === 'payments')
                                            @if ($canCollectPayment && $record->invoice && $record->invoice->status !== 'paid')
                                            <a href="{{ route('masters.edit', ['payments', $record]) }}" class="btn btn-primary btn-sm" title="{{ __('Collect Payment') }}" aria-label="{{ __('Collect Payment') }}">
                                                <i class="fas fa-hand-holding-usd"></i>
                                            </a>
                                            @endif
                                            @if ($canPrint && $record->invoice)
                                            <a href="{{ route('invoices.print', $record->invoice) }}" class="btn btn-success btn-sm" title="{{ __('Print Bill') }}" aria-label="{{ __('Print Bill') }}">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            @endif
                                        @endif
                                        @if ($resource === 'users' && $canResetPassword)
                                            <form method="post" action="{{ route('masters.users.reset-password', $record) }}" style="display:inline;" data-confirm="{{ __('Reset password for') }} {{ $record->name }}? {{ __('Default will be: Alshefa@2026') }}" data-confirm-button="{{ __('Yes, reset it') }}">
                                                @csrf
                                                <button class="btn btn-secondary btn-sm" type="submit" title="{{ __('Reset Password') }}" aria-label="{{ __('Reset Password') }}">
                                                    <i class="fas fa-key"></i>
                                                </button>
                                            </form>
                                        @endif
                                        @if ($resource === 'lab-requests' && $record->status === 'pending' && $canAcceptLabRequest)
                                            <form
                                                method="post"
                                                action="{{ route('masters.lab-requests.accept', $record) }}"
                                                style="display: inline;"
                                                data-confirm="{{ __('Are you sure you want to accept this lab request?') }}"
                                                data-confirm-button="{{ __('Yes, accept it') }}"
                                            >
                                                @csrf
                                                <button class="btn btn-success btn-sm" type="submit" title="{{ __('Accept Request') }}" aria-label="{{ __('Accept Request') }}">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                        @endif
                                        @if ($canEdit)
                                        <a href="{{ route('masters.edit', [$resource, $record]) }}" class="btn btn-warning btn-sm" title="{{ __('Edit') }}" aria-label="{{ __('Edit') }}">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        @endif
                                        @if ($canDelete)
                                        <form
                                            method="post"
                                            action="{{ route('masters.destroy', [$resource, $record]) }}"
                                            style="display: inline;"
                                            data-confirm="{{ __('This record will be archived.') }}"
                                            data-confirm-button="{{ __('Yes, archive it') }}"
                                        >
                                            @csrf
                                            @method('delete')
                                            <button class="btn btn-danger btn-sm" type="submit" title="{{ __('Delete') }}" aria-label="{{ __('Delete') }}">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="{{ count($config['columns']) + 1 }}">{{ __('No records yet.') }}</td>
                                </tr>
                            @endforelse
                        </tbody>
                        </table>
                    </div>

                    {{ $records->links('vendor.pagination.bootstrap-4') }}
                </div>
            </div>
        </div>
    </div>
@endsection
