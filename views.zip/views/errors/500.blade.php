<x-guest-layout>
    <div class="m3-title">
        <p>500</p>
        <h1>{{ __('Something went wrong') }}</h1>
        <p>{{ __('An unexpected error occurred. Please try again.') }}</p>
        <p><a href="{{ url('/') }}">{{ __('Back to home') }}</a></p>
    </div>
</x-guest-layout>
