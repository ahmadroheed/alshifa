@php
    $initials = collect([$patient->first_name, $patient->last_name])
        ->filter()->map(fn ($name) => mb_substr($name, 0, 1))->join('');
    $statusClass = $patient->status === 'active' ? 'success' : ($patient->status === 'deceased' ? 'danger' : 'secondary');
    $patientType = ucwords(str_replace('_', ' ', (string) $patient->patient_type));
    $empty = __('Not set');
@endphp

<div class="patient-profile">
    <section class="patient-profile__hero">
        <div class="patient-profile__identity">
            <div class="patient-profile__avatar">{{ $initials ?: 'P' }}</div>
            <div>
                <div class="patient-profile__eyebrow">{{ __('Medical Record') }}</div>
                <h2>{{ $patient->full_name ?: $empty }}</h2>
                <div class="patient-profile__meta">
                    <span><i class="fas fa-id-card"></i> {{ $patient->mrn ?: $empty }}</span>
                    <span><i class="fas fa-user-tag"></i> {{ $patient->patient_code ?: $empty }}</span>
                    <span class="badge badge-{{ $statusClass }}">{{ __(ucfirst($patient->status)) }}</span>
                </div>
            </div>
        </div>
        <div class="patient-profile__quick-stats">
            <div><strong>{{ $patient->visits()->count() }}</strong><span>{{ __('Visits') }}</span></div>
            <div><strong>{{ $patient->consultations->count() }}</strong><span>{{ __('Consultations') }}</span></div>
            <div><strong>{{ $patient->prescriptions->count() }}</strong><span>{{ __('Prescriptions') }}</span></div>
            <div><strong>{{ $patient->labRequests->count() }}</strong><span>{{ __('Lab Requests') }}</span></div>
        </div>
    </section>

    <div class="row patient-profile__sections">
        <div class="col-lg-4 mb-3">
            <section class="patient-info-card h-100">
                <h4><i class="fas fa-user"></i>{{ __('Personal Information') }}</h4>
                <div class="patient-info-list">
                    <div><span>{{ __('Father Name') }}</span><strong>{{ $patient->father_name ?: $empty }}</strong></div>
                    <div><span>{{ __('Gender') }}</span><strong>{{ filled($patient->gender) ? __(ucfirst($patient->gender)) : $empty }}</strong></div>
                    <div><span>{{ __('Date of Birth') }}</span><strong>{{ $patient->date_of_birth ? displayDate($patient->date_of_birth, 'Y-m-d') : $empty }}</strong></div>
                    <div><span>{{ __('Blood Group') }}</span><strong dir="ltr">{{ $patient->blood_group ?: $empty }}</strong></div>
                    <div><span>{{ __('Marital Status') }}</span><strong>{{ filled($patient->marital_status) ? __(ucfirst($patient->marital_status)) : $empty }}</strong></div>
                    <div><span>{{ __('Tazkira Number') }}</span><strong>{{ $patient->tazkira_number ?: $empty }}</strong></div>
                </div>
            </section>
        </div>
        <div class="col-lg-4 mb-3">
            <section class="patient-info-card h-100">
                <h4><i class="fas fa-address-book"></i>{{ __('Contact & Address') }}</h4>
                <div class="patient-info-list">
                    <div><span>{{ __('Phone') }}</span><strong dir="ltr">{{ $patient->phone ?: $empty }}</strong></div>
                    <div><span>{{ __('Alternate Phone') }}</span><strong dir="ltr">{{ $patient->alternate_phone ?: $empty }}</strong></div>
                    <div><span>{{ __('Emergency Contact') }}</span><strong dir="ltr">{{ $patient->emergency_contact ?: $empty }}</strong></div>
                    <div><span>{{ __('Province') }}</span><strong>{{ filled($patient->province) ? __($patient->province) : $empty }}</strong></div>
                    <div><span>{{ __('District') }}</span><strong>{{ $patient->district ? __($patient->district) : $empty }}</strong></div>
                    <div class="patient-info-list__wide"><span>{{ __('Address') }}</span><strong>{{ $patient->address ?: $empty }}</strong></div>
                </div>
            </section>
        </div>
        <div class="col-lg-4 mb-3">
            <section class="patient-info-card h-100">
                <h4><i class="fas fa-shield-alt"></i>{{ __('Coverage & Registration') }}</h4>
                <div class="patient-info-list">
                    <div><span>{{ __('Patient Type') }}</span><strong>{{ $patientType ? __($patientType) : $empty }}</strong></div>
                    <div><span>{{ __('Insurance Company') }}</span><strong>{{ $patient->insuranceCompany?->name ?: $empty }}</strong></div>
                    <div><span>{{ __('Policy Number') }}</span><strong>{{ $patient->insurance_policy_number ?: $empty }}</strong></div>
                    <div><span>{{ __('Insurance Member Number') }}</span><strong>{{ $patient->insurance_member_number ?: $empty }}</strong></div>
                    <div><span>{{ __('Insurance Validity') }}</span><strong>{{ $patient->insurance_valid_from ? displayDate($patient->insurance_valid_from, 'Y-m-d') : '—' }} — {{ $patient->insurance_valid_until ? displayDate($patient->insurance_valid_until, 'Y-m-d') : '—' }}</strong></div>
                    <div><span>{{ __('Coverage Percentage') }}</span><strong>{{ filled($patient->insurance_coverage_percent) ? number_format($patient->insurance_coverage_percent, 0).'%' : $empty }}</strong></div>
                    <div><span>{{ __('Referral Source') }}</span><strong>{{ filled($patient->referralSource?->name) ? __($patient->referralSource->name) : $empty }}</strong></div>
                    <div><span>{{ __('Company') }}</span><strong>{{ $patient->company?->name ?: $empty }}</strong></div>
                </div>
            </section>
        </div>
    </div>
</div>

@push('css')
<style>
    .patient-profile__hero{display:flex;justify-content:space-between;align-items:center;gap:1.5rem;padding:1.45rem;border-radius:18px;background:linear-gradient(125deg,var(--secondary),var(--primary));color:#fff;box-shadow:0 10px 25px rgba(46,125,50,.18)}
    .patient-profile__identity{display:flex;align-items:center;gap:1rem;min-width:0}.patient-profile__avatar{display:grid;place-items:center;flex:0 0 68px;height:68px;border-radius:20px;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.25);font-size:1.35rem;font-weight:800}.patient-profile__eyebrow{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;opacity:.75}.patient-profile__hero h2{margin:.15rem 0 .45rem;font-size:1.55rem;font-weight:800}.patient-profile__meta{display:flex;flex-wrap:wrap;gap:.5rem 1rem;align-items:center;font-size:.86rem;opacity:.92}.patient-profile__meta i{margin-inline-end:.3rem}.patient-profile__meta .badge{font-size:.72rem}
    .patient-profile__quick-stats{display:grid;grid-template-columns:repeat(4,minmax(76px,1fr));gap:.55rem}.patient-profile__quick-stats div{min-width:78px;padding:.7rem .8rem;text-align:center;border-radius:13px;background:rgba(255,255,255,.13);border:1px solid rgba(255,255,255,.15)}.patient-profile__quick-stats strong{display:block;font-size:1.25rem;line-height:1.1}.patient-profile__quick-stats span{display:block;margin-top:.25rem;font-size:.72rem;opacity:.78}
    .patient-profile__sections{margin-top:1rem}.patient-info-card{overflow:hidden;border:1px solid #e4ebe8;border-radius:16px;background:#fff}.patient-info-card h4{display:flex;align-items:center;gap:.55rem;margin:0;padding:.85rem 1rem;border-bottom:1px solid #e8efec;background:#f7faf9;color:#37474f;font-size:.95rem;font-weight:700}.patient-info-card h4 i{display:grid;place-items:center;width:31px;height:31px;border-radius:9px;background:#e8f5e9;color:var(--primary);font-size:.8rem}.patient-info-list{padding:.35rem 1rem}.patient-info-list>div{display:flex;justify-content:space-between;gap:1rem;padding:.68rem 0;border-bottom:1px dashed #e7eeeb}.patient-info-list>div:last-child{border:0}.patient-info-list span{color:#78909c;font-size:.78rem}.patient-info-list strong{max-width:62%;color:#37474f;text-align:end;font-size:.84rem;font-weight:650;word-break:break-word}
    .patient-profile~.card{border:1px solid #e4ebe8;box-shadow:none}.patient-profile~.card .card-header{background:#f7faf9}.patient-profile~.card .card-title{font-size:1rem}.patient-profile~.card .card-title:before{content:'\f1da';font-family:'Font Awesome 5 Free';font-weight:900;margin-inline-end:.5rem;color:var(--primary)}
    @media(max-width:991.98px){.patient-profile__hero{align-items:flex-start;flex-direction:column}.patient-profile__quick-stats{width:100%}}
    @media(max-width:575.98px){.patient-profile__hero{padding:1rem}.patient-profile__avatar{flex-basis:54px;height:54px;border-radius:15px}.patient-profile__hero h2{font-size:1.25rem}.patient-profile__quick-stats{grid-template-columns:repeat(2,1fr)}.patient-info-list>div{align-items:flex-start;flex-direction:column;gap:.2rem}.patient-info-list strong{max-width:100%;text-align:start}}
</style>
@endpush
