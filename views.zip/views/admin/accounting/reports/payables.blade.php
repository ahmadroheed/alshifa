@extends('layouts.admin', ['title' => __('Payables Report')])

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">{{ __('Payables Report') }}</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>{{ __('Account Code') }}</th>
                                    <th>{{ __('Account Name') }}</th>
                                    <th>{{ __('Debit') }}</th>
                                    <th>{{ __('Credit') }}</th>
                                    <th>{{ __('Balance') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($payableAccounts as $item)
                                    <tr>
                                        <td>{{ $item['account']->code }}</td>
                                        <td>{{ $item['account']->name }}</td>
                                        <td>{{ number_format($item['debit'], 2) }}</td>
                                        <td>{{ number_format($item['credit'], 2) }}</td>
                                        <td>{{ number_format($item['balance'], 2) }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">{{ __('No liability accounts available.') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="4">{{ __('Total Payables') }}</th>
                                    <th>{{ number_format($totalPayables, 2) }}</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
