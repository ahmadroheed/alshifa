@php $title = __('Quick Action Invoice'); @endphp
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() === 'fa' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <title>{{ __('Quick Action Invoice') }}</title>
    <style>
        @page { size: A4 portrait; margin: 8mm; }
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 12px; color: #333; margin: 0; padding: 20px; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #28a745; padding-bottom: 10px; }
        .header h1 { color: #28a745; margin: 0; font-size: 22px; }
        .header p { margin: 2px 0; color: #666; }
        .info-table { width: 100%; margin-bottom: 20px; }
        .info-table td { padding: 3px 8px; }
        .info-table td:first-child { font-weight: 600; width: 120px; }
        .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .items-table th { background: #28a745; color: #fff; padding: 8px; text-align: left; font-size: 11px; }
        .items-table td { padding: 6px 8px; border-bottom: 1px solid #ddd; }
        .items-table tfoot td { font-weight: 600; border-top: 2px solid #333; padding-top: 8px; }
        .payment-info { border-top: 1px solid #ddd; padding-top: 10px; margin-top: 10px; }
        .payment-info p { margin: 2px 0; }
        .status-paid { color: #28a745; font-weight: 700; }
        .status-unpaid { color: #dc3545; font-weight: 700; }
        .footer { text-align: center; margin-top: 30px; font-size: 10px; color: #999; border-top: 1px solid #eee; padding-top: 10px; }
        .badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; }
        .badge-success { background: #28a745; color: #fff; }
        .badge-danger { background: #dc3545; color: #fff; }
        .copy-label { margin-bottom: 4px; color: #555; font-size: 10px; font-weight: 700; text-transform: uppercase; }
        @media print {
            body { padding: 0; font-size: 9px; }
            .invoice-copy { page-break-inside: avoid; break-inside: avoid; border-bottom: 1px dashed #888; margin-bottom: 3mm; }
            .header { margin-bottom: 8px; padding-bottom: 5px; }
            .header h1 { font-size: 15px; }
            .info-table { margin-bottom: 8px; }
            .info-table td { padding: 2px 5px; }
            .items-table { margin-bottom: 8px; }
            .items-table th { padding: 4px; font-size: 9px; }
            .items-table td { padding: 3px 5px; }
            .payment-info { padding-top: 5px; margin-top: 5px; }
            .footer { margin-top: 8px; padding-top: 5px; }
        }
    </style>
    <link rel="stylesheet" href="{{ asset('vendor/fonts/dari.css') }}?v={{ filemtime(public_path('vendor/fonts/dari.css')) }}">
</head>
<body>
    @foreach ([__('Patient Copy'), __('Hospital Copy')] as $copyLabel)
    <div class="invoice-copy">
    <div class="header">
        <div class="copy-label">{{ $copyLabel }}</div>
        <h1>{{ $system_settings['site_name'] ?? 'Alshefa HMS' }}</h1>
        <p>{{ __('Quick Action Invoice') }}</p>
    </div>

    <table class="info-table">
        <tr><td>{{ __('Invoice #') }}</td><td>{{ $invoice->invoice_number }}</td></tr>
        <tr><td>{{ __('Date') }}</td><td>{{ displayDate($invoice->created_at, 'Y-m-d H:i') }}</td></tr>
        <tr><td>{{ __('Patient') }}</td><td>{{ $visit->patient->full_name }}</td></tr>
        <tr><td>{{ __('MRN') }}</td><td>{{ $visit->patient->mrn }}</td></tr>
        <tr><td>{{ __('Doctor') }}</td><td>{{ $visit->doctor?->employee?->full_name ?? __('N/A') }}</td></tr>
        <tr><td>{{ __('Status') }}</td><td><span class="badge badge-{{ $invoice->status === 'paid' ? 'success' : 'danger' }}">{{ __(ucfirst($invoice->status)) }}</span></td></tr>
    </table>

    <table class="items-table">
        <thead>
            <tr>
                <th>{{ __('Description') }}</th>
                <th style="width:80px;">{{ __('Qty') }}</th>
                <th style="width:100px;">{{ __('Unit Price') }}</th>
                <th style="width:100px;">{{ __('Total') }}</th>
            </tr>
        </thead>
        <tbody>
            @php $charge = $visit->quickActionCharge; @endphp
            @if($charge)
            <tr>
                <td>{{ __('Consultation Fee') }}</td>
                <td>1</td>
                <td>{{ number_format($charge->consultation_fee, 2) }}</td>
                <td>{{ number_format($charge->consultation_fee, 2) }}</td>
            </tr>
            @if($charge->additional_amount > 0)
            <tr>
                <td>{{ __('Additional Charge') }} @if($charge->notes)- {{ $charge->notes }}@endif</td>
                <td>1</td>
                <td>{{ number_format($charge->additional_amount, 2) }}</td>
                <td>{{ number_format($charge->additional_amount, 2) }}</td>
            </tr>
            @endif
            @if($charge->discount_amount > 0)
            <tr>
                <td>{{ __('Discount') }}</td>
                <td>1</td>
                <td>-{{ number_format($charge->discount_amount, 2) }}</td>
                <td>-{{ number_format($charge->discount_amount, 2) }}</td>
            </tr>
            @endif
            @endif
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">{{ __('Total') }}</td>
                <td>{{ number_format($invoice->total, 2) }} {{ __('AFN') }}</td>
            </tr>
        </tfoot>
    </table>

    <div class="payment-info">
        @if($invoice->payments->count())
            @php $payment = $invoice->payments->first(); @endphp
            <p><strong>{{ __('Payment') }}:</strong> <span class="status-paid">{{ __('Paid') }}</span></p>
            <p><strong>{{ __('Amount') }}:</strong> {{ number_format($payment->amount, 2) }} {{ __('AFN') }}</p>
            <p><strong>{{ __('Date') }}:</strong> {{ displayDate($payment->payment_date, 'Y-m-d H:i') }}</p>
            @if($payment->discount_amount > 0)
            <p><strong>{{ __('Discount') }}:</strong> {{ number_format($payment->discount_amount, 2) }} {{ __('AFN') }}</p>
            @endif
        @else
            <p><strong>{{ __('Payment') }}:</strong> <span class="status-unpaid">{{ __('Unpaid') }}</span></p>
        @endif
    </div>

    <div class="footer">
        <p>{{ $system_settings['footer_text'] ?? '&copy; Alshefa HMS. All rights reserved.' }}</p>
        <p>{{ __('Generated on') }} {{ displayDate(now(), 'Y-m-d H:i:s') }}</p>
    </div>
    </div>
    @endforeach
</body>
</html>