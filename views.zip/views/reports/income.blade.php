@php $title = __('Income Report'); @endphp
@extends('layouts.admin')
@section('content')
<div class="card card-primary">
    <div class="card-header"><h3 class="card-title"><i class="fas fa-chart-bar"></i> {{ __('Income Report') }}</h3>
        <div class="card-tools">
            <form class="form-inline" method="GET">
                <div class="input-group input-group-sm mr-2">
                    <div class="input-group-prepend"><span class="input-group-text">{{ __('From') }}</span></div>
                    <input type="date" name="start_date" class="form-control" value="{{ $startDate }}">
                </div>
                <div class="input-group input-group-sm mr-2">
                    <div class="input-group-prepend"><span class="input-group-text">{{ __('To') }}</span></div>
                    <input type="date" name="end_date" class="form-control" value="{{ $endDate }}">
                </div>
                <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-search"></i> {{ __('Filter') }}</button>
            </form>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4 col-6"><div class="small-box bg-info"><div class="inner"><h3>{{ number_format($totalBilled, 2) }}</h3><p>{{ __('Total Billed (AFN)') }}</p></div><div class="icon"><i class="fas fa-file-invoice"></i></div></div></div>
    <div class="col-lg-4 col-6"><div class="small-box bg-success"><div class="inner"><h3>{{ number_format($totalCollected, 2) }}</h3><p>{{ __('Total Collected (AFN)') }}</p></div><div class="icon"><i class="fas fa-hand-holding-usd"></i></div></div></div>
    <div class="col-lg-4 col-6"><div class="small-box bg-{{ $totalPending > 0 ? 'warning' : 'success' }}"><div class="inner"><h3>{{ number_format($totalPending, 2) }}</h3><p>{{ __('Pending (AFN)') }}</p></div><div class="icon"><i class="fas fa-clock"></i></div></div></div>
</div>

<div class="row">
    <div class="col-md-6"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('Revenue by Type') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Type') }}</th><th>{{ __('Count') }}</th><th>{{ __('Billed') }}</th><th>{{ __('Collected') }}</th><th>{{ __('Collection Rate') }}</th></tr></thead>
                <tbody>@foreach($byType as $type => $data)<tr>
                    <td><span class="badge badge-info">{{ __($type) }}</span></td><td>{{ $data['count'] }}</td>
                    <td>{{ number_format($data['total'], 2) }}</td><td>{{ number_format($data['collected'], 2) }}</td>
                    <td>@if($data['total'] > 0){{ number_format(($data['collected']/$data['total'])*100, 1) }}%@else 0%@endif</td>
                </tr>@endforeach</tbody>
            </table>
        </div>
    </div></div>

    <div class="col-md-6"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('Doctor Income') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Doctor') }}</th><th>{{ __('Patients') }}</th><th>{{ __('Fee') }}</th><th>{{ __('Total Income') }}</th></tr></thead>
                <tbody>@forelse($doctorIncome as $d)<tr>
                    <td>{{ $d->first_name }} {{ $d->last_name }}</td><td>{{ $d->patient_count }}</td>
                    <td>{{ number_format($d->consultation_fee, 2) }}</td><td><strong>{{ number_format($d->total_income, 2) }}</strong></td>
                </tr>@empty<tr><td colspan="4" class="text-muted text-center">{{ __('No data') }}</td></tr>@endforelse
                <tfoot><tr class="font-weight-bold"><td>{{ __('Total') }}</td><td>{{ $doctorIncome->sum('patient_count') }}</td><td></td><td>{{ number_format($doctorIncome->sum('total_income'), 2) }}</td></tr></tfoot>
            </table>
        </div>
    </div></div>
</div>

<div class="row mt-3">
    <div class="col-md-4"><div class="info-box"><span class="info-box-icon bg-info"><i class="fas fa-flask"></i></span>
        <div class="info-box-content"><span class="info-box-text">{{ __('Lab Income') }}</span><span class="info-box-number">{{ number_format($labIncome, 2) }} {{ __('AFN') }}</span></div>
    </div></div>
    <div class="col-md-4"><div class="info-box"><span class="info-box-icon bg-success"><i class="fas fa-pills"></i></span>
        <div class="info-box-content"><span class="info-box-text">{{ __('Pharmacy Income') }}</span><span class="info-box-number">{{ number_format($pharmacyIncome, 2) }} {{ __('AFN') }}</span></div>
    </div></div>
    <div class="col-md-4"><div class="info-box"><span class="info-box-icon bg-primary"><i class="fas fa-stethoscope"></i></span>
        <div class="info-box-content"><span class="info-box-text">{{ __('Consultation Income') }}</span><span class="info-box-number">{{ number_format($doctorIncome->sum('total_income'), 2) }} {{ __('AFN') }}</span></div>
    </div></div>
</div>

<div class="card mt-3"><div class="card-header"><h3 class="card-title">{{ __('Daily Revenue') }}</h3></div>
    <div class="card-body table-responsive p-0" style="max-height:400px;overflow-y:auto">
        <table class="table table-sm">
            <thead><tr><th>{{ __('Date') }}</th><th>{{ __('Invoices') }}</th><th>{{ __('Billed') }}</th><th>{{ __('Collected') }}</th></tr></thead>
            <tbody>@foreach($dailyRevenue as $date => $data)<tr>
                <td>{{ $date }}</td><td>{{ $data['count'] }}</td><td>{{ number_format($data['total'], 2) }}</td><td>{{ number_format($data['collected'], 2) }}</td>
            </tr>@endforeach</tbody>
        </table>
    </div>
</div>
@endsection
