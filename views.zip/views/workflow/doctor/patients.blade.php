@php $title = __('All My Patients'); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-lg-3 col-6"><div class="small-box bg-info"><div class="inner"><h3>{{ $patientCount }}</h3><p>{{ __('Total Patients') }}</p></div><div class="icon"><i class="fas fa-procedures"></i></div></div></div>
    <div class="col-lg-3 col-6"><div class="small-box bg-success"><div class="inner"><h3>{{ number_format($totalIncome, 2) }}</h3><p>{{ __('Total Income (AFN)') }}</p></div><div class="icon"><i class="fas fa-money-bill-wave"></i></div></div></div>
</div>
<div class="card">
    <div class="card-header"><h3 class="card-title">{{ __('Patient Visits') }}</h3></div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover">
            <thead><tr><th>{{ __('Date') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Visit Code') }}</th><th>{{ __('Consultation') }}</th><th>{{ __('Status') }}</th><th>{{ __('Action') }}</th></tr></thead>
            <tbody>@foreach($visits as $v)<tr>
                <td>{{ displayDate($v->visit_date, 'Y-m-d') }}</td>
                <td><strong>{{ $v->patient->full_name }}</strong></td>
                <td>{{ $v->visit_code }}</td>
                <td>{{ $v->consultation?->chief_complaint ? \Str::limit($v->consultation->chief_complaint, 50) : __('Not consulted') }}</td>
                <td><span class="badge badge-{{ $v->status === 'with_doctor' ? 'warning' : ($v->status === 'consulted' ? 'success' : 'secondary') }}">{{ __(ucwords(str_replace('_', ' ', $v->status))) }}</span></td>
                <td><a href="{{ route('workflow.doctor.consult', $v->id) }}" class="btn btn-sm btn-{{ $v->consultation ? 'info' : 'primary' }}"><i class="fas fa-{{ $v->consultation ? 'eye' : 'stethoscope' }}"></i></a></td>
            </tr>@endforeach</tbody>
        </table>
    </div>
    @if($visits->hasPages())<div class="card-footer clearfix">{{ $visits->links('vendor.pagination.bootstrap-4') }}</div>@endif
</div>
@endsection
