<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{ app()->getLocale() === 'fa' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ __('Invoice') }} {{ $invoice->invoice_number }}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        *, ::before, ::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #f0f2f5;
            color: #1a1a2e;
            line-height: 1.6;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .invoice-card {
            max-width: 820px;
            margin: 32px auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 1px 3px rgba(0,0,0,.08), 0 4px 16px rgba(0,0,0,.04);
            overflow: hidden;
        }

        .invoice-header {
            padding: 32px 36px 24px;
            border-bottom: 1px solid #f0f0f0;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 24px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .brand-logo {
            width: 52px;
            height: 52px;
            border-radius: 12px;
            object-fit: contain;
            background: #f8f9fa;
            padding: 4px;
        }

        .brand-logo-placeholder {
            width: 52px;
            height: 52px;
            border-radius: 12px;
            background: linear-gradient(135deg, #1a73e8, #1557b0);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 700;
            font-size: 22px;
            flex-shrink: 0;
        }

        .brand-info h1 {
            font-size: 20px;
            font-weight: 700;
            color: #1a1a2e;
            margin: 0;
            letter-spacing: -.3px;
        }

        .brand-info .subtitle {
            font-size: 13px;
            color: #666;
            font-weight: 400;
            margin-top: 2px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .3px;
            text-transform: uppercase;
        }

        .status-badge.paid { background: #e6f7ed; color: #0d6832; }
        .status-badge.partial { background: #fff8e1; color: #8d6200; }
        .status-badge.unpaid { background: #fce8e6; color: #b3261e; }

        .status-badge .dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
        }

        .status-badge.paid .dot { background: #0d6832; }
        .status-badge.partial .dot { background: #8d6200; }
        .status-badge.unpaid .dot { background: #b3261e; }

        .invoice-number-section {
            text-align: right;
        }

        .invoice-number-section .label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #888;
            font-weight: 500;
        }

        .invoice-number-section .number {
            font-size: 18px;
            font-weight: 700;
            color: #1a1a2e;
            margin-top: 2px;
        }

        .invoice-body {
            padding: 28px 36px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 28px;
            margin-bottom: 32px;
        }

        .info-block h3 {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #888;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .info-block .name {
            font-size: 16px;
            font-weight: 600;
            color: #1a1a2e;
        }

        .info-block .detail {
            font-size: 13px;
            color: #555;
            margin-top: 3px;
        }

        .info-block .detail strong {
            color: #333;
            font-weight: 500;
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }

        .items-table thead th {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .8px;
            color: #888;
            font-weight: 600;
            padding: 10px 12px;
            text-align: left;
            border-bottom: 2px solid #e8e8e8;
        }

        .items-table thead th.text-right { text-align: right; }
        .items-table thead th.text-center { text-align: center; }

        .items-table tbody td {
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
            color: #333;
        }

        .items-table tbody td.text-right { text-align: right; }
        .items-table tbody td.text-center { text-align: center; }

        .items-table tbody tr:last-child td { border-bottom: none; }

        .totals-wrapper {
            display: flex;
            justify-content: flex-end;
            margin-top: 8px;
        }

        .totals {
            width: 320px;
        }

        .totals .row {
            display: flex;
            justify-content: space-between;
            padding: 7px 0;
            font-size: 14px;
        }

        .totals .row .label { color: #666; }
        .totals .row .value { font-weight: 500; color: #333; }

        .totals .row.total {
            border-top: 2px solid #e8e8e8;
            margin-top: 4px;
            padding-top: 12px;
        }

        .totals .row.total .label { font-weight: 600; color: #1a1a2e; font-size: 16px; }
        .totals .row.total .value { font-weight: 700; color: #1a1a2e; font-size: 18px; }

        .totals .row.paid .label,
        .totals .row.paid .value { color: #0d6832; font-weight: 600; }
        .totals .row.due .label,
        .totals .row.due .value { color: #b3261e; font-weight: 600; }

        .invoice-footer {
            padding: 20px 36px;
            background: #f8f9fa;
            border-top: 1px solid #f0f0f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .invoice-footer .thanks {
            font-size: 13px;
            color: #666;
        }

        .action-bar {
            padding: 20px 36px 28px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: all .2s;
        }

        .btn:active { transform: scale(.97); }

        .btn-secondary {
            background: #f0f2f5;
            color: #333;
        }
        .btn-secondary:hover { background: #e4e6ea; }

        .btn-success {
            background: #0d6832;
            color: #fff;
        }
        .btn-success:hover { background: #0a5228; }

        .btn-info {
            background: #1a73e8;
            color: #fff;
        }
        .btn-info:hover { background: #1557b0; }

        .btn-primary {
            background: #1a1a2e;
            color: #fff;
        }
        .btn-primary:hover { background: #0f0f1e; }

        .btn-group { display: flex; gap: 10px; flex-wrap: wrap; }

        .copy-label {
            margin-bottom: 4px;
            color: #555;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: .8px;
            text-transform: uppercase;
        }

        @page {
            size: A4 portrait;
            margin: 7mm;
        }

        @media print {
            body { background: #fff; font-size: 9px; line-height: 1.25; }
            .invoice-card {
                max-width: none;
                margin: 0;
                border-radius: 0;
                box-shadow: none;
                break-inside: avoid;
                page-break-inside: avoid;
            }
            .invoice-card + .invoice-card { margin-top: 2mm; }
            .invoice-header { padding: 4mm 6mm 3mm; }
            .brand-logo, .brand-logo-placeholder { width: 36px; height: 36px; }
            .brand-info h1 { font-size: 15px; }
            .brand-info .subtitle { font-size: 10px; }
            .status-badge { padding: 3px 8px; font-size: 9px; }
            .invoice-number-section .number { font-size: 13px; }
            .invoice-body { padding: 3mm 6mm; }
            .action-bar { display: none !important; }
            .invoice-footer { padding: 2mm 6mm; }
            .info-grid { gap: 12px; margin-bottom: 8px; }
            .info-block h3 { margin-bottom: 3px; }
            .info-block .name { font-size: 12px; }
            .info-block .detail { margin-top: 1px; font-size: 10px; }
            .items-table { margin-bottom: 8px; }
            .items-table thead th { padding: 4px 6px; font-size: 9px; }
            .items-table tbody td { padding: 4px 6px; font-size: 10px; }
            .totals { width: 250px; }
            .totals .row { padding: 2px 0; font-size: 10px; }
            .totals .row.total { padding-top: 5px; }
            .totals .row.total .label { font-size: 12px; }
            .totals .row.total .value { font-size: 13px; }
            .invoice-footer .thanks { font-size: 10px; }
        }

        @media (max-width: 640px) {
            .invoice-card { margin: 16px; border-radius: 12px; }
            .invoice-header { padding: 24px; }
            .header-top { flex-direction: column; }
            .invoice-number-section { text-align: left; }
            .info-grid { grid-template-columns: 1fr; gap: 20px; }
            .invoice-body { padding: 20px 24px; }
            .totals { width: 100%; }
            .action-bar { flex-direction: column; gap: 12px; align-items: stretch; }
            .btn-group { justify-content: center; }
        }
    </style>
    <link rel="stylesheet" href="{{ asset('vendor/fonts/dari.css') }}?v={{ filemtime(public_path('vendor/fonts/dari.css')) }}">
</head>
<body>
    @foreach ([__('Patient Copy'), __('Hospital Copy')] as $copyIndex => $copyLabel)
    <div class="invoice-card">
        <div class="invoice-header">
            <div class="header-top">
                <div class="brand">
                    @php $logo = setting('logo'); @endphp
                    @if ($logo)
                        <img src="{{ asset('storage/' . $logo) }}" alt="{{ setting('site_name', __('Alshefa HMS')) }}" class="brand-logo">
                    @else
                        <div class="brand-logo-placeholder">{{ substr(setting('site_name', __('Alshefa HMS')), 0, 1) }}</div>
                    @endif
                    <div class="brand-info">
                        <h1>{{ setting('site_name', __('Alshefa HMS')) }}</h1>
                        <div class="subtitle">{{ __('Finance Invoice') }}</div>
                    </div>
                </div>
                <div class="invoice-number-section">
                    <div class="copy-label">{{ $copyLabel }}</div>
                    <div class="status-badge {{ $invoice->status }}">
                        <span class="dot"></span>
                        {{ __(str($invoice->status)->replace('_', ' ')->title()->toString()) }}
                    </div>
                    <div class="label" style="margin-top: 10px;">{{ __('Invoice') }}</div>
                    <div class="number">{{ $invoice->invoice_number }}</div>
                </div>
            </div>
        </div>

        <div class="invoice-body">
            <div class="info-grid">
                <div class="info-block">
                    <h3>{{ __('Patient') }}</h3>
                    <div class="name">{{ $invoice->patient?->display_name ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('MRN') }}:</strong> {{ $invoice->patient?->mrn ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Phone') }}:</strong> {{ $invoice->patient?->phone ?? __('Not set') }}</div>
                </div>
                <div class="info-block">
                    <h3>{{ __('Invoice Details') }}</h3>
                    <div class="detail"><strong>{{ __('Type') }}:</strong> {{ __($invoice->invoice_type) }}</div>
                    <div class="detail"><strong>{{ __('Visit') }}:</strong> {{ $invoice->patientVisit?->visit_code ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Admission') }}:</strong> {{ $invoice->admission?->admission_code ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Created By') }}:</strong> {{ $invoice->createdBy?->name ?? __('Not set') }}</div>
                    <div class="detail"><strong>{{ __('Date') }}:</strong> {{ displayDate($invoice->created_at, 'Y-m-d H:i') }}</div>
                </div>
            </div>

            <table class="items-table">
                <thead>
                    <tr>
                        <th>{{ __('Description') }}</th>
                        <th class="text-center">{{ __('Qty') }}</th>
                        <th class="text-right">{{ __('Unit Price') }}</th>
                        <th class="text-right">{{ __('Total') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($invoice->items as $item)
                        <tr>
                            <td>{{ $item->description }}</td>
                            <td class="text-center">{{ $item->quantity }}</td>
                            <td class="text-right">{{ number_format((float) $item->unit_price, 2) }}</td>
                            <td class="text-right">{{ number_format((float) $item->total, 2) }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" style="text-align: center; color: #888; padding: 24px;">{{ __('No items') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>

            <div class="totals-wrapper">
                <div class="totals">
                    <div class="row">
                        <span class="label">{{ __('Subtotal') }}</span>
                        <span class="value">{{ number_format((float) $invoice->subtotal, 2) }}</span>
                    </div>
                    <div class="row">
                        <span class="label">{{ __('Discount') }}</span>
                        <span class="value">{{ number_format((float) $invoice->discount, 2) }}</span>
                    </div>
                    @php $paymentDiscount = $invoice->payments->where('status', 'completed')->sum('discount_amount'); @endphp
                    @if ($paymentDiscount > 0)
                    <div class="row">
                        <span class="label" style="color: #888;">{{ __('Payment Discount') }}</span>
                        <span class="value" style="color: #888;">-{{ number_format((float) $paymentDiscount, 2) }}</span>
                    </div>
                    @endif
                    <div class="row">
                        <span class="label">{{ __('Tax') }}</span>
                        <span class="value">{{ number_format((float) $invoice->tax, 2) }}</span>
                    </div>
                    <div class="row total">
                        <span class="label">{{ __('Total') }}</span>
                        <span class="value">{{ number_format((float) $invoice->total, 2) }}</span>
                    </div>
                    <div class="row paid">
                        <span class="label">{{ __('Paid Amount') }}</span>
                        <span class="value">{{ number_format((float) $invoice->paid_amount, 2) }}</span>
                    </div>
                    <div class="row due">
                        <span class="label">{{ __('Due Amount') }}</span>
                        <span class="value">{{ number_format((float) $invoice->due_amount, 2) }}</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="invoice-footer">
            <div class="thanks">{{ __('Thank you for your visit') }}</div>
            <div style="font-size: 12px; color: #999;">{{ setting('footer_text', '') }}</div>
        </div>

        @if ($copyIndex === 0)
        <div class="action-bar no-print">
            <a href="{{ route('masters.index', 'invoices') }}" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                {{ __('Back to Invoices') }}
            </a>
            <div class="btn-group">
                @if ($invoice->status !== 'paid')
                <a href="{{ route('masters.create', 'payments') }}?invoice_id={{ $invoice->id }}" class="btn btn-success">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    {{ __('Collect Payment') }}
                </a>
                @endif
                <a href="{{ route('invoices.download', $invoice) }}" class="btn btn-info">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    {{ __('Download PDF') }}
                </a>
                <button type="button" onclick="window.print()" class="btn btn-primary">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                    {{ __('Print Invoice') }}
                </button>
            </div>
        </div>
        @endif
    </div>
    @endforeach
</body>
</html>
