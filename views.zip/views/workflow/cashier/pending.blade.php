@php $title = __('Cashier - Pending Payments'); @endphp
@extends('layouts.admin')
@section('content')
<div class="row">
    <div class="col-lg-3 col-6"><div class="small-box bg-warning"><div class="inner"><h3>{{ $pendingInvoices->total() }}</h3><p>{{ __('Pending Payments') }}</p></div><div class="icon"><i class="fas fa-clock"></i></div></div></div>
    <div class="col-lg-3 col-6"><div class="small-box bg-success"><div class="inner"><h3>{{ $totalToday }} {{ __('AFN') }}</h3><p>{{ __('Collected Today') }}</p></div><div class="icon"><i class="fas fa-money-bill-wave"></i></div></div></div>
</div>

<div class="row">
    <div class="col-md-8"><div class="card">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-file-invoice"></i> {{ __('Unpaid Invoices') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <thead><tr><th>{{ __('Invoice #') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Type') }}</th><th>{{ __('Items') }}</th><th>{{ __('Total') }}</th><th>{{ __('Date') }}</th><th>{{ __('Action') }}</th></tr></thead>
                <tbody>@forelse($pendingInvoices as $inv)<tr>
                    <td>{{ $inv->invoice_number }}</td>
                    <td><strong>{{ $inv->patientVisit?->patient?->full_name ?? __('N/A') }}</strong></td>
                    <td><span class="badge badge-info">{{ __($inv->invoice_type) }}</span></td>
                    <td>{{ $inv->items->pluck('description')->implode(', ') }}</td>
                    <td><strong>{{ number_format($inv->total, 2) }} {{ __('AFN') }}</strong></td>
                    <td>{{ displayDate($inv->created_at, 'Y-m-d') }}</td>
                    <td><button class="btn btn-success btn-sm collect-btn" data-invoice="{{ $inv->id }}"><i class="fas fa-hand-holding-usd"></i> {{ __('Collect') }}</button></td>
                </tr>@empty<tr><td colspan="7" class="text-center text-muted">{{ __('No pending invoices') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
        @if($pendingInvoices->hasPages())<div class="card-footer clearfix">{{ $pendingInvoices->links('vendor.pagination.bootstrap-4') }}</div>@endif
    </div></div>

    <div class="col-md-4"><div class="card">
        <div class="card-header"><h3 class="card-title"><i class="fas fa-check-circle"></i> {{ __('Today\'s Collections') }}</h3></div>
        <div class="card-body table-responsive p-0" style="max-height:400px;overflow-y:auto">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Payment') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Amount') }}</th></tr></thead>
                <tbody>@forelse($todayCollections as $c)<tr>
                    <td>{{ $c->payment_number }}</td>
                    <td>{{ $c->invoice?->patientVisit?->patient?->full_name ?? 'N/A' }}</td>
                    <td>{{ number_format($c->amount, 2) }}</td>
                </tr>@empty<tr><td colspan="3" class="text-muted text-center">{{ __('No collections today') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>

<div class="modal fade" id="bankModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">{{ __('Select Bank Account') }}</h5><button type="button" class="close" data-dismiss="modal">&times;</button></div>
            <div class="modal-body">
                <div class="form-group">
                    <label>{{ __('Bank Account') }}</label>
                    <select id="bank_account_id" class="form-control">
                        <option value="">{{ __('Cash (On Hand)') }}</option>
                        @foreach($bankAccounts as $ba)
                            <option value="{{ $ba->id }}">{{ $ba->account_name }} ({{ $ba->bank_name }} - {{ $ba->account_number }})</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-success" id="confirmCollect">{{ __('Confirm & Collect') }}</button>
            </div>
        </div>
    </div>
</div>

@push('js')
<script>
$(document).ready(function() {
    var pendingInvoiceId = null;

    $('.collect-btn').on('click', function() {
        pendingInvoiceId = $(this).data('invoice');
        $('#bankModal').modal('show');
    });

    $('#confirmCollect').on('click', function() {
        if (!pendingInvoiceId) return;
        $('#confirmCollect').html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
        $.ajax({
            url: '{{ route("workflow.cashier.collect", ["invoice" => "__INVOICE__"]) }}'.replace('__INVOICE__', pendingInvoiceId),
            method: 'POST',
            data: {_token: '{{ csrf_token() }}', bank_account_id: $('#bank_account_id').val()},
            success: function(res) { if (res.success) window.location.href = res.redirect; },
            error: function(xhr) { alert(xhr.responseJSON?.message || '{{ __("Error collecting payment.") }}'); $('#confirmCollect').html('{{ __("Confirm & Collect") }}').prop('disabled', false); $('#bankModal').modal('hide'); }
        });
    });
});
</script>
@endpush
@endsection
