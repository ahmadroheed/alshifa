@php $title = __('Daily Report'); @endphp
@extends('layouts.admin')
@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title"><i class="fas fa-calendar-day"></i> {{ __('Daily Activity Report') }}</h3>
        <div class="card-tools"><form class="form-inline" method="GET"><input type="date" name="date" class="form-control form-control-sm" value="{{ $date }}"><button type="submit" class="btn btn-sm btn-primary ml-2"><i class="fas fa-search"></i> {{ __('View') }}</button></form></div>
    </div>
</div>

<div class="row">
    <div class="col-lg-2 col-6"><div class="small-box bg-success"><div class="inner"><h3>{{ number_format($totalCash, 2) }}</h3><p>{{ __('Total Collected') }}</p></div><div class="icon"><i class="fas fa-money-bill-wave"></i></div></div></div>
    <div class="col-lg-2 col-6"><div class="small-box bg-info"><div class="inner"><h3>{{ $invoiceCount }}</h3><p>{{ __('Paid Invoices') }}</p></div><div class="icon"><i class="fas fa-file-invoice"></i></div></div></div>
    <div class="col-lg-2 col-6"><div class="small-box bg-primary"><div class="inner"><h3>{{ $consultationsDone }}</h3><p>{{ __('Consultations') }}</p></div><div class="icon"><i class="fas fa-stethoscope"></i></div></div></div>
    <div class="col-lg-2 col-6"><div class="small-box bg-warning"><div class="inner"><h3>{{ $labTestsCompleted }}</h3><p>{{ __('Lab Tests') }}</p></div><div class="icon"><i class="fas fa-flask"></i></div></div></div>
    <div class="col-lg-2 col-6"><div class="small-box bg-success"><div class="inner"><h3>{{ $prescriptionsDispensed }}</h3><p>{{ __('Prescriptions') }}</p></div><div class="icon"><i class="fas fa-pills"></i></div></div></div>
</div>

<div class="row">
    <div class="col-md-6"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('Collections by Type') }}</h3></div>
        <div class="card-body table-responsive p-0">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Type') }}</th><th>{{ __('Transactions') }}</th><th>{{ __('Amount') }}</th></tr></thead>
                <tbody>@forelse($byType as $type => $data)<tr>
                    <td><span class="badge badge-info">{{ __($type) }}</span></td><td>{{ $data['count'] }}</td><td>{{ number_format($data['total'], 2) }}</td>
                </tr>@empty<tr><td colspan="3" class="text-muted text-center">{{ __('No collections') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
    <div class="col-md-6"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('All Collections') }}</h3></div>
        <div class="card-body table-responsive p-0" style="max-height:300px;overflow-y:auto">
            <table class="table table-sm">
                <thead><tr><th>{{ __('Payment #') }}</th><th>{{ __('Patient') }}</th><th>{{ __('Type') }}</th><th>{{ __('Amount') }}</th><th>{{ __('Collected By') }}</th></tr></thead>
                <tbody>@forelse($collections as $c)<tr>
                    <td>{{ $c->payment_number }}</td><td>{{ $c->invoice?->patientVisit?->patient?->full_name ?? 'N/A' }}</td>
                    <td><span class="badge badge-info">{{ __($c->invoice?->invoice_type ?? 'N/A') }}</span></td>
                    <td>{{ number_format($c->amount, 2) }}</td><td>{{ $c->createdBy?->name ?? 'N/A' }}</td>
                </tr>@empty<tr><td colspan="5" class="text-center text-muted">{{ __('No collections on this date') }}</td></tr>@endforelse</tbody>
            </table>
        </div>
    </div></div>
</div>
@endsection
