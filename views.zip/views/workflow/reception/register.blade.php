@php $title = __('Patient Registration'); @endphp
@extends('layouts.admin')
@section('content')
<div class="registration-shell">
<div class="row">
    <div class="col-md-12">
        <div class="card registration-card">
            <div class="card-header registration-card__header">
                <div>
                    <h3 class="card-title"><i class="fas fa-user-plus mr-2"></i>{{ __('Patient Registration') }}</h3>
                    <div class="registration-card__subtitle">{{ __('Create a new patient or add a visit to an existing medical record.') }}</div>
                </div>
            </div>
            <div class="registration-tabs">
                <ul class="nav nav-tabs border-0" id="patient-type-tabs">
                    <li class="nav-item"><a class="nav-link {{ $flowType === 'doctor_visit' ? 'active' : '' }}" href="#doctor-visit" data-toggle="tab"><i class="fas fa-stethoscope"></i> {{ __('Doctor Visit') }}</a></li>
                    <li class="nav-item"><a class="nav-link {{ $flowType === 'quick_action' ? 'active' : '' }}" href="#quick-action" data-toggle="tab"><i class="fas fa-bolt"></i> {{ __('Special Patient Registration') }}</a></li>
                    <li class="nav-item"><a class="nav-link {{ $flowType === 'lab_only' ? 'active' : '' }}" href="#lab-only" data-toggle="tab"><i class="fas fa-flask"></i> {{ __('Lab Only') }}</a></li>
                    <li class="nav-item"><a class="nav-link {{ $flowType === 'pharmacy_only' ? 'active' : '' }}" href="#pharmacy-only" data-toggle="tab"><i class="fas fa-pills"></i> {{ __('Pharmacy Only') }}</a></li>
                    <li class="nav-item"><a class="nav-link {{ $flowType === 'ipd' ? 'active' : '' }}" href="#ipd" data-toggle="tab"><i class="fas fa-procedures"></i> {{ __('Admission / IPD') }}</a></li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    @foreach (['doctor_visit' => ['id' => 'doctor-visit', 'icon' => 'stethoscope', 'label' => 'Doctor Visit', 'color' => 'primary'], 'quick_action' => ['id' => 'quick-action', 'icon' => 'bolt', 'label' => 'Special Patient Registration', 'color' => 'success'], 'lab_only' => ['id' => 'lab-only', 'icon' => 'flask', 'label' => 'Lab Only', 'color' => 'info'], 'pharmacy_only' => ['id' => 'pharmacy-only', 'icon' => 'pills', 'label' => 'Pharmacy Only', 'color' => 'success'], 'ipd' => ['id' => 'ipd', 'icon' => 'procedures', 'label' => 'Admission / IPD', 'color' => 'warning']] as $type => $tab)
                    <div class="tab-pane fade {{ $flowType === $type ? 'active show' : '' }}" id="{{ $tab['id'] }}">
                        <form id="register-form-{{ $type }}" class="patient-register-form" data-flow="{{ $type }}" method="POST" action="{{ route('workflow.reception.store-patient') }}">
                            @csrf
                            <input type="hidden" name="flow_type" value="{{ $type }}">
                            <div class="registration-section registration-section--patient">
                                <div class="card-header py-2"><strong><i class="fas fa-search"></i> {{ __('Returning patient') }}</strong></div>
                                <div class="card-body pb-1">
                                    <div class="form-group">
                                        <label>{{ __('Find by MRN, name, father name, or phone') }}</label>
                                        <select name="patient_id" class="form-control existing-patient no-select2" style="width: 100%"></select>
                                        <small class="form-text text-muted">{{ __('Leave empty to create a new patient. Selecting a patient keeps the same MRN and medical history.') }}</small>
                                    </div>
                                </div>
                            </div>
                            <div class="new-patient-fields">
                            <div class="row">
                                <div class="col-md-4"><div class="form-group"><label>{{ __('First Name') }} <span class="text-danger">*</span></label><input type="text" name="first_name" class="form-control" required></div></div>
                                <div class="col-md-4"><div class="form-group"><label>{{ __('Last Name') }} <span class="text-danger">*</span></label><input type="text" name="last_name" class="form-control" required></div></div>
                                <div class="col-md-4"><div class="form-group"><label>{{ __('Father Name') }} <span class="text-danger">*</span></label><input type="text" name="father_name" class="form-control" required></div></div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><div class="form-group"><label>{{ __('Gender') }} <span class="text-danger">*</span></label><select name="gender" class="form-control select2" required><option value="">{{ __('Select') }}</option><option value="male">{{ __('Male') }}</option><option value="female">{{ __('Female') }}</option></select></div></div>
                                <div class="col-md-3"><div class="form-group"><label>{{ __('Date of Birth') }} <span class="text-danger">*</span></label><input type="hidden" id="date_of_birth_{{ $type }}" name="date_of_birth" value=""><input id="date_of_birth_shamsi_{{ $type }}" type="text" class="form-control shamsi-datepicker" data-alt-field="#date_of_birth_{{ $type }}" required></div></div>
                                <div class="col-md-3"><div class="form-group"><label>{{ __('Phone') }} <span class="text-danger">*</span></label><input type="text" name="phone" class="form-control" required></div></div>
                                <div class="col-md-3"><div class="form-group"><label>{{ __('Blood Group') }}</label><select name="blood_group" class="form-control select2"><option value="">{{ __('Select') }}</option>@foreach (['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $bg)<option value="{{ $bg }}">{{ $bg }}</option>@endforeach</select></div></div>
                            </div>
                            <div class="row">
                                <div class="col-md-8"><div class="form-group"><label>{{ __('Address') }} <span class="text-danger">*</span></label><textarea name="address" class="form-control" rows="2" required></textarea></div></div>
                                <div class="col-md-4"><div class="form-group"><label>{{ __('Province') }}</label><select name="province" class="form-control select2"><option value="">{{ __('Select Province') }}</option>@foreach ($provinces as $p)<option value="{{ $p }}">{{ __($p) }}</option>@endforeach</select></div></div>
                            </div>
                            <div class="registration-section">
                                <div class="card-header py-2"><strong><i class="fas fa-shield-alt"></i> {{ __('Insurance (optional)') }}</strong></div>
                                <div class="card-body pb-1">
                                    <div class="row">
                                        <div class="col-md-3"><div class="form-group"><label>{{ __('Insurance Company') }}</label><select name="insurance_company_id" class="form-control select2 insurance-company"><option value="">{{ __('Self Pay') }}</option>@foreach($insuranceCompanies as $company)<option value="{{ $company->id }}" data-coverage="{{ $company->default_coverage_percent }}">{{ $company->name }} ({{ $company->default_coverage_percent }}%)</option>@endforeach</select></div></div>
                                        <div class="col-md-3"><div class="form-group"><label>{{ __('Policy Number') }}</label><input type="text" name="insurance_policy_number" class="form-control insurance-detail"></div></div>
                                        <div class="col-md-2"><div class="form-group"><label>{{ __('Member Number') }}</label><input type="text" name="insurance_member_number" class="form-control insurance-detail"></div></div>
                                        <div class="col-md-2"><div class="form-group"><label>{{ __('Valid Until') }}</label><input type="hidden" id="insurance_valid_until_{{ $type }}" name="insurance_valid_until"><input type="text" class="form-control insurance-detail shamsi-datepicker" data-alt-field="#insurance_valid_until_{{ $type }}"></div></div>
                                        <div class="col-md-2"><div class="form-group"><label>{{ __('Coverage %') }}</label><input type="number" name="insurance_coverage_percent" class="form-control insurance-coverage" min="0" max="100" step="0.01"></div></div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            @if ($type === 'doctor_visit' || $type === 'quick_action' || $type === 'ipd')
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group"><label>{{ __('Department') }} @if($type==='doctor_visit' || $type==='quick_action')<span class="text-danger">*</span>@endif</label>
                                        <select name="department_id" class="form-control select2" @if($type==='doctor_visit')required @endif>
                                            <option value="">{{ __('Select Department') }}</option>
                                            @foreach ($departments as $d)<option value="{{ $d->id }}">{{ $d->name }}</option>@endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @if ($type === 'doctor_visit' || $type === 'quick_action' || $type === 'ipd')
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group"><label>{{ __('Refer to Doctor') }} @if($type==='doctor_visit' || $type==='quick_action')<span class="text-danger">*</span>@endif</label>
                                        <select name="doctor_id" class="form-control select2" @if($type==='doctor_visit')required @endif>
                                            <option value="">{{ __('Select Doctor') }}</option>
                                            @foreach ($doctors as $doc)<option value="{{ $doc->id }}">{{ $doc->employee?->full_name ?? 'Dr. #'.$doc->id }} - {{ $doc->specialization ?? '' }}</option>@endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @if ($type === 'lab_only')
                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <div class="card card-info card-outline">
                                        <div class="card-header"><h5 class="card-title"><i class="fas fa-flask"></i> {{ __('Select Lab Tests') }}</h5></div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <select class="form-control select2" id="lab-tests-{{ $type }}" multiple style="width:100%" data-placeholder="{{ __('Select Lab Tests') }}">
                                                    @foreach ($labTests as $t)<option value="{{ $t->id }}" data-price="{{ $t->price }}">{{ $t->name }} - {{ number_format($t->price, 2) }} {{ __('AFN') }}</option>@endforeach
                                                </select>
                                            </div>
                                            <table class="table table-sm" id="lab-tests-table-{{ $type }}">
                                                <thead><tr><th>{{ __('Test') }}</th><th>{{ __('Price') }}</th><th>{{ __('Action') }}</th></tr></thead>
                                                <tbody></tbody>
                                                <tfoot><tr class="font-weight-bold"><td>{{ __('Total') }}</td><td id="lab-total-{{ $type }}">0.00 {{ __('AFN') }}</td><td></td></tr></tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @if ($type === 'pharmacy_only')
                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <div class="card card-success card-outline">
                                        <div class="card-header"><h5 class="card-title"><i class="fas fa-pills"></i> {{ __('Select Medicines') }}</h5></div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <select class="form-control select2" id="medicine-select-{{ $type }}" style="width:100%" data-placeholder="{{ __('Select Medicine') }}">
                                                    <option value="">{{ __('Select Medicine') }}</option>
                                                    @foreach ($medicines as $m)<option value="{{ $m->id }}" data-price="{{ $m->batches->first()?->sale_price ?? 0 }}" data-stock="{{ $m->batches->sum('remaining_quantity') }}">{{ $m->name }} - {{ number_format($m->batches->first()?->sale_price ?? 0, 2) }} {{ __('AFN') }} ({{ __('Stock') }}: {{ $m->batches->sum('remaining_quantity') }})</option>@endforeach
                                                </select>
                                            </div>
                                            <table class="table table-sm" id="medicine-table-{{ $type }}">
                                                <thead><tr><th>{{ __('Medicine') }}</th><th>{{ __('Price') }}</th><th>{{ __('Qty') }}</th><th>{{ __('Total') }}</th><th>{{ __('Action') }}</th></tr></thead>
                                                <tbody></tbody>
                                                <tfoot><tr class="font-weight-bold"><td colspan="3">{{ __('Total') }}</td><td id="medicine-total-{{ $type }}">0.00 {{ __('AFN') }}</td><td></td></tr></tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-{{ $tab['icon'] }} mr-1"></i> {{ __('Register & Generate Bill') }}</button>
                                    <a href="{{ route('dashboard') }}" class="btn btn-default btn-lg">{{ __('Cancel') }}</a>
                                </div>
                            </div>
                        </form>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
</div>

@if($patients->count())
<div class="row mt-3">
    <div class="col-md-12">
        <div class="card"><div class="card-header"><h3 class="card-title">{{ __('Recent Patients') }}</h3></div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover table-striped">
                    <thead><tr><th>#</th><th>{{ __('MRN') }}</th><th>{{ __('Name') }}</th><th>{{ __('Phone') }}</th><th>{{ __('Type') }}</th><th>{{ __('Date') }}</th><th>{{ __('Status') }}</th><th>{{ __('Action') }}</th></tr></thead>
                    <tbody>@foreach ($patients as $p)<tr><td>{{ $p->id }}</td><td>{{ $p->mrn }}</td><td>{{ $p->full_name }}</td><td>{{ $p->phone }}</td><td>{{ __(ucwords(str_replace('_', ' ', $p->patient_type))) }}</td><td>{{ displayDate($p->created_at, 'Y-m-d') }}</td><td><span class="badge badge-{{ $p->status === 'active' ? 'success' : 'secondary' }}">{{ __(ucfirst($p->status)) }}</span></td>
                        <td><a href="{{ route('masters.show', ['resource' => 'patients', 'id' => $p->id]) }}" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a></td></tr>@endforeach</tbody>
                </table>
            </div>
            <div class="card-footer clearfix">{{ $patients->links('vendor.pagination.bootstrap-4') }}</div>
        </div>
    </div>
</div>
@endif

@push('js')
<script>
$(document).ready(function() {
    $('.select2').select2({theme: 'bootstrap4'});
    $('.existing-patient').each(function () {
        var select = $(this);
        if (select.hasClass('select2-hidden-accessible')) {
            select.select2('destroy');
        }
        select.select2({
            theme: 'bootstrap4',
            width: '100%',
            allowClear: true,
            placeholder: '{{ __('New patient — enter details below') }}',
            minimumInputLength: 1,
            ajax: {
                url: '{{ route('workflow.reception.search-patients') }}',
                dataType: 'json',
                delay: 250,
                data: function (params) { return { q: params.term }; },
                processResults: function (data) { return data; }
            }
        }).on('change', function () {
            var form = select.closest('form');
            var existing = !!select.val();
            form.find('.new-patient-fields').toggle(!existing);
            form.find('.new-patient-fields').find('input, select, textarea').prop('disabled', existing);
        });
    });
    $('.insurance-company').on('change', function() {
        var form = $(this).closest('form');
        form.find('.insurance-coverage').val($(this).find('option:selected').data('coverage') || '');
        form.find('.insurance-detail, .insurance-coverage').prop('disabled', !$(this).val());
    }).trigger('change');
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        var target = $(e.target).attr('href');
        $(target).find('select.form-control.select2').each(function () {
            if ($(this).hasClass('select2-hidden-accessible')) {
                $(this).select2('destroy');
            }
            $(this).select2({ theme: 'bootstrap4', width: '100%' });
        });
    });

    // ─── Lab Tests Multi-Select ──────────────────────────────────────
    function setupLabTests(type) {
        var select = $('#lab-tests-' + type);
        if (!select.length) return;
        select.on('change', function() {
            var ids = $(this).val() || [];
            var tbody = $('#lab-tests-table-' + type + ' tbody');
            tbody.empty();
            var total = 0;
            ids.forEach(function(id) {
                var opt = select.find('option[value="' + id + '"]');
                var name = opt.text().split(' - ')[0];
                var price = parseFloat(opt.data('price'));
                total += price;
                tbody.append('<tr><td>' + name + '<input type="hidden" name="lab_tests[]" value="' + id + '"></td><td>' + price.toFixed(2) + ' {{ __('AFN') }}</td><td><button type="button" class="btn btn-sm btn-danger remove-lab-test" data-type="' + type + '" data-id="' + id + '"><i class="fas fa-times"></i></button></td></tr>');
            });
            $('#lab-total-' + type).text(total.toFixed(2) + ' {{ __('AFN') }}');
        });
        $(document).on('click', '.remove-lab-test', function() {
            var id = $(this).data('id');
            var t = $(this).data('type');
            var sel = $('#lab-tests-' + t);
            var vals = sel.val() || [];
            sel.val(vals.filter(function(v) { return v != id; })).trigger('change');
        });
    }
    setupLabTests('lab_only');

    // ─── Medicines Selection ────────────────────────────────────────
    var medicineItems = {};
    function setupMedicines(type) {
        var select = $('#medicine-select-' + type);
        if (!select.length) return;
        medicineItems[type] = [];
        select.on('change', function() {
            var id = $(this).val();
            if (!id) return;
            var opt = $(this).find('option:selected');
            var name = opt.text().split(' - ')[0];
            var price = parseFloat(opt.data('price'));
            var stock = parseInt(opt.data('stock'));
            if (medicineItems[type].find(function(i) { return i.id == id; })) { alert(@json(__('Already added.'))); return; }
            medicineItems[type].push({id: id, name: name, price: price, qty: 1, stock: stock});
            renderMedicineTable(type);
            $(this).val('').trigger('change');
        });
    }
    function renderMedicineTable(type) {
        var items = medicineItems[type] || [];
        var tbody = $('#medicine-table-' + type + ' tbody');
        tbody.empty();
        var total = 0;
        items.forEach(function(item, idx) {
            var lineTotal = item.price * item.qty;
            total += lineTotal;
            tbody.append('<tr><td>' + item.name + '<input type="hidden" name="medicines[' + idx + '][medicine_id]" value="' + item.id + '"><input type="hidden" name="medicines[' + idx + '][quantity]" value="' + item.qty + '"></td><td>' + item.price.toFixed(2) + '</td><td><input type="number" class="form-control form-control-sm medicine-qty" data-type="' + type + '" data-idx="' + idx + '" value="' + item.qty + '" min="1" max="' + item.stock + '" style="width:80px"></td><td>' + lineTotal.toFixed(2) + ' {{ __('AFN') }}</td><td><button type="button" class="btn btn-sm btn-danger remove-medicine" data-type="' + type + '" data-idx="' + idx + '"><i class="fas fa-times"></i></button></td></tr>');
        });
        $('#medicine-total-' + type).text(total.toFixed(2) + ' {{ __('AFN') }}');
    }
    setupMedicines('pharmacy_only');
    $(document).on('change', '.medicine-qty', function() {
        var type = $(this).data('type');
        var idx = $(this).data('idx');
        medicineItems[type][idx].qty = parseInt($(this).val()) || 1;
        renderMedicineTable(type);
    });
    $(document).on('click', '.remove-medicine', function() {
        var type = $(this).data('type');
        var idx = $(this).data('idx');
        medicineItems[type].splice(idx, 1);
        renderMedicineTable(type);
    });

    // ─── Form Submission ────────────────────────────────────────────
    $('.patient-register-form').on('submit', function(e) {
        e.preventDefault();
        var form = $(this);
        var flowType = form.data('flow');
        var btn = form.find('button[type="submit"]').html('<i class="fas fa-spinner fa-spin"></i> {{ __('Processing...') }}').prop('disabled', true);
        form.find('.alert-danger').remove();

        if (flowType === 'lab_only') {
            var labIds = $('#lab-tests-lab_only').val();
            if (!labIds || !labIds.length) {
                form.prepend('<div class="alert alert-danger"><ul><li>Please select at least one lab test.</li></ul></div>');
                btn.html('<i class="fas fa-flask"></i> {{ __('Register & Generate Bill') }}').prop('disabled', false);
                return;
            }
        }
        if (flowType === 'pharmacy_only') {
            if (!medicineItems['pharmacy_only'] || !medicineItems['pharmacy_only'].length) {
                form.prepend('<div class="alert alert-danger"><ul><li>Please add at least one medicine.</li></ul></div>');
                btn.html('<i class="fas fa-pills"></i> {{ __('Register & Generate Bill') }}').prop('disabled', false);
                return;
            }
        }

        $.ajax({
            url: '{{ route("workflow.reception.store-patient") }}',
            method: 'POST',
            data: form.serialize(),
            success: function(res) {
                if (res.success) {
                    window.location.href = res.redirect;
                }
            },
            error: function(xhr) {
                var errors = xhr.responseJSON?.errors;
                var msg = '<div class="alert alert-danger"><ul>';
                if (errors) { $.each(errors, function(k,v) { msg += '<li>'+v[0]+'</li>'; }); }
                else { msg += '<li>' + (xhr.responseJSON?.message || 'An error occurred') + '</li>'; }
                msg += '</ul></div>';
                form.prepend(msg);
                btn.html(form.data('flow') === 'lab_only' ? '<i class="fas fa-flask"></i> {{ __('Register & Generate Bill') }}' : '<i class="fas fa-pills"></i> {{ __('Register & Generate Bill') }}').prop('disabled', false);
            }
        });
    });
});
</script>
@endpush

@push('css')
<style>
    .registration-shell { --registration-primary: var(--primary, #2e7d32); }
    .registration-card__header { display:flex; align-items:center; min-height:76px; padding:1.1rem 1.35rem; }
    .registration-card__header .card-title { float:none; margin:0; color:#263238; font-size:1.12rem; }
    .registration-card__header .card-title i { color:var(--registration-primary); }
    .registration-card__subtitle { clear:both; padding-top:.3rem; color:#78909c; font-size:.88rem; }
    .registration-tabs { padding:.8rem 1.2rem 0; background:#fff; border-bottom:1px solid #edf1f0; }
    .registration-tabs .nav-tabs { gap:.4rem; }
    .registration-tabs .nav-link { border:0!important; border-radius:11px 11px 0 0!important; padding:.72rem .95rem; color:#607d8b; font-weight:600; background:#f4f7f6; transition:.18s ease; }
    .registration-tabs .nav-link:hover { color:var(--registration-primary); background:#edf6f0; }
    .registration-tabs .nav-link.active { color:#fff!important; background:var(--registration-primary)!important; box-shadow:0 5px 13px rgba(46,125,50,.18); }
    .registration-card > .card-body { padding:1.35rem; }
    .registration-section { margin:0 0 1.15rem; border:1px solid #e3ebe8; border-radius:14px; overflow:hidden; background:#fbfcfc; box-shadow:none; }
    .registration-section .card-header { padding:.75rem 1rem; background:#f7faf9; border-bottom:1px solid #e6eeeb; color:#455a64; }
    .registration-section .card-header i { width:1.25rem; color:var(--registration-primary); }
    .registration-section .card-body { padding:1rem; }
    .registration-section--patient { border-color:#d8e9dd; background:#f9fcfa; }
    .registration-shell label { color:#455a64; font-size:.86rem; font-weight:600; }
    .registration-shell .form-text { color:#78909c!important; }
    .registration-shell .btn-lg { padding:.65rem 1.15rem; font-size:.95rem; }
    .registration-shell .table { margin-bottom:0; }
    .registration-shell .table tfoot td { background:#f7faf9; border-top:1px solid #e3ebe8; }
    .registration-shell .card-tabs { border:0; }
    @media (max-width:767.98px) {
        .registration-tabs { padding:.7rem .75rem 0; overflow-x:auto; }
        .registration-tabs .nav-tabs { flex-wrap:nowrap; min-width:max-content; }
        .registration-tabs .nav-link { padding:.65rem .75rem; font-size:.85rem; }
        .registration-card > .card-body { padding:1rem .8rem; }
        .registration-card__subtitle { max-width:95%; }
    }
</style>
@endpush
@endsection
