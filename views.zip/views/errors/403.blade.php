<x-guest-layout>
    <div class="m3-title">
        <p>403</p>
        <h1>{{ __('Access denied') }}</h1>
        <p>{{ __('You do not have access to this page or action.') }}</p>
        <p><a href="{{ url('/') }}">{{ __('Back to home') }}</a></p>
    </div>
</x-guest-layout>
